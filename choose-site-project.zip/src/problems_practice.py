"""Practice page: every problem from Problem Set 4, unchanged, plus a challenge section from the lecture."""
from pcommon import *
from problems_lesson import positions_frames

PRACTICE = []
S1, S2, S3, S4 = "Choose function", "Block walking", "Problem solving", "Challenge from class"

# =========================================================== PS1
PRACTICE.append(problem(
    "ps1", "practice", S1, "1",
    "There are ten distinct candies in a bag, you reach your hand in and grab three candies. How many different "
    "possibilities are there for which candies you take?",
    [step("How many different handfuls of 3 candies are there?", 120,
          ["Does the order you grabbed them change what's in your hand?",
           "Count as if they came out one at a time. Then: how many of those lists show the same handful?",
           "Write every order of three particular candies. How many are there?"],
          "Pretend the candies come out one at a time and count those lists. Then ask how many lists show the same handful.",
          "10 × 9 × 8 ÷ (3 × 2 × 1) = 720 ÷ 6 = 120.", "10 choose 3 = 10!/(3!·7!) = 120.",
          "Each handful hid 6 orders inside the 720.",
          named={720: "That counts Mint-then-Lemon and Lemon-then-Mint as two handfuls. Are they?",
                 240: "You divided by 3. How many orders can one handful of 3 come out in?",
                 360: "How many orders does a group of three have, not two?",
                 1000: "Can the same candy come out twice?", 30: "Is it one choice of 10 and one of 3, or three choices in a row?",
                 170: "Very close in spirit. Recheck the last multiplication."})],
    choose_story("PS1", list("ABCDEFGHIJ"), 3, ["B", "E", "H"], "handful", "candies", list("ABCD")),
    "120", "10 × 9 × 8 = 720 ordered; each handful 3! = 6 times; 720 ÷ 6 = 120.", concept="c2", inclass="40:23"))

# =========================================================== PS2
V("PS2", len(partitions_brute(9, (5, 4))), comb(9, 5))
tiny_ps2 = sorted(split_names(b, "ABC") for b in partitions_brute(3, (2, 1)))
V("PS2 tiny", len(tiny_ps2), 3)
PRACTICE.append(problem(
    "ps2", "practice", S1, "2", "How many ways are there to form a team of 5 and a team of 4 out of 9 available players?",
    [step("How many ways are there to form the two teams?", 126,
          ["Once the team of 5 is picked, how much choice is left for the team of 4?",
           "Can the team of 5 and the team of 4 ever trade places?",
           "Count the ways to pick just the bigger team."],
          "Choose the 5 players for the bigger team; the other 4 are forced.",
          "9 choose 5 × 4 choose 4 = 126 × 1 = 126.", "Checked by listing every split of 9 into groups of 5 and 4.",
          "The team of 4 had no choices left.",
          named={252: "A team of 5 can't swap with a team of 4, so nothing needs undoing… but nothing needs doubling either.",
                 15876: "Once the 5 are picked, how many choices are left for the 4?",
                 63: "The teams have different sizes. Can swapping them give the same split?",
                 15120: "That's 9 × 8 × 7 × 6 × 5, picking the 5 in order."})],
    [Fr(1, v.bags([("team of 5", list("ABCDE"), 5), ("team of 4", list("FGHI"), 4)]),
        "One way: A, B, C, D, E on the team of 5; F, G, H, I on the team of 4."),
     Fr(2, v.chips_row(list("ABCDEFGHI"), caption="9 players: a team of 5 and a team of 4"), "All 9 players are used."),
     Skip(3, "any player can be on either team"),
     Fr(4, v.same_split([list("ABCDE"), list("FGHI")], [list("EDCBA"), list("IHGF")], note="order inside a team doesn't matter"),
        "Reordering a team changes nothing. Moving a player to the other team does."),
     Fr(5, v.calc(["9·8·7·6·5", "÷", "5!", "=", "126"], "team of 5"),
        "Team of 5: 9 choose 5 = 15,120 ÷ 120 = 126."),
     Fr(5, slots_from([("team of 5", "126"), ("team of 4", "1")], "126", note="the 4 left over are forced"),
        "Team of 4: the 4 left over, 1 way. 126 × 1 = 126."),
     Fr(6, v.same_split([list("ABCDE"), list("FGHI")], [list("FGHI"), list("ABCDE")], same=False, note="sizes differ"),
        "Twins? No. A team of 5 can't trade places with a team of 4, so each split was built once."),
     Fr(7, v.outcome_list(tiny_ps2, cols=3, note="3 choose 2 = 3"),
        "Tiny case: A, B, C into a team of 2 and a team of 1. 3 choose 2 = 3, and the list has 3.")],
    "126", "9 choose 5 = 126; the team of 4 is forced. Checked by listing every split.", concept="c4", inclass="41:13"))

# =========================================================== PS3
V("PS3 named", len(partitions_brute(10, (5, 5), True)), 252)
V("PS3", len(partitions_brute(10, (5, 5), False)), 126)
tiny_ps3 = sorted(split_names(b, "ABCD") for b in partitions_brute(4, (2, 2), False))
PRACTICE.append(problem(
    "ps3", "practice", S1, "3", "How many ways are there to form two teams of 5 out of 10 available players?",
    [step("How many ways are there to form the two teams?", 126,
          ["Do the two teams have names, like Red and Blue?",
           "Swap the two whole teams. Is that a new way to form them?",
           "If you count 'first team, then second team', how many times does each real split show up?"],
          "Count with a 'first team' and a 'second team'. Then ask how many times each real split appears in that count.",
          "10 choose 5 = 252 with a first team; each split appears twice; 252 ÷ 2 = 126.",
          "Checked by listing every split of 10 players into two unnamed teams of 5.",
          "Two unnamed teams of the same size can trade places.",
          named={252: "Not wrong, just unfinished. The teams have no names: swap them and see.",
                 63: "That divides by 4. How many ways can two teams be named?",
                 30240: "That picks the first team in order.", 15876: "Once one team is picked, how many choices are left for the other?"})],
    [Fr(1, v.bags([("a team", list("ABCDE"), 5), ("a team", list("FGHIJ"), 5)]), "One way: A to E together, F to J together."),
     Fr(2, v.chips_row(list("ABCDEFGHIJ"), caption="10 players, two teams of 5"), "Everyone plays: two teams of 5."),
     Skip(3, "any player can be on either team"),
     Fr(4, v.same_split([list("ABCDE"), list("FGHIJ")], [list("FGHIJ"), list("ABCDE")], note="no team names"),
        "Swap the two whole teams. With no names, it's the same pair of teams.",
        ask="What would change if the teams were called Red and Blue?"),
     Fr(5, v.calc(["10 choose 5", "×", "1", "=", "252"], "named"), "Pretend there's a first team: choose its 5 (252), and the rest are the second team."),
     Fr(6, v.same_split([list("ABCDE"), list("FGHIJ")], [list("FGHIJ"), list("ABCDE")], note="built twice"),
        "Twins? Yes. Each split was built once with each team as 'first'."),
     Fr(6, v.calc(["252", "÷", "2!", "=", "126"], "divide"), "252 ÷ 2 = 126."),
     Fr(7, v.outcome_list(tiny_ps3, cols=3, note="6 named ÷ 2 = 3"),
        "Tiny case: A, B, C, D into two teams of 2. Named 6, halved 3, and the list has 3.")],
    "126", "10 choose 5 ÷ 2! = 126. Checked by listing all unnamed splits.", concept="c5",
    note="The lecture's version of this problem uses 8 players and teams of 4; it's in the challenge section."))

# =========================================================== PS4
tiny4 = sorted("".join(p) for p in set(permutations("UURR")))
V("PS4", len(set(permutations("UUURRRR"))), 35)
PRACTICE.append(problem(
    "ps4", "practice", S1, "4", "How many ways are there to arrange the letters U, U, U, R, R, R, R?",
    [step("How many different arrangements are there?", 35,
          ["Swap two of the U's. Is that a new arrangement?",
           "Think about the 7 spots. What decides the arrangement?",
           "Once the U's are placed, is there anything left to decide?"],
          "Choose which 3 of the 7 spots hold a U; R's fill the rest.",
          "7 choose 3 = 35.", "7!/(3!·4!) = 5040 ÷ 144 = 35; checked by listing.", "The U spots decide everything.",
          named={5040: "That treats every U and every R as different.", 210: "That places the U's in order. Wash off the paint.",
                 840: "You took out the U orders. What about the R's?", 144: "That's the number of copies, not arrangements."})],
    positions_frames("UUURRRR", "RURRUUR", "PS4", "UURR", tiny4),
    "35", "7 choose 3 = 35.", concept="c6", inclass="43:24"))

# =========================================================== PS5-7 block walking
A, B, C = (0, 0), (4, 3), (8, 8)
V("PS5", paths_brute(A, B), comb(7, 3))
V("PS6", paths_brute(B, C), comb(9, 4))
V("PS7", paths_brute(A, C, through=B), 35 * 126)
V("PS7 all A to C", paths_brute(A, C), comb(16, 8))
GRIDNOTE = "Use the 8 × 8 grid: A is the bottom-left corner, B is 4 right and 3 up from A, C is the top-right corner."


def path_frames(key, start, end, path, word_letters, tiny):
    r, u = end[0] - start[0], end[1] - start[1]
    n = r + u
    tiny_end, tiny_list = tiny
    V(f"{key} tiny", paths_brute((0, 0), tiny_end), len(tiny_list))
    leg = [((start), path, "leg1")]
    return [
        Fr(1, v.vstack(v.lattice(8, 8, legs=leg, marks={"A": A, "B": B, "C": C}), v.word_strip(path)),
           f"One path: {' '.join(path)}."),
        Fr(2, v.word_strip(path, note=f"{n} moves: which {u} are U?"),
           f"Every path is {n} moves: {r} right and {u} up. The path is decided by which {u} moves are U."),
        Skip(3, "every up/right path between these points is allowed"),
        Fr(4, v.card(["swap two U's → same path", "swap a U and an R → new path"], "swap", W=320),
           "The U's are interchangeable, so the U spots form a group."),
        Fr(5, v.calc([f"{n} choose {u}", "=", fmt(comb(n, u))], "choose"),
           f"Choose the {u} U spots from {n}: {n} choose {u} = {fmt(comb(n, u))}."),
        Fr(6, v.card([f"{u}! orders of painted U's → same spots"], "twins", W=320),
           f"Twins? Yes, but '{n} choose {u}' has already divided by {u}!. Nothing more to undo."),
        Fr(7, v.vstack(v.lattice(tiny_end[0], tiny_end[1], path=tiny_list[0], marks={"A": (0, 0)}),
                       v.outcome_list(tiny_list, cols=3)),
           f"Tiny case: a {tiny_end[0]}-by-{tiny_end[1]} grid has {len(tiny_list)} paths, matching {tiny_end[0] + tiny_end[1]} choose {tiny_end[1]}."),
    ]


t21 = sorted(set("".join(p) for p in permutations("RRU")))
t12 = sorted(set("".join(p) for p in permutations("RUU")))
PRACTICE.append(problem(
    "ps5", "practice", S2, "5", GRIDNOTE + " How many paths are there from A to B which follow the lines on the grid and only go up or to the right?",
    [step("How many R moves and how many U moves does a path from A to B use? (R first)", [4, 3],
          ["Count squares along the bottom from A to below B.", "Then count up to B.", "Does every path use the same number?"],
          "B is some squares right and some squares up from A; count each.", "4 R and 3 U.", "B sits at (4, 3).",
          "Same moves on every path.", type="nums", order=True, named={"3,4": "Right numbers, wrong order: R first."}),
     step("How many paths from A to B?", 35,
          ["A path is a word of R's and U's. What decides it?", "How many spots, and how many hold U?",
           "Does the order you choose the U spots in matter?"],
          "Choose which of the moves are U.", "7 choose 3 = 35.", "Checked by walking every path.", "Paths are words.",
          named={128: "That lets every move be anything; the path must end at B.", 12: "That multiplies 4 × 3.",
                 5040: "That treats every move as different.", 210: "That places the U's in order."})],
    path_frames("PS5", A, B, "RURRUUR", "", ((2, 1), t21)), "35", "7 choose 3 = 35.", concept="c7", inclass="47:54"))
PRACTICE.append(problem(
    "ps6", "practice", S2, "6", GRIDNOTE + " How many paths are there from B to C which follow the lines on the grid and only go up or to the right?",
    [step("How many R moves and how many U moves does a path from B to C use? (R first)", [4, 5],
          ["How far right is C from B?", "How far up?", "Count squares, not dots."],
          "Subtract B's position from C's.", "4 R and 5 U.", "C − B = (8 − 4, 8 − 3).", "Every path uses these moves.",
          type="nums", order=True, named={"5,4": "Right numbers, wrong order: R first.", "4,8": "B isn't at the bottom: count up from B."}),
     step("How many paths from B to C?", 126,
          ["What decides a path?", "How many spots, and how many are U (or R)?", "Choose spots, not ordered spots."],
          "Choose which of the 9 moves are R (or U).", "9 choose 4 = 126.", "Checked by walking every path.",
          "Choosing the R spots or the U spots gives the same answer.",
          named={512: "That lets every move be anything.", 20: "That multiplies 4 × 5.", 3024: "That places the R's in order.",
                 35: "That's A to B."})],
    path_frames("PS6", B, C, "URUURRURU", "", ((1, 2), t12)), "126", "9 choose 4 = 126.", concept="c7", inclass="48:30"))

tiny7 = sorted(s for s in set("".join(p) for p in permutations("RRUU"))
               if any((s[:i].count("R"), s[:i].count("U")) == (1, 1) for i in range(5)))
V("PS7 tiny", paths_brute((0, 0), (2, 2), through=(1, 1)), len(tiny7))
V("PS7 tiny formula", len(tiny7), 2 * 2)
PRACTICE.append(problem(
    "ps7", "practice", S2, "7", GRIDNOTE + " How many paths are there from A to C which follow the lines on the grid, only go up or to the right, and pass through B?",
    [step("How many paths from A to C pass through B?", 4410,
          ["Split the trip at B. How many pieces does each path have?",
           "Does every first piece work with every second piece?",
           "Combine the two piece counts the way 'this AND that' choices combine."],
          "Each path through B is one A-to-B path followed by one B-to-C path. Combine the counts from problems 5 and 6.",
          "35 × 126 = 4,410.", "Checked by walking every A-to-C path and keeping those that touch B.",
          "Two legs: every first leg pairs with every second leg.",
          named={161: "Adding means 'leg 1 OR leg 2'. A trip needs leg 1 AND leg 2.",
                 12870: "That's every path from A to C, including ones that miss B.", 35: "That's only the first leg.",
                 126: "That's only the second leg."})],
    [Fr(1, v.lattice(8, 8, legs=[(A, "RURRUUR", "leg1"), (B, "URUURRURU", "leg2")], marks={"A": A, "B": B, "C": C}),
        "One path through B: a blue leg from A to B, then an orange leg from B to C."),
     Fr(2, v.card(["a first leg A → B", "a second leg B → C"], "two legs", W=280), "Each trip is a pair: one first leg and one second leg."),
     Fr(3, v.card(["rule: must touch B", "→ split every trip at B"], "rule", W=280),
        "Rule: the path must pass through B. Start with that: split every trip at B.", ask="Can a path pass through B in two different ways?"),
     Fr(4, v.card(["keep leg 1, change leg 2 → new trip", "change leg 1, keep leg 2 → new trip"], "swap", W=360),
        "Changing either leg changes the trip, and leg 1 always comes first."),
     Fr(5, slots_from([("A → B", "35"), ("B → C", "126")], "4,410", note="every first leg with every second leg"),
        "Any of the 35 first legs can be followed by any of the 126 second legs: 35 × 126 = 4,410."),
     Fr(6, v.card(["each trip splits at B in exactly one way"], "no twins", W=340), "Twins? No. Each trip has exactly one first leg and one second leg."),
     Fr(7, v.vstack(v.lattice(2, 2, legs=[((0, 0), "RU", "leg1"), ((1, 1), "UR", "leg2")], marks={"A": (0, 0), "B": (1, 1), "C": (2, 2)}),
                    v.outcome_list(tiny7, cols=2, note="2 × 2 = 4")),
        "Tiny case: 2-by-2 grid through the middle point. 2 first legs × 2 second legs = 4, and the list has 4.")],
    "4,410", "35 × 126 = 4,410; checked by walking every path.", concept="c7", inclass="49:11"))

# =========================================================== PS8
V("PS8 named", multinomial([4, 4, 4]), comb(12, 4) * comb(8, 4))
V("PS8", len(partitions_brute(12, (4, 4, 4), False)), 5775)
t8 = sorted(split_names(b, "ABCDEF") for b in partitions_brute(6, (2, 2, 2), False))
V("PS8 tiny named", len(partitions_brute(6, (2, 2, 2), True)), 90)
V("PS8 tiny", len(t8), 15)
from itertools import permutations as _perms
PRACTICE.append(problem(
    "ps8", "practice", S3, "8", "(2003 Purple Comet) In how many ways can we form three teams of four players each from a group of 12 participants?",
    [step("In how many ways can the three teams be formed?", 5775,
          ["Do the teams have names?", "Count as if the teams were Team 1, Team 2, Team 3. How many times does each real split appear?",
           "Three unnamed teams of the same size: how many ways are there to stick names on them?"],
          "Fill Team 1, Team 2, Team 3 from whoever is left. Then divide by the number of ways to name three teams.",
          "12 choose 4 × 8 choose 4 × 4 choose 4 = 495 × 70 × 1 = 34,650; ÷ 3! = 5,775.",
          "Checked by listing every split of 12 into three unnamed groups of 4.", "Three same-size unnamed teams: divide by 3!.",
          named={34650: "Not wrong, just unfinished. The teams have no names.", 17325: "You divided by 2. How many ways can three teams be named?",
                 11550: "You divided by 3. List the namings of teams X, Y, Z.", 495: "That's only the first team.",
                 1925: "You divided by 18."})],
    [Fr(1, v.bags([("a team", list("ABCD"), 4), ("a team", list("EFGH"), 4), ("a team", list("IJKL"), 4)]),
        "One way: ABCD, EFGH, IJKL."),
     Fr(2, v.chips_row(list("ABCDEFGHIJKL"), per_row=12, caption="12 players into three teams of 4"), "Everyone is on a team."),
     Skip(3, "any player can be on any team"),
     Fr(4, v.same_split([list("ABCD"), list("EFGH")], [list("EFGH"), list("ABCD")], note="teams have no names"),
        "Swap two whole teams: same three teams."),
     Fr(5, slots_from([("Team 1", "495"), ("Team 2", "70"), ("Team 3", "1")], "34,650", note="pretend the teams are named"),
        "Pretend the teams are named: 12 choose 4, then 8 choose 4, then 1. 495 × 70 × 1 = 34,650."),
     Fr(6, v.outcome_list(["".join(p) for p in _perms("XYZ")], cols=6, note="3! ways to name teams X, Y, Z"),
        "Twins? Yes. The same three teams got named in 3! = 6 ways (X, Y, Z in any order)."),
     Fr(6, v.calc(["34,650", "÷", "6", "=", "5,775"], "divide"), "34,650 ÷ 6 = 5,775."),
     Fr(7, v.outcome_list(t8, cols=3, note="90 named ÷ 3! = 15"),
        "Tiny case: 6 players into three pairs. Named 90, ÷ 6 = 15, and the list has 15.")],
    "5,775", "34,650 ÷ 3! = 5,775. Checked by listing every split.", concept="c5"))

# =========================================================== PS9
named9 = F(12) // (F(2) ** 3 * F(3) ** 2)
V("PS9 named", named9, comb(12, 2) * comb(10, 2) * comb(8, 2) * comb(6, 3))
V("PS9", named9 // 12, 138600)
t9 = sorted(split_names(b, "ABCD") for b in partitions_brute(4, (2, 2), False))
PRACTICE.append(problem(
    "ps9", "practice", S3, "9",
    "(2006 Purple Comet) 12 students need to form five study groups. They will form three study groups with 2 students "
    "each and two study groups with 3 students each. In how many ways can these groups be formed?",
    [step("Suppose the five groups had names (Group 1 to Group 5, with Groups 1–3 holding 2 and Groups 4–5 holding 3). How many ways?",
          named9,
          ["Fill the groups one at a time from whoever is left.", "How many students remain after each group?",
           "Multiply the choose counts for each group."],
          "Group 1: choose 2 of 12; Group 2: 2 of 10; Group 3: 2 of 8; Group 4: 3 of 6; Group 5: the last 3.",
          "66 × 45 × 28 × 20 × 1 = 1,663,200.", "Also 12!/(2!·2!·2!·3!·3!) = 1,663,200.", "That's the named count.",
          named={479001600: "That's 12!. It also orders the students inside each group."}),
     step("The groups really have no names. How many ways are there?", 138600,
          ["Which groups could trade places with each other?", "How many ways can three same-size groups be named? Two?",
           "Do the namings of the pairs and the trios combine by adding or multiplying?"],
          "The three pairs can be named in 3! ways and the two trios in 2! ways, and every pair-naming goes with every trio-naming.",
          "1,663,200 ÷ (3! × 2!) = 1,663,200 ÷ 12 = 138,600.", "Checked by listing every set partition of 12 students.",
          "Copies multiply: 6 × 2 = 12, not 6 + 2.",
          named={277200: "You took out the pair namings. What about the two trios?",
                 831600: "You took out the trio namings. What about the three pairs?",
                 207900: "Copies multiply: 3! × 2!, not 3! + 2!.", 1663200: "That's step 1's answer."})],
    [Fr(1, v.bags([("pair", list("AB"), 2), ("pair", list("CD"), 2), ("pair", list("EF"), 2), ("trio", list("GHI"), 3), ("trio", list("JKL"), 3)]),
        "One way: AB, CD, EF, GHI, JKL."),
     Fr(2, v.chips_row(list("ABCDEFGHIJKL"), per_row=12, caption="12 students: three pairs, two trios"), "Everyone is in exactly one group."),
     Fr(3, v.card(["two kinds of group: pairs and trios", "a pair can't trade with a trio"], "kinds", W=340),
        "Two kinds of group, but no cases to add. Just remember a pair can only trade with a pair."),
     Fr(4, v.same_split([list("AB"), list("CD")], [list("CD"), list("AB")], note="unnamed pairs"), "Swap two whole pairs: same groups."),
     Fr(5, slots_from([("G1", "66"), ("G2", "45"), ("G3", "28"), ("G4", "20"), ("G5", "1")], "1,663,200", note="pretend the groups are named"),
        "Named groups, filled from whoever is left: 66 × 45 × 28 × 20 × 1 = 1,663,200."),
     Fr(6, v.table(["pair namings", "trio namings", "copies"], [["3! = 6", "2! = 2", "6 × 2 = 12"]], hl=0),
        "Twins? Yes. Each real split was built 6 × 2 = 12 times: every way of naming the pairs with every way of naming the trios."),
     Fr(6, v.calc(["1,663,200", "÷", "12", "=", "138,600"], "divide"), "1,663,200 ÷ 12 = 138,600."),
     Fr(7, v.outcome_list(t9, cols=3, note="named 6 ÷ 2! = 3"),
        "Tiny case: A, B, C, D into two unnamed pairs. 6 named ÷ 2 = 3, and the list has 3.")],
    "138,600", "12!/(2!³·3!²) ÷ (3!·2!) = 138,600; checked over all 4,213,597 set partitions of 12.", concept="c5", above=True))

# =========================================================== PS10
subs = [frozenset(b + g) for b in combinations("bcdefg", 2) for g in combinations("BCDEFG", 2)]
V("PS10 one", len(subs), 225)
V("PS10", len({frozenset((s, t)) for s in subs for t in subs if not (s & t)}), 4050)
tsubs = [frozenset((b, g)) for b in ("b1", "b2") for g in ("g1", "g2")]
t10 = sorted({" & ".join(sorted("".join(sorted(x)) for x in pr)) for pr in
              {frozenset((s, t)) for s in tsubs for t in tsubs if not (s & t)}})
V("PS10 tiny", len(t10), 2)
PRACTICE.append(problem(
    "ps10", "practice", S3, "10",
    "(2000 MATHCOUNTS) The Sagebrush student council has 6 boys and 6 girls as class representatives. Two different "
    "subcommittees, each consisting of 2 boys and 2 girls, are to be created. If no student can serve on both "
    "subcommittees, how many different combinations of subcommittees are possible?",
    [step("How many ways are there to make just one subcommittee of 2 boys and 2 girls?", 225,
          ["Choose the boys and the girls separately.", "How many ways to pick 2 of 6 boys?",
           "Every pair of boys can go with every pair of girls."],
          "Choose 2 of the 6 boys and 2 of the 6 girls, and combine.", "6 choose 2 × 6 choose 2 = 15 × 15 = 225.",
          "Checked by listing.", "Boys and girls are chosen independently.",
          named={30: "Adding gives 'boys OR girls'. You need boys AND girls.", 495: "That's 12 choose 4, which could be all boys."}),
     step("How many different combinations of two subcommittees are possible?", 4050,
          ["After the first subcommittee, who is left?", "Do the two subcommittees have names?",
           "Count first-then-second, then ask how many times each pair of subcommittees appears."],
          "First subcommittee: step 1's count. Second, from the 4 boys and 4 girls left. The two subcommittees have no names.",
          "225 × (4 choose 2 × 4 choose 2) = 225 × 36 = 8,100; ÷ 2 = 4,050.",
          "Checked by listing every pair of non-overlapping subcommittees.", "Two unnamed subcommittees: divide by 2.",
          named={8100: "Not wrong, just unfinished: the two subcommittees have no names.",
                 50625: "That lets the same student serve on both.", 225: "That's step 1's answer.", 2025: "You divided by 4."})],
    [Fr(1, v.bags([("committee", ["b1", "b2", "G1", "G2"], 4), ("committee", ["b3", "b4", "G3", "G4"], 4)]),
        "One way: boys b1, b2 with girls G1, G2; and boys b3, b4 with girls G3, G4."),
     Fr(2, v.chips_row(["b1", "b2", "b3", "b4", "b5", "b6", "G1", "G2", "G3", "G4", "G5", "G6"], per_row=12,
                       caption="6 boys, 6 girls"), "Each subcommittee needs 2 boys and 2 girls."),
     Fr(3, v.card(["two kinds: boys and girls → choose each separately", "rule: nobody on both"], "rule", W=360),
        "Two rules: boys and girls are chosen separately, and nobody can be on both subcommittees."),
     Fr(4, v.same_split([["b1", "b2", "G1", "G2"], ["b3", "b4", "G3", "G4"]],
                        [["b3", "b4", "G3", "G4"], ["b1", "b2", "G1", "G2"]], note="no names on the committees"),
        "Swap the two subcommittees: same two subcommittees."),
     Fr(5, slots_from([("1st: boys", "15"), ("1st: girls", "15"), ("2nd: boys", "6"), ("2nd: girls", "6")], "8,100",
                      note="pretend there's a first subcommittee"),
        "Pretend there's a first one: 15 × 15 = 225. The second comes from the 4 boys and 4 girls left: 6 × 6 = 36. Total 8,100."),
     Fr(6, v.same_split([["b1", "b2", "G1", "G2"], ["b3", "b4", "G3", "G4"]],
                        [["b3", "b4", "G3", "G4"], ["b1", "b2", "G1", "G2"]], note="built twice"),
        "Twins? Yes. Each pair of subcommittees was built twice, once with each as 'first'."),
     Fr(6, v.calc(["8,100", "÷", "2", "=", "4,050"], "divide"), "8,100 ÷ 2 = 4,050."),
     Fr(7, v.outcome_list(t10, cols=2, note="named 4 ÷ 2 = 2"),
        "Tiny case: boys b1, b2 and girls g1, g2, two subcommittees of 1 boy + 1 girl. Named 4, halved 2, and the list has 2.")],
    "4,050", "225 × 36 ÷ 2 = 4,050; checked by listing every unordered pair of disjoint subcommittees.", concept="c5",
    note="'Two different subcommittees' is read as unnamed (the teacher's convention). If they were named, it would be 8,100."))

# =========================================================== PS11
ps11 = sum(1 for f in product(range(4), repeat=5) if len(set(f)) == 4)
V("PS11", ps11, comb(5, 2) * F(4))
V("PS11 obvious", 5 * 4 * 3 * 2 * 4, 2 * ps11)
t11 = []
for f in product("AB", repeat=3):
    if len(set(f)) == 2:
        a = "".join(str(i + 1) for i in range(3) if f[i] == "A")
        b = "".join(str(i + 1) for i in range(3) if f[i] == "B")
        t11.append(f"A:{a} B:{b}")
V("PS11 tiny", len(t11), comb(3, 2) * 2)
PRACTICE.append(problem(
    "ps11", "practice", S3, "11",
    "Ellen has five different jobs to be done. She assigns all five jobs to her four kids. Each kid will have at least "
    "one job. How many ways can Ellen assign the jobs?",
    [step("How many of the kids end up with more than one job?", 1,
          ["Picture one job in each kid's hands first. What happens to the jobs you haven't placed?",
           "Could two kids each have two jobs?", "5 jobs, 4 kids, nobody empty-handed."],
          "Give each kid one job; count what's left over.", "Exactly 1 kid gets two jobs.", "5 − 4 = 1 extra job.",
          "One kid doubles up.", named={2: "Two kids with two jobs would need 6 jobs.", 0: "5 jobs can't go one each to 4 kids."}),
     step("How many ways can Ellen assign the jobs?", 240,
          ["Look at the kid with two jobs. Did your count decide which of her two jobs came 'first'?",
           "Which two jobs end up together? Decide that first.",
           "Once two jobs are glued together, how many bundles are there for 4 kids?"],
          "Decide first which two jobs travel together. Then you have 4 bundles of jobs for 4 kids.",
          "5 choose 2 × 4! = 10 × 24 = 240.", "Checked: of all 4⁵ = 1,024 assignments, 240 leave no kid empty-handed.",
          "Gluing the pair first stops every assignment from being built twice.",
          named={480: "Not wrong, just unfinished: each assignment was built twice. Which of the doubled-up kid's jobs was the 'spare'?",
                 1024: "That lets a kid get no jobs.", 120: "That's 5!. There are 4 kids, not 5.",
                 24: "The kids are set; the jobs still need grouping.", 1: "That's step 1's answer."})],
    [Fr(1, v.assign(["Ana", "Ben", "Cal", "Dee"], {"Ana": ["Dishes", "Pets"], "Ben": ["Trash"], "Cal": ["Laundry"], "Dee": ["Garden"]}),
        "One assignment: Ana gets Dishes and Pets; Ben, Cal and Dee get one job each."),
     Fr(2, v.chips_row(["Dishes", "Pets", "Trash", "Laundry", "Garden"], w=72, caption="5 jobs, each given to one of 4 kids"),
        "Each of the 5 jobs goes to one of the 4 kids."),
     Fr(3, v.card(["rule: every kid gets at least one job", "5 jobs, 4 kids → exactly one kid gets two"], "rule", W=360),
        "Rule: nobody is empty-handed. So exactly one kid gets two jobs."),
     Fr(4, v.card(["giving Ana's job to Ben → new assignment", "Ana's two jobs in either order → same"], "swap", W=380),
        "Which kid gets which job matters. The order of Ana's own two jobs doesn't."),
     Fr(5, v.calc(["5·4·3·2", "×", "4", "=", "480"], "obvious build", crossed=True, note="one job each, then the spare to anyone"),
        "The obvious build: one job each (5 × 4 × 3 × 2), then the spare job to any kid (× 4) = 480.",
        ask="What does this count when Ana gets Dishes first and Pets as the spare?"),
     Fr(6, v.tiles([[("D", None, "p1"), ("+", None, None), ("P", None, "p2")], [("P", None, "p2"), ("+", None, None), ("D", None, "p1")]],
                   note="Dishes first, Pets spare  =  Pets first, Dishes spare"),
        "Twins? Yes. Each real assignment was built twice, once for each of the doubled-up kid's jobs being the 'spare'. 480 ÷ 2 = 240."),
     Fr(5, v.slots([{"lab": "glue 2 jobs", "n": "10"}, {"lab": "bundles → kids", "n": "24"}], result="240",
                   note="5 choose 2, then 4 × 3 × 2 × 1"),
        "A cleaner build: glue the two travelling jobs (5 choose 2 = 10), then hand 4 bundles to 4 kids (4! = 24). 10 × 24 = 240, no twins.",
        ask="Why does gluing first stop the twins?"),
     Fr(7, v.outcome_list(t11, cols=3, note="3 choose 2 × 2! = 6"),
        "Tiny case: jobs 1, 2, 3 for kids A and B. Obvious way 3 × 2 × 2 = 12, half are twins → 6. The list has 6.")],
    "240", "5 choose 2 × 4! = 240; brute force over all 1,024 assignments agrees.", concept="c4"))

# =========================================================== PS12
from problems_lesson import cube_pts
V("PS12", len(list(combinations(cube_pts, 2))), 28)
sq2 = ["".join(c) for c in combinations("ABCD", 2)]
PRACTICE.append(problem(
    "ps12", "practice", S3, "12", "How many line segments have both their endpoints located at the vertices of a given cube?",
    [step("How many segments are there?", 28,
          ["What decides a segment?", "Do the segments have to be edges of the cube?",
           "Is the segment from A to G different from the one from G to A?"],
          "A segment is decided by its 2 endpoints. Choose 2 of the 8 corners.", "8 choose 2 = 8 × 7 ÷ 2 = 28.",
          "12 edges + 12 face diagonals + 4 space diagonals = 28.", "Choose what decides the shape.",
          named={56: "That counts A-to-G and G-to-A separately.", 12: "Those are only the edges.",
                 24: "Edges and face diagonals. Any segments going through the middle of the cube?", 64: "A segment needs two different corners."})],
    [Fr(1, v.cube(hl=[("A", "G")]), "One segment: from corner A to corner G, straight through the cube."),
     Fr(2, v.cube(), "A segment is decided by its 2 endpoints. Choose 2 of the 8 corners."),
     Skip(3, "every pair of corners makes a segment"),
     Fr(4, v.card(["A to G  =  G to A"], "swap", W=240), "Swapping the endpoints gives the same segment."),
     Fr(5, slots_from([("1st end", "8"), ("2nd end", "7")], "56"), "Pick endpoints one at a time: 8 × 7 = 56."),
     Fr(6, v.bundle([("A", "G"), ("G", "A")], ["A", "G"]), "Twins? Yes. Each segment was built twice."),
     Fr(6, v.calc(["56", "÷", "2", "=", "28"], "divide"), "56 ÷ 2 = 28: 12 edges, 12 face diagonals, 4 through the middle."),
     Fr(7, v.vstack(v.dots({"A": (40, 150), "B": (150, 150), "C": (150, 40), "D": (40, 40)},
                           [("A", "B"), ("B", "C"), ("C", "D"), ("D", "A")], hl=[("A", "C"), ("B", "D")], W=200, H=180),
                    v.outcome_list(sq2, cols=3, note="4 × 3 ÷ 2 = 6")),
        "Tiny case: a square has 4 sides and 2 diagonals = 6 segments, and 4 choose 2 = 6.")],
    "28", "8 choose 2 = 28 = 12 + 12 + 4.", concept="c8"))

# =========================================================== PS13
oct_pts = v.polygon_points(8, r=72, cx=110, cy=100)
V("PS13", sum(1 for a, b in combinations(range(8), 2) if (b - a) % 8 not in (1, 7)), comb(8, 2) - 8)
pent = v.polygon_points(5, r=60, cx=80, cy=80)
pd = [a + b for a, b in combinations("ABCDE", 2) if (ord(b) - ord(a)) % 5 not in (1, 4)]
V("PS13 tiny", len(pd), comb(5, 2) - 5)
PRACTICE.append(problem(
    "ps13", "practice", S3, "13", "How many diagonals does a regular octagon have?",
    [step("How many diagonals are there?", 20,
          ["What decides a diagonal?", "Which segments between corners are not diagonals?",
           "From one corner, how many diagonals start? Is each diagonal counted from both of its ends?"],
          "Every pair of corners makes a segment; the ones that are sides aren't diagonals. Or: count from each corner, then fix the double count.",
          "8 choose 2 − 8 = 28 − 8 = 20; or 8 × 5 ÷ 2 = 20.", "Checked by testing every pair of corners.", "Diagonals = pairs minus sides.",
          named={28: "That includes the 8 sides.", 40: "Each diagonal was counted from both ends.", 5: "That's from one corner.",
                 56: "That counts each pair twice and includes sides."})],
    [Fr(1, v.dots(oct_pts, [(a, b) for a, b in zip("ABCDEFGH", "BCDEFGHA")], hl=[("A", "D")], W=220, H=200),
        "One diagonal: from A to D."),
     Fr(2, v.dots(oct_pts, [(a, b) for a, b in zip("ABCDEFGH", "BCDEFGHA")], W=220, H=200),
        "A diagonal is decided by its 2 corners, as long as they aren't neighbours."),
     Fr(3, v.card(["segments = sides + diagonals", "take away the sides"], "rule", W=300),
        "Rule: neighbours make a side, not a diagonal. Count all segments, then take away the sides."),
     Fr(4, v.card(["A to D  =  D to A"], "swap", W=240), "Swapping the ends gives the same diagonal."),
     Fr(5, v.dots(oct_pts, [(a, b) for a, b in zip("ABCDEFGH", "BCDEFGHA")], hl=[("A", x) for x in "CDEFG"], W=220, H=200),
        "From each corner, 5 diagonals start (not itself, not its 2 neighbours): 8 × 5 = 40."),
     Fr(6, v.calc(["40", "÷", "2", "=", "20"], "divide"), "Twins? Yes. Each diagonal was counted from both ends. 40 ÷ 2 = 20. (Also 28 − 8 = 20.)"),
     Fr(7, v.vstack(v.dots(pent, [(a, b) for a, b in zip("ABCDE", "BCDEA")], hl=[(x[0], x[1]) for x in pd], W=170, H=160),
                    v.outcome_list(pd, cols=5, note="5 × 2 ÷ 2 = 5")),
        "Tiny case: a pentagon. 5 × 2 ÷ 2 = 5 diagonals, and the list has 5.")],
    "20", "8 choose 2 − 8 = 20 = 8 × 5 ÷ 2.", concept="c8"))

# =========================================================== PS14
inc = [n for n in range(100, 1000) if len(set(str(n))) == 3 and str(n)[0] < str(n)[1] < str(n)[2]]
dec = [n for n in range(100, 1000) if len(set(str(n))) == 3 and str(n)[0] > str(n)[1] > str(n)[2]]
V("PS14 inc", len(inc), comb(9, 3))
V("PS14 dec", len(dec), comb(10, 3))
t14 = sorted(str(n) for n in range(10, 100) if set(str(n)) <= set("012") and str(n)[0] != str(n)[1]
             and (str(n)[0] < str(n)[1] or str(n)[0] > str(n)[1]))
V("PS14 tiny", len(t14), comb(2, 2) + comb(3, 2))
PRACTICE.append(problem(
    "ps14", "practice", S3, "14",
    "How many of the numbers, 100, 101, . . . , 999 have three different digits in increasing order or in decreasing order?",
    [step("How many have their digits in increasing order (like 147)?", 84,
          ["Pick any three different digits. In how many increasing orders can they be written?",
           "Can an increasing number use the digit 0?", "So you're really choosing a set of digits. From which digits?"],
          "Each set of 3 different digits gives exactly one increasing number, but 0 would have to lead, so leave it out.",
          "9 choose 3 = 84 (digits 1 to 9).", "Checked by testing every number from 100 to 999.", "Choose the digits; the order is forced.",
          named={120: "Can an increasing three-digit number contain 0?", 504: "That's 9 × 8 × 7: the order is already forced.",
                 720: "The order of the digits isn't free."}),
     step("How many have their digits in decreasing order (like 852)?", 120,
          ["Does each set of 3 different digits give a decreasing number?", "Can a decreasing number use 0? Where would it go?",
           "So, choose 3 digits from how many?"],
          "Each set of 3 different digits gives exactly one decreasing number, and 0 can sit at the end.",
          "10 choose 3 = 120 (digits 0 to 9).", "Checked by testing every number.", "0 is fine at the end (like 210).",
          named={84: "Can a decreasing number end in 0, like 210?", 720: "The order is forced once the digits are chosen.",
                 84 + 120: "That's both kinds. This step is decreasing only."}),
     step("How many numbers from 100 to 999 are increasing or decreasing?", 204,
          ["Can a number be both increasing and decreasing?", "Two kinds that can't overlap: combine them how?",
           "Use steps 1 and 2."],
          "The two kinds never overlap, so combine the two counts.", "84 + 120 = 204.",
          "Checked by testing every number from 100 to 999.", "Separate cases add.",
          named={168: "Do increasing and decreasing numbers come in equal amounts? Look at 0.",
                 240: "Increasing numbers can't use 0.", 10080: "Cases add; they don't multiply.",
                 84: "That's step 1's answer.", 120: "That's step 2's answer."})],
    [Fr(1, v.card(["147  (1 < 4 < 7)", "852  (8 > 5 > 2)"], "examples", W=260), "Two examples: 147 is increasing; 852 is decreasing."),
     Fr(2, v.chips_row([str(d) for d in range(10)], {"1": "picked", "4": "picked", "7": "picked"}, caption="choose 3 digits"),
        "What decides the number? Just its 3 digits, because the order is forced."),
     Fr(3, v.card(["two kinds: increasing, decreasing", "no number is both → add"], "cases", W=320),
        "Two kinds that can't overlap: count each, then add."),
     Fr(4, v.card(["{1, 4, 7} → 147 only (increasing)", "{1, 4, 7} → 741 only (decreasing)"], "swap", W=340),
        "Shuffling the digits doesn't make a new increasing number: each digit set gives exactly one.",
        ask="Why can't 0 be in an increasing number?"),
     Fr(5, v.chips_row([str(d) for d in range(10)], {"0": "banned"}, caption="increasing: 0 can't lead → choose from 1–9"),
        "Increasing: choose 3 of the digits 1 to 9: 84."),
     Fr(5, v.chips_row([str(d) for d in range(10)], caption="decreasing: 0 can sit at the end → choose from 0–9"),
        "Decreasing: choose 3 of 0 to 9: 120. (Like 210.)"),
     Fr(6, v.calc(["84", "+", "120", "=", "204"], "add"), "Twins? No. Each number is built once, in one case. Add: 84 + 120 = 204."),
     Fr(7, v.outcome_list(t14, cols=4, note="increasing 1 + decreasing 3 = 4"),
        "Tiny case: two-digit numbers using only 0, 1, 2. Increasing: 12 (1). Decreasing: 10, 20, 21 (3). Total 4, and the list has 4.")],
    "204", "9 choose 3 + 10 choose 3 = 84 + 120 = 204; checked number by number.", concept="c9"))

# =========================================================== PS15
cells = [(r, c) for r in range(5) for c in range(5)]
V("PS15", sum(1 for t in combinations(cells, 3) if len({x[0] for x in t}) == 3 and len({x[1] for x in t}) == 3),
  comb(5, 3) * 5 * 4 * 3)
c3 = [(r, c) for r in range(3) for c in range(3)]
t15 = sorted("".join(str(c + 1) for r, c in sorted(t)) for t in combinations(c3, 3)
             if len({x[0] for x in t}) == 3 and len({x[1] for x in t}) == 3)
V("PS15 tiny", len(t15), F(3))
PRACTICE.append(problem(
    "ps15", "practice", S3, "15",
    "(2007 AMC 10) A set of 25 square blocks is arranged into a 5×5 square. How many different combinations of 3 blocks "
    "can be selected from that set so that no two are in the same row or column?",
    [step("How many combinations of 3 blocks are there?", 600,
          ["Which part of the rule restricts you most?", "Could you choose the rows first?",
           "Once the rows are fixed (top to bottom), how many column choices does each row have?"],
          "Choose which 3 rows are used (as a group). Then, going down those rows in order, give each a column nobody above used.",
          "5 choose 3 × 5 × 4 × 3 = 10 × 60 = 600.", "Checked by testing every set of 3 of the 25 blocks.",
          "Rows as a group, columns in row order.",
          named={2300: "That's any 3 blocks; some share a row or column.", 100: "That chooses columns as a group too, but each row still needs its own column.",
                 3600: "That picks the blocks in order.", 60: "Which rows are used?", 1000: "Columns can't repeat."})],
    [Fr(1, v.table(["", "c1", "c2", "c3", "c4", "c5"], [["r1", "", "■", "", "", ""], ["r2", "", "", "", "", ""],
                                                       ["r3", "", "", "", "", "■"], ["r4", "■", "", "", "", ""], ["r5", "", "", "", "", ""]], hl={0, 2, 3}),
        "One combination: rows 1, 3, 4 with columns 2, 5, 1."),
     Fr(2, v.card(["3 blocks from 25", "no shared row, no shared column"], "setup", W=300), "We choose 3 blocks, with a rule."),
     Fr(3, v.card(["start with rows: choose 3 of 5", "5 choose 3 = 10"], "rows first", W=300),
        "Start with the most restricting part: choose which 3 rows (10 ways)."),
     Fr(4, v.card(["blocks picked in any order = same combination"], "swap", W=360), "The blocks form a group, so we must not count orders."),
     Fr(5, slots_from([("top row", "5"), ("middle row", "4"), ("bottom row", "3")], "60", note="columns, going down the chosen rows"),
        "Going down the chosen rows, the top one has 5 columns, the next 4, the last 3: 60."),
     Fr(5, v.calc(["10", "×", "60", "=", "600"], "multiply"), "10 row-sets × 60 column patterns = 600."),
     Fr(6, v.card(["rows: chosen as a set (÷3! done inside 5 choose 3)", "columns: tied to rows top→bottom, once"], "twins", W=420),
        "Twins? No. Each combination is built once. (Picking blocks in order would give 3,600 = 600 × 3!.)"),
     Fr(7, v.outcome_list(t15, cols=6, note="3 choose 3 × 3 × 2 × 1 = 6"),
        "Tiny case: a 3 × 3 square, 3 blocks. Listing columns row by row gives 6, matching 1 × 3 × 2 × 1.")],
    "600", "5 choose 3 × 5 × 4 × 3 = 600; checked over all 2,300 triples.", concept="c9"))

# =========================================================== PS16
ok_ori = [o for o in product((0, 1), repeat=8) if all(not (o[i] == 1 and o[i + 1] == 0) for i in range(7))]
V("PS16 faces", len(ok_ori), 9)
V("PS16 colours", len(set(permutations("GGGGSSSS"))), comb(8, 4))
V("PS16", len(set(permutations("GGGGSSSS"))) * len(ok_ori), 630)
t16 = []
for cols in sorted(set(permutations("GGS"))):
    for o in product((0, 1), repeat=3):
        if all(not (o[i] == 1 and o[i + 1] == 0) for i in range(2)):
            t16.append("".join(cols) + " " + "".join("▲" if x else "▼" for x in o))
V("PS16 tiny", len(t16), 12)
PRACTICE.append(problem(
    "ps16", "practice", S3, "16",
    "Robert has 4 indistinguishable gold coins and 4 indistinguishable silver coins. Each coin has an engraving of one "
    "face on one side, but not on the other. He wants to stack the eight coins on a table into a single stack so that "
    "no two adjacent coins are face to face. Find the number of possible distinguishable arrangements of the 8 coins.",
    [step("Forget the engraved faces. How many different colour orders (bottom to top) can the stack have?", 70,
          ["Two gold coins look the same: does swapping them make a new stack?",
           "Think about the 8 spots. What decides the colour order?", "Choose which spots are gold."],
          "Choose which 4 of the 8 spots hold gold coins.", "8 choose 4 = 70.", "Checked by listing colour orders.", "Colours done.",
          named={40320: "Two gold coins look the same.", 576: "Is it 4! × 4!, or choosing which spots are gold?",
                 256: "There must be exactly four gold."}),
     step("Forget the colours. Each coin is face-up or face-down. How many up/down patterns, bottom to top, avoid two faces touching?", 9,
          ["Which pair actually touches face to face: a face-up coin under a face-down one, or the other way round?",
           "Once a coin is face-up, what must every coin above it be?",
           "Try listing the 3-coin version. How many patterns does it have?"],
          "A face-up coin can never have a face-down coin right on top of it. So the stack is some face-down coins, then all face-up.",
          "0 to 8 face-down coins at the bottom: 9 patterns.", "Checked by testing all 256 patterns.", "Faces done.",
          named={256: "Some of those put a face-up coin right under a face-down one.", 8: "Did you count all-down and all-up?",
                 2: "Mixed patterns are allowed too: some down, then up.", 10: "Try listing the 3-coin version."}),
     step("How many stacks are there?", 630,
          ["Does each colour order work with each face pattern?", "Two independent decisions: add or multiply?",
           "Use steps 1 and 2."],
          "Colours and faces are separate decisions, and any colour order works with any face pattern.",
          "70 × 9 = 630.", "Checked by testing every colour order with every face pattern.", "Two independent decisions multiply.",
          named={79: "Each colour order goes with each face pattern.", 70: "That's step 1's answer.", 9: "That's step 2's answer."})],
    [Fr(1, v.coins([("G", False), ("S", False), ("G", True), ("G", True), ("S", True), ("S", True), ("G", True), ("S", True)]),
        "One stack, bottom to top: colour and which way up."),
     Fr(2, v.card(["8 colour spots: gold or silver", "8 face spots: ▲ up or ▼ down"], "two strips", W=320),
        "Two separate choices for each spot: colour, and face-up or face-down."),
     Fr(3, v.coins([("G", True), ("S", False)], bad=0, note="▲ under ▼: faces touch"),
        "Rule: faces may not touch, which happens when a face-up coin sits right under a face-down coin."),
     Fr(4, v.card(["swap two gold coins → identical stack"], "swap", W=320), "Gold coins are identical, so swapping them changes nothing."),
     Fr(5, v.chips_row([str(i + 1) for i in range(8)], {0: "picked", 2: "picked", 3: "picked", 6: "picked"}, caption="choose 4 spots for gold"),
        "Colours: choose 4 of 8 spots for gold = 70.", ask="Why not 8!?"),
     Fr(5, v.tree([("▼", [("▼▼", None), ("▼▲", None)]), ("▲", [("▲▲", None)])], counts=["coin 1", "coin 2"], leaf_w=52),
        "Faces: the options aren't equal. After ▲ only ▲ may follow; after ▼ either may. So list instead of doubling."),
     Fr(5, v.outcome_list(["▼▼▼▼▼▼▼▼", "▼▼▼▼▼▼▼▲", "▼▼▼▼▼▼▲▲", "▼▼▼▼▼▲▲▲", "▼▼▼▼▲▲▲▲", "▼▼▼▲▲▲▲▲", "▼▼▲▲▲▲▲▲", "▼▲▲▲▲▲▲▲", "▲▲▲▲▲▲▲▲"],
                         cols=3, cellw=104, note="some ▼ then all ▲"),
        "Once a ▲ appears, everything above it is ▲. So 0 to 8 ▼ coins at the bottom: 9 patterns."),
     Fr(6, v.calc(["70", "×", "9", "=", "630"], "multiply"),
        "Twins? No. Each stack has one colour order and one face pattern. Any colour order works with any face pattern: 70 × 9 = 630."),
     Fr(7, v.outcome_list(t16, cols=4, cellw=78, note="3 colour orders × 4 face patterns = 12"),
        "Tiny case: 2 gold, 1 silver. 3 colour orders × 4 face patterns = 12, and the list has 12.")],
    "630", "8 choose 4 × 9 = 630; checked by testing every colour order with every face pattern.", concept="c6", above=True))

# =========================================================== PS17
V("PS17", [n for n in range(6, 200) if comb(n, 6) == 6 * comb(n, 3)], [13])
rows17 = [[str(n), fmt(comb(n, 3)), fmt(comb(n, 6)), fmt(6 * comb(n, 3))] for n in (10, 11, 12, 13, 14)]
PRACTICE.append(problem(
    "ps17", "practice", S3, "17",
    "A game uses a deck of n different cards, where n is an integer and n ≥ 6. The number of possible sets of 6 cards "
    "that can be drawn from the deck is 6 times the number of possible sets of 3 cards that can be drawn. Find n.",
    [step("What is n?", 13,
          ["Try a value of n. Compute the sets of 3 and the sets of 6.", "If sets of 6 come out too small, should n go up or down?",
           "Write both counts as falling products. Which factors cancel when you compare them?"],
          "Try values in a table, or compare (n choose 6) to (n choose 3): after cancelling, (n−3)(n−4)(n−5) must equal 720.",
          "n = 13: 13 choose 6 = 1,716 and 13 choose 3 = 286, and 6 × 286 = 1,716.",
          "(n−3)(n−4)(n−5) = 720 = 10 × 9 × 8, so n = 13; checked for every n up to 200.", "Three consecutive numbers multiplying to 720.",
          special="ps17")],
    [Fr(1, v.card(["a deck of n cards", "sets of 6 and sets of 3"], "setup", W=280), "We don't know n. We compare two counts."),
     Fr(2, v.card(["sets of 6: n choose 6", "sets of 3: n choose 3"], "what is chosen", W=300), "Both are groups chosen from the same n cards."),
     Fr(3, v.card(["rule: (n choose 6) = 6 × (n choose 3)"], "rule", W=340), "The rule turns the counting into a search for n."),
     Fr(4, v.card(["a set of cards has no order"], "swap", W=280), "Sets have no order, so both counts are choose counts."),
     Fr(5, v.table(["n", "sets of 3", "sets of 6", "6 × sets of 3"], rows17, hl=3),
        "Try values: for small n, sets of 6 are too few; the row where they match is the answer."),
     Fr(6, v.card(["(n choose 6) ÷ (n choose 3) = (n−3)(n−4)(n−5) ÷ 120", "= 6 → (n−3)(n−4)(n−5) = 720 = 10 × 9 × 8"], "cancel", W=440),
        "Cancelling shows three consecutive numbers must multiply to 720 = 10 × 9 × 8. So n − 3 = 10."),
     Fr(7, v.calc(["6 × 286", "=", "1,716"], "check"), "Check n = 13: 13 choose 3 = 286, 13 choose 6 = 1,716 = 6 × 286. ✓")],
    "13", "13 choose 6 = 1,716 = 6 × 286 = 6 × (13 choose 3); n = 13 is the only solution up to 200.", concept="c9", above=True))

# =========================================================== PS18
V("PS18", [N for N in range(6, 200) if comb(N - 5, 2) + 10 == 220], [26])
t18 = ["".join(c) for c in combinations("ABCD", 2)]
PRACTICE.append(problem(
    "ps18", "practice", S3, "18",
    "(2012 MATHCOUNTS) In a round-robin chess tournament every player plays one game with every other player. Five "
    "participants withdrew after playing two games each. None of these players played a game against each other. A "
    "total of 220 games were played in the tournament. Including those who withdrew, how many players participated?",
    [step("How many games did the five players who withdrew play altogether?", 10,
          ["Each played 2 games. Could a game be counted twice?", "Did any two of them play each other?",
           "Count their games."],
          "5 players × 2 games each, and no game is between two of them, so none is double counted.", "10 games.",
          "5 × 2 = 10, no overlaps.", "Their games are all against players who stayed.",
          named={5: "Each played 2.", 20: "Each played only 2 games."}),
     step("How many games were played among the players who stayed?", 210,
          ["Take the withdrawn players' games away from the total.", "Use step 1.", "Every game is one or the other."],
          "Total games minus the withdrawn players' games.", "220 − 10 = 210.", "Two kinds of game add to 220.", "Cases add.",
          named={230: "Take away, don't add.", 220: "Some of the 220 involved withdrawn players."}),
     step("How many players stayed?", 21,
          ["How many games does a round robin of n players have?", "Each game is a pair of players. n choose 2 = 210.",
           "Find two consecutive numbers that multiply to 420."],
          "n choose 2 = 210, so n × (n − 1) = 420.", "21 × 20 = 420, so n = 21.", "21 choose 2 = 210.", "Two consecutive numbers.",
          named={20: "Check: 20 choose 2 = 190.", 22: "Check: 22 choose 2 = 231.", 210: "That's step 2's answer."}),
     step("Including those who withdrew, how many players participated?", 26,
          ["Who is missing from step 3?", "Add the players who withdrew.", "21 + ?"],
          "Players who stayed plus players who withdrew.", "21 + 5 = 26.", "C(21, 2) + 10 = 210 + 10 = 220. ✓", "Done.",
          named={21: "That's step 3's answer: who's missing?", 31: "Only 5 withdrew."})],
    [Fr(1, v.dots(v.polygon_points(6, r=70, cx=110, cy=95), [(a, b) for a, b in combinations("ABCDEF", 2)], hl=[("A", "D")], W=220, H=190),
        "In a round robin, every pair of players plays once. Each line is one game."),
     Fr(2, v.card(["a game = a pair of players"], "chosen", W=260), "A game is decided by its 2 players."),
     Fr(3, v.card(["games by the 5 who left: 5 × 2 = 10", "games among those who stayed: 220 − 10"], "two kinds", W=360),
        "Two kinds of games: those involving the 5 who withdrew, and those among the players who stayed."),
     Fr(4, v.card(["A vs B  =  B vs A"], "swap", W=220), "A game between A and B is the same as B and A."),
     Fr(5, v.calc(["n × (n − 1) ÷ 2", "=", "210"], "stayers"), "Players who stayed: n × (n − 1) ÷ 2 = 210, so n × (n − 1) = 420 = 21 × 20."),
     Fr(6, v.card(["each game counted from both players → ÷ 2"], "twins", W=320), "Twins? Yes. n × (n − 1) counts each game from both players, so we halve it."),
     Fr(6, v.calc(["21", "+", "5", "=", "26"], "total"), "21 stayed + 5 withdrew = 26."),
     Fr(7, v.vstack(v.dots({"A": (40, 140), "B": (150, 140), "C": (150, 40), "D": (40, 40)},
                           [(a, b) for a, b in combinations("ABCD", 2)], W=200, H=170),
                    v.outcome_list(t18, cols=3, note="4 × 3 ÷ 2 = 6")),
        "Tiny case: 4 players play 4 × 3 ÷ 2 = 6 games, and the list has 6.")],
    "26", "21 choose 2 + 10 = 210 + 10 = 220; n = 26 is the only solution.", concept="c8", above=True,
    note="Assumes the players who stayed completed the round robin among themselves."))

# =========================================================== Challenge from class
V("CH1 named", len(partitions_brute(8, (4, 4), True)), 70)
V("CH1", len(partitions_brute(8, (4, 4), False)), 35)
tch1 = sorted(split_names(b, "ABCD") for b in partitions_brute(4, (2, 2), False))
PRACTICE.append(problem(
    "ch1", "practice", S4, "Class practice 3", "How many ways are there to form two teams of 4 out of 8 available players?",
    [step("How many ways are there to form the two teams?", 35,
          ["Do the teams have names?", "Swap the two whole teams: new way or the same?",
           "In a first-team, second-team count, how often does each split appear?"],
          "Count with a first team, then remove the naming of two same-size teams.", "8 choose 4 ÷ 2! = 70 ÷ 2 = 35.",
          "Checked by listing every split.", "Same idea as problem 3, smaller numbers.",
          named={70: "Not wrong, just unfinished: two teams of four don't have to be a first and second team.",
                 1680: "That picks the first team in order.", 17: "Recheck your division."})],
    [Fr(1, v.bags([("a team", list("ABCD"), 4), ("a team", list("EFGH"), 4)]), "One way: ABCD and EFGH."),
     Fr(2, v.chips_row(list("ABCDEFGH"), caption="8 players, two teams of 4"), "Two teams of 4."),
     Skip(3, "any player can be on either team"),
     Fr(4, v.same_split([list("ABCD"), list("EFGH")], [list("EFGH"), list("ABCD")]), "Swap whole teams: same split."),
     Fr(5, v.calc(["8 choose 4", "×", "1", "=", "70"], "named"), "With a first team: 70."),
     Fr(6, v.calc(["70", "÷", "2!", "=", "35"], "divide"), "Twins? Yes. Each split appears twice. 70 ÷ 2 = 35."),
     Fr(7, v.outcome_list(tch1, cols=3, note="6 ÷ 2 = 3"), "Tiny case: 4 players into two pairs: 3, matching 6 ÷ 2.")],
    "35", "70 ÷ 2! = 35.", concept="c5", inclass="42:11"))

# Problem 3.1
nodes = [(i, j) for i in range(6) for j in range(5)]


def _is_par(S):
    xs = sorted({p[0] for p in S})
    ys = sorted({p[1] for p in S})
    return len(xs) == 2 and len(ys) == 2 and set(S) == {(x, y) for x in xs for y in ys}


V("CH2", sum(1 for S in combinations(nodes, 4) if _is_par(S)), comb(6, 2) * comb(5, 2))
n22 = [(i, j) for i in range(3) for j in range(3)]
V("CH2 tiny", sum(1 for S in combinations(n22, 4) if _is_par(S)), comb(3, 2) * comb(3, 2))
PRACTICE.append(problem(
    "ch2", "practice", S4, "Problem 3.1",
    "In the figure shown, there are parallelograms of many sizes. How many total parallelograms are there in the diagram? "
    "(The figure is a slanted grid 5 small parallelograms wide and 4 tall.)",
    [step("How many parallelograms are there in total?", 150,
          ["Why doesn't choosing 4 corners work?", "What two things decide a parallelogram in this figure?",
           "How many slanted lines are there? How many flat lines?"],
          "A parallelogram here is decided by 2 of the slanted lines and 2 of the flat lines.",
          "6 choose 2 × 5 choose 2 = 15 × 10 = 150.", "Checked by testing every set of 4 grid corners.",
          "Choose what decides the shape: two pairs of lines.",
          named={20: "Those are only the smallest ones.", 25: "Choosing pairs of lines doesn't add; each slanted pair goes with each flat pair.",
                 225: "Count the flat lines again (including the top and bottom).", 100: "Count the slanted lines again (including the ends).",
                 27405: "Most sets of 4 corners aren't parallelograms."})],
    [Fr(1, v.skew_grid(5, 4, hl_v=(1, 3), hl_h=(0, 2)), "One parallelogram, 2 wide and 2 tall."),
     Fr(2, v.skew_grid(5, 4, number=True), "What decides it? Two slanted lines and two flat lines. There are 6 slanted and 5 flat."),
     Fr(3, v.card(["4 corners don't always make one", "→ choose lines instead"], "rule", W=300),
        "Choosing 4 corners fails: three could even lie on one line. So choose lines."),
     Fr(4, v.card(["lines 2 and 4  =  lines 4 and 2"], "swap", W=300), "A pair of lines has no order."),
     Fr(5, slots_from([("slanted pair", "15"), ("flat pair", "10")], "150", note="6 choose 2 × 5 choose 2"),
        "6 choose 2 = 15 slanted pairs, 5 choose 2 = 10 flat pairs. Each goes with each: 150."),
     Fr(6, v.card(["each parallelogram ↔ exactly one slanted pair", "and exactly one flat pair"], "twins", W=360),
        "Twins? No. The order is already removed inside 'choose 2'."),
     Fr(7, v.skew_grid(2, 2, hl_v=(0, 2), hl_h=(0, 2), note="3 choose 2 × 3 choose 2 = 9"),
        "Tiny case: a 2-by-2 slanted grid. 4 small + 2 wide + 2 tall + 1 big = 9 = 3 × 3.")],
    "150", "6 choose 2 × 5 choose 2 = 150; checked over all 4-corner sets.", concept="c8", inclass="50:22"))

# Problem 3.3
sol = [(r, b) for r in range(1, 40) for b in range(1, 40) if comb(r, 2) * b + r * comb(b, 2) == 25]
V("CH3", sol, [(2, 5), (5, 2)])
studs = ["R1", "R2", "B1", "B2", "B3", "B4", "B5"]
rrb = [" ".join(t) for t in combinations(studs, 3) if sum(s[0] == "R" for s in t) == 2]
rbb = [t for t in combinations(studs, 3) if sum(s[0] == "R" for s in t) == 1]
V("CH3 RRB", len(rrb), 5)
V("CH3 RBB", len(rbb), 20)
rows33 = [["{1, 2}", "2", "too small"], ["{1, 5}", "20", "too small"], ["{1, 10}", "90", "too big"],
          ["{2, 5}", "50", "works"], ["{5, 5}", "200", "too big"]]
for rb, val, _ in rows33:
    a, b2 = [int(x) for x in rb.strip("{}").split(",")]
    V(f"CH3 table {rb}", a * b2 * (a + b2 - 2), int(val))
PRACTICE.append(problem(
    "ch3", "practice", S4, "Problem 3.3",
    "(2009 ARML I-3) Some students in a gym class are wearing blue jerseys, and the rest are wearing red jerseys. There "
    "are exactly 25 ways to pick a team of three players that includes at least one player wearing each color. Compute "
    "the number of students in the class.",
    [step("How many students wear each colour? (Two numbers, any order.)", [2, 5],
          ["A mixed team of 3 is either 2 red + 1 blue, or 1 red + 2 blue. Count each kind with letters r and b.",
           "Try small numbers of red and blue and count mixed teams.", "Which pairs make exactly 25?"],
          "Mixed teams: (r choose 2) × b + r × (b choose 2) = 25. Doubling gives r·b·(r + b − 2) = 50; try factor pairs of 50.",
          "2 and 5.", "With 2 red, 5 blue: 1 × 5 + 2 × 10 = 25.", "Cases add, then search.", type="nums"),
     step("How many students are in the class?", 7,
          ["Use step 1.", "Every student wears one of the two colours.", "Add."],
          "Red plus blue.", "2 + 5 = 7.", "5 two-red teams + 20 one-red teams = 25. ✓", "Done.",
          named={25: "That's the number of teams.", 10: "Add the colours, don't multiply.", 50: "That's twice the number of teams."})],
    [Fr(1, v.outcome_list(["R1 R2 B3"], cols=1, cellw=110), "One mixed team: two reds and a blue."),
     Fr(2, v.card(["r red students, b blue students", "choose 3 with both colours"], "setup", W=320), "We don't know r or b."),
     Fr(3, v.card(["2 red + 1 blue", "1 red + 2 blue", "never both → add"], "cases", W=260),
        "Two kinds of mixed team that can't overlap: count each and add."),
     Fr(4, v.card(["a team has no order"], "swap", W=240), "Teams are groups, so we use choose counts."),
     Fr(5, v.calc(["(r choose 2)·b", "+", "r·(b choose 2)", "=", "25"], "equation"),
        "(r choose 2) × b + r × (b choose 2) = 25. Doubling and factoring gives r × b × (r + b − 2) = 50."),
     Fr(6, v.table(["{r, b}", "r·b·(r+b−2)", "result"], rows33, hl=3),
        "The ÷2 inside each 'choose 2' is the only twin fix. Now try pairs whose product divides 50: only {2, 5} gives 50."),
     Fr(7, v.outcome_list(rrb, cols=5, cellw=74, note="2-red teams: 5;  1-red teams: 2 × 10 = 20"),
        "Check with 2 red and 5 blue: 5 two-red teams (listed) + 20 one-red teams = 25. ✓")],
    "7", "{r, b} = {2, 5}; 5 + 20 = 25 mixed teams; 7 students.", concept="c9", inclass="56:57", above=True))
