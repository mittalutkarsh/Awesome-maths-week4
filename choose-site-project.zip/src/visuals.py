"""Visual primitives. Every picture on the site is generated here from data.

All functions return an <svg> (or small HTML) string. Colours come from CSS classes so the
page palette controls them. Every painted copy carries a letter/subscript as well as a colour.
"""
from html import escape as _e

_MK = [0]


def _mid(base):
    _MK[0] += 1
    return f"{base}{_MK[0]}"


PAINT = ["p1", "p2", "p3", "p4", "p5", "p6"]   # css classes for painted copies


def esc(s):
    return _e(str(s), quote=True)


def svg(w, h, body, label, cls=""):
    mw = round(w * 1.45)
    return (f'<svg class="pic {cls}" viewBox="0 0 {w} {h}" role="img" aria-label="{esc(label)}" '
            f'style="max-width:{mw}px" preserveAspectRatio="xMidYMid meet">{body}</svg>')


def text(x, y, s, cls="t", anchor="middle", size=None):
    st = f' style="font-size:{size}px"' if size else ""
    return f'<text x="{x}" y="{y}" class="{cls}" text-anchor="{anchor}"{st}>{esc(s)}</text>'


def tspan_sub(main, sub):
    """Letter with subscript, as SVG tspans."""
    if not sub:
        return esc(main)
    return f'{esc(main)}<tspan class="sub" dy="4">{esc(sub)}</tspan><tspan dy="-4"></tspan>'


# ---------------------------------------------------------------- chips
def chip(x, y, label, state="", w=34, h=26, sub=None, paint=None):
    """Option chip. state: '' | picked | used | banned."""
    cls = f"chip {state} {paint or ''}".strip()
    body = f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="6" class="{cls}"/>'
    body += (f'<text x="{x + w / 2}" y="{y + h / 2 + 5}" class="chiptxt {state}" text-anchor="middle">'
             f'{tspan_sub(label, sub)}</text>')
    if state in ("used", "banned"):
        body += f'<line x1="{x + 3}" y1="{y + h - 4}" x2="{x + w - 3}" y2="{y + 4}" class="strike {state}"/>'
    return body


def chips_row(labels, states=None, label="options", w=34, gap=6, caption=None, per_row=None):
    states = states or {}
    per_row = per_row or len(labels)
    rows = (len(labels) + per_row - 1) // per_row
    W = max(per_row * (w + gap) + gap, 120)
    H = rows * 34 + 10 + (24 if caption else 0)
    b = ""
    for i, lab in enumerate(labels):
        r, c = divmod(i, per_row)
        b += chip(gap + c * (w + gap), 6 + r * 34, lab, states.get(i, states.get(lab, "")), w=w)
    if caption:
        b += text(W / 2, H - 6, caption, "cap")
    return svg(W, H, b, label)


# ---------------------------------------------------------------- slots
def slots(items, ops=None, result=None, label="slots", note=None, chips_per=None):
    """items: list of dicts {lab, n, chips:[(label,state)], show_n:True}
    ops: list of operators between items ('×','÷','+'); result: value string or None."""
    ops = ops or ["×"] * (len(items) - 1)
    bw, gap = 74, 30
    chip_rows = 0
    for it in items:
        if it.get("chips"):
            chip_rows = max(chip_rows, (len(it["chips"]) + 2) // 3)
    H = 112 + chip_rows * 22 + (22 if note else 0)
    n = len(items)
    rw = max(84, 13 * len(str(result)) + 22) if result is not None else 0
    W = n * bw + (n - 1) * gap + (gap + rw if result is not None else 0) + 20
    x = 10
    b = ""
    for i, it in enumerate(items):
        b += text(x + bw / 2, 20, it.get("lab", ""), "slotlab")
        b += f'<rect x="{x}" y="28" width="{bw}" height="50" rx="8" class="slot {it.get("cls", "")}"/>'
        b += text(x + bw / 2, 63, it.get("n", ""), "slotn")
        if it.get("chips"):
            for j, (cl, st) in enumerate(it["chips"]):
                r, c = divmod(j, 3)
                b += chip(x + 2 + c * 24, 86 + r * 22, cl, st, w=22, h=18)
        if i < n - 1:
            b += text(x + bw + gap / 2, 62, ops[i], "op")
        x += bw + gap
    if result is not None:
        b += text(x - gap / 2, 62, "=", "op")
        b += f'<rect x="{x}" y="28" width="{rw}" height="50" rx="8" class="result"/>'
        b += text(x + rw / 2, 63, result, "slotn")
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


# ---------------------------------------------------------------- big arithmetic line
def calc(parts, label="calculation", crossed=False, note=None, plain_last=False):
    """parts: list of strings; operators are drawn plain, numbers in boxes. Last part boxed as result."""
    widths = [max(30, 13 * len(str(p)) + 18) for p in parts]
    W = sum(widths) + 8 * len(parts) + 20
    H = 70 + (22 if note else 0)
    x = 10
    b = ""
    ops = {"×", "÷", "=", "+", "−", "→", "·", "/"}
    for i, p in enumerate(parts):
        w = widths[i]
        if p in ops:
            b += text(x + w / 2, 44, p, "op")
        else:
            cls = "result" if (i == len(parts) - 1 and not plain_last) else "numbox"
            b += f'<rect x="{x}" y="16" width="{w}" height="40" rx="7" class="{cls}"/>'
            b += text(x + w / 2, 43, p, "calcn")
        x += w + 8
    if crossed:
        b += f'<line x1="6" y1="60" x2="{W - 6}" y2="12" class="strike banned big"/>'
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


# ---------------------------------------------------------------- bundle (signature visual)
def bundle(orders, group, label="bundle", paint=True, cols=None, note=None, collapsed=True):
    """orders: list of tuples of item labels (each an ordered list). They slide into one group box."""
    n = len(orders)
    cols = cols or (1 if n <= 6 else 2)
    per = (n + cols - 1) // cols
    k = len(orders[0])
    cw = 22
    cardw = k * (cw + 2) + 10
    W = cols * (cardw + 10) + 180
    H = max(per * 30 + 20, 110) + (22 if note else 0)
    b = ""
    items = sorted(set(x for o in orders for x in o))
    pmap = {it: PAINT[i % len(PAINT)] for i, it in enumerate(items)}
    for i, o in enumerate(orders):
        c, r = divmod(i, per)
        x0, y0 = 10 + c * (cardw + 10), 12 + r * 30
        b += f'<rect x="{x0}" y="{y0}" width="{cardw}" height="24" rx="5" class="card"/>'
        for j, it in enumerate(o):
            b += chip(x0 + 5 + j * (cw + 2), y0 + 3, it, "", w=cw, h=18, paint=pmap[it] if paint else None)
    gx = 10 + cols * (cardw + 10) + 34
    mid = (H - (22 if note else 0)) / 2
    mk = _mid("ah")
    b += f'<path d="M{gx - 30} {mid} L{gx - 6} {mid}" class="arrow" marker-end="url(#{mk})"/>'
    b += (f'<defs><marker id="{mk}" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" '
          'orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10z" class="ahead"/></marker></defs>')
    gw = max(120, k * 30 + 30)
    b += f'<rect x="{gx}" y="{mid - 30}" width="{gw}" height="60" rx="14" class="groupbox"/>'
    b += text(gx + gw / 2, mid - 36, "one group" if collapsed else "", "cap")
    b += text(gx + gw / 2, mid + 7, "{ " + ", ".join(group) + " }", "groupt")
    b += text(gx + gw / 2, mid + 48, f"{n} lists → 1", "cap")
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


# ---------------------------------------------------------------- pick grid
def pickgrid(labels, stage="twins", hl=None, label="pick grid", plain=False, note=None):
    """stages: empty | filled | diagonal | twins. plain=True: no twins (ordered pairs, all count).
    Cells carry data-r / data-c so grid.js can light a cell's twin on hover."""
    n = len(labels)
    cs = 34 if n <= 6 else (28 if n <= 8 else 24)
    off = 44
    W = off + n * cs + 16
    H = off + n * cs + 16 + (22 if note else 0)
    b = text(off + n * cs / 2, 14, "second pick →", "cap")
    b += text(12, off + n * cs / 2, "first pick ↓", "cap vert", anchor="middle")
    for i, l in enumerate(labels):
        b += text(off + i * cs + cs / 2, off - 8, l, "gridlab")
        b += text(off - 10, off + i * cs + cs / 2 + 5, l, "gridlab")
    for r in range(n):
        for c in range(n):
            x, y = off + c * cs, off + r * cs
            cls = "pg-cell"
            content = ""
            if stage != "empty":
                content = labels[r] + labels[c]
            if stage in ("diagonal", "twins") and r == c:
                cls += " diag"
            if stage == "twins" and not plain and r > c:
                cls += " lower"
            if hl and (r, c) in hl:
                cls += " hl"
            b += (f'<rect x="{x}" y="{y}" width="{cs}" height="{cs}" class="{cls}" data-r="{r}" data-c="{c}" '
                  f'tabindex="-1"/>')
            if content:
                tcls = "pgt" + (" dim" if ("lower" in cls or "diag" in cls) else "")
                b += text(x + cs / 2, y + cs / 2 + 4, content, tcls, size=(11 if cs >= 30 else 9))
            if stage in ("diagonal", "twins") and r == c:
                b += f'<line x1="{x + 4}" y1="{y + cs - 4}" x2="{x + cs - 4}" y2="{y + 4}" class="strike banned"/>'
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label, cls="pickgrid" + (" plain" if plain else ""))


# ---------------------------------------------------------------- trees
def tree(root_children, label="tree", note=None, leaf_w=40, counts=None):
    """root_children: nested list of (label, children). Leaves laid left to right, levels downward.
    counts: optional list of per-level branch-count labels drawn at the left margin."""
    def depth(nodes):
        return 1 + max((depth(c) for _, c in nodes if c), default=0) if nodes else 0
    D = depth(root_children)
    counter = [0]

    def lay(nodes, lvl):
        out = []
        for lab, ch in nodes:
            kids = lay(ch, lvl + 1) if ch else []
            if kids:
                cx = sum(k[0] for k in kids) / len(kids)
            else:
                cx = 0
                cx = counter[0]
                counter[0] += 1
            out.append([cx, lvl, lab, kids])
        return out

    laid = lay(root_children, 1)
    nleaf = counter[0]
    left = 70 if counts else 10
    W = max(nleaf * leaf_w + left + 10, 180)
    lev_h = 50
    H = 26 + D * lev_h + 26 + (22 if note else 0)
    X = lambda c: left + c * leaf_w + leaf_w / 2
    Y = lambda l: 22 + l * lev_h
    rootx = (X(0) + X(nleaf - 1)) / 2

    def draw(nodes, px, py):
        s = ""
        for cx, lvl, lab, kids in nodes:
            s += f'<line x1="{px}" y1="{py}" x2="{X(cx)}" y2="{Y(lvl) - 13}" class="edge"/>'
            s += f'<rect x="{X(cx) - leaf_w / 2 + 3}" y="{Y(lvl) - 12}" width="{leaf_w - 6}" height="20" rx="5" class="tnode"/>'
            s += text(X(cx), Y(lvl) + 3, lab, "nodet")
            s += draw(kids, X(cx), Y(lvl) + 8)
        return s

    b = f'<circle cx="{rootx}" cy="{Y(0) + 8}" r="5" class="node root"/>'
    b += draw(laid, rootx, Y(0) + 12)
    if counts:
        for i, c in enumerate(counts):
            b += text(8, Y(i + 1) + 4, c, "cap", anchor="start")
    b += text(W / 2, H - (28 if note else 8), f"{nleaf} leaves", "cap")
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


def counts_tree(level_counts, label="tree", note=None, unequal=None):
    """Compact tree that labels branch counts per level. level_counts: e.g. [3, 2]."""
    # build actual nested structure with letter labels per level
    def build(lv):
        if lv == len(level_counts):
            return None
        n = level_counts[lv]
        return [(chr(65 + i) if lv == 0 else str(i + 1), build(lv + 1)) for i in range(n)]
    return tree(build(0), label=label, note=note)


# ---------------------------------------------------------------- letter tiles
def tiles(words, label="tiles", note=None, gap_rows=10, highlight_rows=None):
    """words: list of lists of (char, sub, paint) tuples."""
    tw = 30
    W = max(len(w) for w in words) * (tw + 4) + 20
    H = len(words) * (tw + gap_rows) + 10 + (22 if note else 0)
    b = ""
    for r, w in enumerate(words):
        y = 8 + r * (tw + gap_rows)
        if highlight_rows and r in highlight_rows:
            b += f'<rect x="4" y="{y - 3}" width="{W - 8}" height="{tw + 6}" rx="6" class="rowhl"/>'
        for c, (ch, sub, paint) in enumerate(w):
            x = 10 + c * (tw + 4)
            b += f'<rect x="{x}" y="{y}" width="{tw}" height="{tw}" rx="5" class="tile {paint or ""}"/>'
            b += f'<text x="{x + tw / 2}" y="{y + tw / 2 + 6}" class="tilet" text-anchor="middle">{tspan_sub(ch, sub)}</text>'
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


def collapse(painted_rows, real, label="copies collapse", note=None):
    """Painted copies (list of lists of (char, sub, paint)) bracket into one real word."""
    tw = 26
    k = len(painted_rows[0])
    colw = k * (tw + 3) + 14
    rows = len(painted_rows)
    W = colw + 90 + len(real) * (tw + 3) + 16
    H = max(rows * (tw + 8) + 16, 90) + (22 if note else 0)
    b = ""
    for r, w in enumerate(painted_rows):
        y = 8 + r * (tw + 8)
        for c, (ch, sub, paint) in enumerate(w):
            x = 10 + c * (tw + 3)
            b += f'<rect x="{x}" y="{y}" width="{tw}" height="{tw}" rx="4" class="tile {paint or ""}"/>'
            b += f'<text x="{x + tw / 2}" y="{y + tw / 2 + 5}" class="tilet sm" text-anchor="middle">{tspan_sub(ch, sub)}</text>'
    top, bot = 8, 8 + rows * (tw + 8) - 8
    bx = colw + 4
    b += f'<path d="M{bx} {top} q10 0 10 10 L{bx + 10} {(top + bot) / 2 - 8} q0 8 10 8 q-10 0 -10 8 L{bx + 10} {bot - 10} q0 10 -10 10" class="brace"/>'
    mid = (top + bot) / 2
    mk = _mid("ac")
    b += f'<path d="M{bx + 26} {mid} L{bx + 58} {mid}" class="arrow" marker-end="url(#{mk})"/>'
    b += (f'<defs><marker id="{mk}" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" '
          'orient="auto"><path d="M0 0 L10 5 L0 10z" class="ahead"/></marker></defs>')
    x0 = bx + 66
    for c, ch in enumerate(real):
        b += f'<rect x="{x0 + c * (tw + 3)}" y="{mid - tw / 2}" width="{tw}" height="{tw}" rx="4" class="tile real"/>'
        b += text(x0 + c * (tw + 3) + tw / 2, mid + 5, ch, "tilet sm")
    b += text(x0 + len(real) * (tw + 3) / 2, mid + tw / 2 + 16, f"{rows} → 1", "cap")
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


# ---------------------------------------------------------------- dots and lines
def dots(points, lines=(), hl=(), label="dots and lines", note=None, W=240, H=200, labels=True, hl2=()):
    """points: dict name -> (x, y) in viewBox units. lines: list of (a, b). hl: highlighted lines."""
    b = ""
    for a, c in lines:
        (x1, y1), (x2, y2) = points[a], points[c]
        b += f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" class="seg"/>'
    for a, c in hl2:
        (x1, y1), (x2, y2) = points[a], points[c]
        b += f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" class="seg hl2"/>'
    for a, c in hl:
        (x1, y1), (x2, y2) = points[a], points[c]
        b += f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" class="seg hl"/>'
    for name, (x, y) in points.items():
        b += f'<circle cx="{x}" cy="{y}" r="5" class="dot"/>'
        if labels:
            b += text(x + 10, y - 8, name, "dotlab", anchor="start")
    if note:
        H2 = H + 22
        b += text(W / 2, H2 - 6, note, "cap")
        return svg(W, H2, b, label)
    return svg(W, H, b, label)


def polygon_points(n, r=80, cx=120, cy=100, names=None):
    import math
    names = names or [chr(65 + i) for i in range(n)]
    return {names[i]: (round(cx + r * math.sin(2 * math.pi * i / n), 1),
                       round(cy - r * math.cos(2 * math.pi * i / n), 1)) for i in range(n)}


CUBE = {  # 2D projection of {0,1}^3 ; label = coordinates letter
    "A": (40, 150), "B": (140, 150), "C": (140, 50), "D": (40, 50),
    "E": (90, 120), "F": (190, 120), "G": (190, 20), "H": (90, 20),
}
CUBE_EDGES = [("A", "B"), ("B", "C"), ("C", "D"), ("D", "A"), ("E", "F"), ("F", "G"), ("G", "H"), ("H", "E"),
              ("A", "E"), ("B", "F"), ("C", "G"), ("D", "H")]


def cube(hl=(), hl2=(), label="cube", note=None):
    pts = {k: (x + 20, y + 16) for k, (x, y) in CUBE.items()}
    return dots(pts, CUBE_EDGES, hl, label, note, W=250, H=190, hl2=hl2)


# ---------------------------------------------------------------- lattice grid
def lattice(w, h, path=None, marks=None, legs=None, label="grid", note=None, cell=None, legend=None):
    """w x h cells. path: U/R string from (0,0). legs: list of (start, string, cls).
    marks: dict name -> (x, y) lattice coords."""
    cell = cell or (28 if max(w, h) <= 6 else 22)
    pad = 24
    W = w * cell + 2 * pad + 10
    H = h * cell + 2 * pad + (22 if note else 0)
    X = lambda x: pad + x * cell
    Y = lambda y: pad + (h - y) * cell
    b = ""
    for i in range(w + 1):
        b += f'<line x1="{X(i)}" y1="{Y(0)}" x2="{X(i)}" y2="{Y(h)}" class="gl"/>'
    for j in range(h + 1):
        b += f'<line x1="{X(0)}" y1="{Y(j)}" x2="{X(w)}" y2="{Y(j)}" class="gl"/>'

    def draw_path(start, s, cls):
        x, y = start
        d = f"M{X(x)} {Y(y)}"
        for ch in s:
            if ch == "R":
                x += 1
            else:
                y += 1
            d += f" L{X(x)} {Y(y)}"
        return f'<path d="{d}" class="path {cls}"/>'

    if path:
        b += draw_path((0, 0), path, "leg1")
    for start, s, cls in (legs or []):
        b += draw_path(start, s, cls)
    for name, (x, y) in (marks or {}).items():
        b += f'<circle cx="{X(x)}" cy="{Y(y)}" r="5" class="dot"/>'
        b += text(X(x) - 9, Y(y) + 15, name, "dotlab", anchor="end")
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


def word_strip(word, label="move word", cls_map=None, note=None):
    cls_map = cls_map or {"U": "p2", "R": "p1"}
    tw = 22
    W = len(word) * (tw + 3) + 20
    H = 40 + (22 if note else 0)
    b = ""
    for i, ch in enumerate(word):
        x = 10 + i * (tw + 3)
        b += f'<rect x="{x}" y="8" width="{tw}" height="{tw}" rx="4" class="tile {cls_map.get(ch, "")}"/>'
        b += text(x + tw / 2, 8 + tw / 2 + 5, ch, "tilet sm")
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


# ---------------------------------------------------------------- skewed grid (parallelograms)
def skew_grid(cols, rows, hl_v=(), hl_h=(), label="slanted grid", note=None, number=False):
    s = 34
    sh = 0.4
    pad = 16
    W = cols * s + rows * s * sh + 2 * pad + 20
    H = rows * s + 2 * pad + (22 if note else 0) + (16 if number else 0)
    P = lambda i, j: (pad + i * s + j * s * sh, pad + (rows - j) * s)
    b = ""
    for i in range(cols + 1):
        (x1, y1), (x2, y2) = P(i, 0), P(i, rows)
        cls = "gl hlv" if i in hl_v else "gl"
        b += f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" class="{cls}"/>'
        if number:
            b += text(x1, y1 + 16, str(i + 1), "cap")
    for j in range(rows + 1):
        (x1, y1), (x2, y2) = P(0, j), P(cols, j)
        cls = "gl hlh" if j in hl_h else "gl"
        b += f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" class="{cls}"/>'
        if number:
            b += text(x1 - 8, y1 + 4, str(j + 1), "cap", anchor="end")
    if len(hl_v) == 2 and len(hl_h) == 2:
        (a, c), (d, e) = sorted(hl_v), sorted(hl_h)
        pts = [P(a, d), P(c, d), P(c, e), P(a, e)]
        b = (f'<polygon points="{" ".join(f"{x},{y}" for x, y in pts)}" class="shade"/>') + b
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


# ---------------------------------------------------------------- bags / teams
def bags(groups, label="bags", note=None, pool=None, pool_states=None):
    """groups: list of (title, items, cap). pool: optional list shown on top with states."""
    bw = 104
    W = len(groups) * (bw + 14) + 16
    top = 0
    b = ""
    if pool:
        per = max(1, (W - 12) // 30)
        rows = (len(pool) + per - 1) // per
        for i, it in enumerate(pool):
            r, c = divmod(i, per)
            b += chip(8 + c * 30, 6 + r * 28, it, (pool_states or {}).get(it, ""), w=26, h=22)
        top = rows * 28 + 12
    H = top + 136 + (22 if note else 0)
    for g, (title, items, cap) in enumerate(groups):
        x = 8 + g * (bw + 14)
        y = top + 18
        b += text(x + bw / 2, top + 12, title, "slotlab")
        b += (f'<path d="M{x + 8} {y} L{x + bw - 8} {y} Q{x + bw} {y + 80} {x + bw / 2} {y + 92} '
              f'Q{x} {y + 80} {x + 8} {y} Z" class="bag"/>')
        for i, it in enumerate(items):
            r, c = divmod(i, 3)
            b += chip(x + 12 + c * 28, y + 10 + r * 26, it, "picked", w=24, h=20)
        if cap is not None:
            b += text(x + bw / 2, y + 108, f"holds {cap}", "cap")
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


def same_split(split_a, split_b, label="same split", note=None, same=True):
    """Two pictures of a split inside one oval with '=' between them."""
    def mini(x, groups):
        s = ""
        for g, items in enumerate(groups):
            gx = x + g * 92
            s += (f'<path d="M{gx + 6} 30 L{gx + 80} 30 Q{gx + 88} 96 {gx + 43} 104 Q{gx - 2} 96 {gx + 6} 30Z" '
                  f'class="bag"/>')
            per = 3
            for i, it in enumerate(items):
                r, c = divmod(i, per)
                s += chip(gx + 8 + c * 24, 38 + r * 22, it, "picked", w=22, h=18)
        return s
    wa = len(split_a) * 92
    W = wa * 2 + 60
    H = 130 + (22 if note else 0)
    b = f'<ellipse cx="{W / 2}" cy="68" rx="{W / 2 - 4}" ry="62" class="oval {"" if same else "diff"}"/>'
    b += mini(16, split_a) + text(W / 2, 74, "=" if same else "≠", "op big") + mini(W / 2 + 14, split_b)
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


# ---------------------------------------------------------------- outcome list
def outcome_list(items, label="list", cols=None, note=None, hl=None, struck=None, cellw=None):
    hl = set(hl or [])
    struck = set(struck or [])
    cols = cols or min(len(items), 6)
    cw = cellw or max(44, 10 * max(len(str(i)) for i in items) + 16)
    rows = (len(items) + cols - 1) // cols
    W = cols * (cw + 6) + 14
    H = rows * 30 + 12 + (22 if note else 0)
    b = ""
    for i, it in enumerate(items):
        r, c = divmod(i, cols)
        x, y = 8 + c * (cw + 6), 6 + r * 30
        cls = "lcell" + (" hl" if i in hl or it in hl else "") + (" struck" if i in struck or it in struck else "")
        b += f'<rect x="{x}" y="{y}" width="{cw}" height="24" rx="5" class="{cls}"/>'
        b += text(x + cw / 2, y + 17, it, "lt")
        if "struck" in cls:
            b += f'<line x1="{x + 3}" y1="{y + 20}" x2="{x + cw - 3}" y2="{y + 4}" class="strike banned"/>'
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


# ---------------------------------------------------------------- simple word card
def card(lines, label="card", tone="", W=300, note=None, strike=False):
    W = max(W, int(max(len(str(l)) for l in lines) * 8.6) + 40)
    H = 26 * len(lines) + 30 + (22 if note else 0)
    b = f'<rect x="4" y="4" width="{W - 8}" height="{26 * len(lines) + 22}" rx="10" class="wcard {tone}"/>'
    for i, ln in enumerate(lines):
        b += text(W / 2, 32 + i * 26, ln, "cardt")
    if strike:
        b += f'<line x1="14" y1="{26 * len(lines) + 16}" x2="{W - 14}" y2="14" class="strike banned big"/>'
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


def skip_pic(reason):
    return card(["not needed here"], "step not needed: " + reason, tone="skip", W=260)


# ---------------------------------------------------------------- coins
def coins(stack, label="coin stack", note=None, bad=None):
    """stack: list bottom->top of (colour 'G'|'S', up True/False). bad: index i where coin i (up) sits under i+1 (down)."""
    W, cw, ch = 150, 96, 18
    H = len(stack) * (ch + 4) + 20 + (22 if note else 0)
    b = ""
    for i, (col, up) in enumerate(stack):
        y = H - (22 if note else 0) - 14 - (i + 1) * (ch + 4)
        cls = "coin gold" if col == "G" else "coin silver"
        b += f'<rect x="{(W - cw) / 2}" y="{y}" width="{cw}" height="{ch}" rx="9" class="{cls}"/>'
        b += text(W / 2 - 24, y + 13, col, "coint")
        b += text(W / 2 + 22, y + 13, "▲ up" if up else "▼ down", "coint")
        if bad is not None and i in (bad, bad + 1):
            b += f'<rect x="{(W - cw) / 2 - 4}" y="{y - 2}" width="{cw + 8}" height="{ch + 4}" rx="10" class="badring"/>'
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


# ---------------------------------------------------------------- states with two members
def states(n, picked=None, chosen=None, label="states", note=None, names=None):
    """n state cards; picked: set of state indices; chosen: dict state -> 0/1 member."""
    picked = set(picked or [])
    chosen = chosen or {}
    names = names or [f"S{i + 1}" for i in range(n)]
    bw = 64
    per = min(n, 5)
    rows = (n + per - 1) // per
    W = per * (bw + 8) + 12
    H = rows * 66 + 10 + (22 if note else 0)
    b = ""
    for i in range(n):
        r, c = divmod(i, per)
        x, y = 8 + c * (bw + 8), 6 + r * 66
        b += f'<rect x="{x}" y="{y}" width="{bw}" height="58" rx="8" class="state {"picked" if i in picked else ""}"/>'
        b += text(x + bw / 2, y + 15, names[i], "cap")
        for m in range(2):
            st = ""
            if i in chosen:
                st = "picked" if chosen[i] == m else "used"
            b += chip(x + 6 + m * 28, y + 24, "AB"[m], st, w=24, h=22)
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


# ---------------------------------------------------------------- people / kids with items
def assign(people, items_by_person, label="assignment", note=None):
    pw = 84
    W = len(people) * (pw + 8) + 12
    H = 112 + (22 if note else 0)
    b = ""
    for i, p in enumerate(people):
        x = 8 + i * (pw + 8)
        b += f'<circle cx="{x + pw / 2}" cy="22" r="14" class="person"/>'
        b += text(x + pw / 2, 27, p[0], "persont")
        b += text(x + pw / 2, 52, p, "cap")
        for j, it in enumerate(items_by_person.get(p, [])):
            b += chip(x + 4, 58 + j * 24, it, "picked", w=pw - 8, h=20)
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)


# ---------------------------------------------------------------- table (HTML)
def table(headers, rows, hl=None, cls=""):
    h = "".join(f"<th>{esc(x)}</th>" for x in headers)
    body = ""
    for i, r in enumerate(rows):
        rc = ' class="hl"' if hl is not None and (i == hl or (isinstance(hl, (set, list, tuple)) and i in hl)) else ""
        body += f"<tr{rc}>" + "".join(f"<td>{esc(x)}</td>" for x in r) + "</tr>"
    return f'<table class="ptable {cls}"><thead><tr>{h}</tr></thead><tbody>{body}</tbody></table>'


def hstack(*parts):
    return '<div class="hstack">' + "".join(parts) + "</div>"


def vstack(*parts):
    return '<div class="vstack">' + "".join(parts) + "</div>"


def bag_of(items, picked=(), label="bag", note=None):
    """A drawstring bag holding chips; picked ones lifted (highlighted)."""
    per = 5
    rows = (len(items) + per - 1) // per
    W = per * 34 + 50
    H = rows * 30 + 70 + (22 if note else 0)
    b = (f'<path d="M20 30 Q{W / 2} 18 {W - 20} 30 Q{W - 4} {H - (22 if note else 0) - 8} {W / 2} '
         f'{H - (22 if note else 0) - 6} Q4 {H - (22 if note else 0) - 8} 20 30Z" class="bag"/>')
    for i, it in enumerate(items):
        r, c = divmod(i, per)
        b += chip(25 + c * 34, 40 + r * 30, it, "picked" if it in picked else "", w=30, h=24)
    if note:
        b += text(W / 2, H - 6, note, "cap")
    return svg(W, H, b, label)
