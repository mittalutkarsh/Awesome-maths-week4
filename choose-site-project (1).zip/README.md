# Choose Function site (AwesomeMath Level 1, week 4)

Rebuild: `python3 build.py` → writes out/index.html, out/choose-notes.html, out/choose-lesson.html, out/choose-practice.html.
Publish: copy those four files to the root of a GitHub Pages repo (relative links only).

src/answers_bruteforce.py  every answer by brute force AND by argument (build stops on any mismatch)
src/visuals.py             SVG primitives (slots, chips, bundle, pick grid, trees, tiles, grids, bags, coins...)
src/stories.py, pcommon.py story frames, verification log, worked-story templates
src/problems_lesson.py     9 guided problems (from class)      src/problems_practice.py  PS4 #1-18 + 3 challenge
src/concepts.py            plan story + 9 concept stories       src/notes.py              traps, cheat sheet, glossary, habits, rules card
assets/*.js|css            checker, workbench, story, pick grid, pen, sandbox-safe helpers, style
tests/                     audit_leak.py, run_passes.py, structure.py, contact.py (contact sheets)
