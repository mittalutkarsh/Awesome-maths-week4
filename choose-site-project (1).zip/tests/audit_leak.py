"""Leakage audit: does any text visible before the hint (or on the same default screen) give away a step's answer?

Searched, per step: question, three nudges, hint, placeholder, named-error messages, generic messages;
plus default-visible text on the same screen: the Concept tab (lesson) or the Rules card (practice).
Looked for: the step's answer as a numeral, in comma form, as a number word, or as any expression that evaluates to it.
"""
import json
import re
import sys
from fractions import Fraction
from math import comb, factorial

sys.path.insert(0, "/home/claude/site/src")
OUT = "/home/claude/site/out/"
import notes  # noqa: E402

WORDS = {0: "zero", 1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight", 9: "nine", 10: "ten",
         11: "eleven", 12: "twelve", 13: "thirteen", 14: "fourteen", 15: "fifteen", 16: "sixteen", 17: "seventeen", 18: "eighteen",
         19: "nineteen", 20: "twenty", 21: "twenty-one", 26: "twenty-six", 28: "twenty-eight", 30: "thirty", 35: "thirty-five",
         56: "fifty-six", 66: "sixty-six", 84: "eighty-four", 120: "one hundred twenty", 126: "one hundred twenty-six"}


def strip(h):
    h = re.sub(r"<svg.*?</svg>", lambda m: " ".join(re.findall(r">([^<>]+)<", m.group(0))), h, flags=re.S)
    return re.sub(r"<[^>]+>", " ", h)


TOK = re.compile(r"\d[\d,]*(?:\.\d+)?|choose|[×x\*·÷/\^!+\-−()]")


def tokens(t):
    t = t.replace("−", "-")
    out = []
    for m in TOK.finditer(t):
        out.append((m.group(0), m.start(), m.end()))
    return out


def ev(toks):
    """Evaluate a token list; None if invalid."""
    s = ""
    for tk, _, _ in toks:
        if tk[0].isdigit():
            s += " (" + tk.replace(",", "") + ") "
        elif tk in "×x*·":
            s += "*"
        elif tk in "÷/":
            s += "/"
        elif tk == "^":
            s += "**"
        elif tk == "!":
            s = re.sub(r"\((\d+)\)\s*$", lambda m: f"({factorial(int(m.group(1)))})", s)
            if not s.endswith(") "):
                return None
        elif tk == "choose":
            s += "@"
        else:
            s += tk
    if "@" in s:
        m = re.fullmatch(r"\s*\((\d+)\)\s*@\s*\((\d+)\)\s*", s)
        if not m:
            return None
        return Fraction(comb(int(m.group(1)), int(m.group(2))))
    if re.search(r"\*\*\s*\(\d{4,}", s):
        return None
    try:
        v = eval(re.sub(r"\((\d+)\)", r"Fraction(\1)", s), {"Fraction": Fraction})
        return Fraction(v)
    except Exception:
        return None


def hits_for(text, ans):
    """Return list of (kind, snippet) where text gives `ans`."""
    found = []
    t = strip(text)
    a = int(ans)
    for m in re.finditer(r"(?<![\d,.])\d[\d,]*(?![\d,]*\d)", t):
        if m.group(0).replace(",", "") == str(a):
            found.append(("numeral", t[max(0, m.start() - 30):m.end() + 30]))
    if a in WORDS and re.search(r"\b" + re.escape(WORDS[a]) + r"\b", t.lower()):
        found.append(("word", WORDS[a]))
    tk = tokens(t)
    n = len(tk)
    for i in range(n):
        for j in range(i + 2, min(n, i + 12) + 1):
            window = tk[i:j]
            if not any(x[0] in "×x*·÷/^!+-−" or x[0] == "choose" for x in window):
                continue
            if not (window[0][0][0].isdigit() or window[0][0] == "("):
                continue
            # contiguous in the original text (only spaces between tokens)
            ok = all(re.fullmatch(r"[\s]*", t[window[k][2]:window[k + 1][1]]) for k in range(len(window) - 1))
            if not ok:
                continue
            v = ev(window)
            if v is not None and v == a:
                found.append(("expression", t[window[0][1]:window[-1][2]]))
    # de-duplicate
    seen, out = set(), []
    for k, sn in found:
        if (k, sn) not in seen:
            seen.add((k, sn))
            out.append((k, sn))
    return out


def main():
    report = []
    for page in ("lesson", "practice"):
        d = json.load(open(OUT + f"data_{page}.json"))
        for p in d["problems"]:
            screen = d["concepts"][p["concept"]] if page == "lesson" else notes.RULES_CARD
            for si, st in enumerate(p["steps"]):
                answers = st["ans"] if isinstance(st["ans"], list) else [st["ans"]]
                fields = {"question": st["q"], "placeholder": st["ph"], "hint": st["hint"]}
                for k, nd in enumerate(st["nudges"]):
                    fields[f"nudge{k + 1}"] = nd
                for key, msg in st["named"].items():
                    fields[f"named[{key}]"] = msg
                fields["default-screen"] = screen
                for name, txt in fields.items():
                    if isinstance(st["ans"], list):
                        pair = st["ans"]
                        pat = re.compile(r"\b%d\b\D{0,12}\b%d\b" % (pair[0], pair[1]))
                        if pat.search(strip(txt)):
                            report.append((page, p["id"], si + 1, name, "pair", pat.search(strip(txt)).group(0)))
                        continue
                    for kind, sn in hits_for(txt, answers[0]):
                        report.append((page, p["id"], si + 1, name, kind, sn.strip()))
    print(f"HITS: {len(report)}")
    for r in report:
        print(" | ".join(str(x) for x in r))
    json.dump(report, open("/home/claude/site/tests/leak_report.json", "w"), indent=1)


if __name__ == "__main__":
    main()
