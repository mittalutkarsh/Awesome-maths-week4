import sys
from playwright.sync_api import sync_playwright
pages = sys.argv[1:] or ["index.html","choose-notes.html","choose-lesson.html","choose-practice.html"]
with sync_playwright() as p:
    b = p.chromium.launch()
    for name in pages:
        pg = b.new_page(viewport={"width":1400,"height":900})
        errs=[]
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append("console:"+m.text) if m.type=="error" else None)
        pg.goto("file:///home/claude/site/out/"+name)
        pg.wait_for_timeout(400)
        pg.screenshot(path=f"/home/claude/site/tests/{name}.png")
        print(name, "errors:", [e for e in errs if "fonts" not in e][:5])
    b.close()
