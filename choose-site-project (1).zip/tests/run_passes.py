"""Scripted passes in headless Chromium.
Environments: normal file:// page; with confirm() and history.replaceState throwing; inside a sandboxed srcdoc iframe."""
import json
import sys
from playwright.sync_api import sync_playwright

OUT = "/home/claude/site/out/"
THROW = "window.confirm=()=>{throw new Error('confirm blocked')};window.alert=()=>{throw new Error('alert blocked')};" \
        "window.prompt=()=>{throw new Error('prompt blocked')};history.replaceState=()=>{throw new Error('replaceState blocked')};"


def fmt(ans):
    return f"{ans[0]} and {ans[1]}" if isinstance(ans, list) else str(ans)


def wrong(ans):
    return str(int(ans) * 7 + 3)


class Env:
    def __init__(self, browser, mode):
        self.mode = mode
        self.errors = []
        self.page = browser.new_page(viewport={"width": 1400, "height": 900}, accept_downloads=True)
        self.page.on("pageerror", lambda e: self.errors.append(str(e)))
        if mode == "throwing":
            self.page.add_init_script(THROW)

    def open(self, name, hash_=""):
        if self.mode == "sandbox":
            html = open(OUT + name, encoding="utf-8").read()
            self.page.set_content("<html><body style='margin:0'><iframe id=f sandbox='allow-scripts allow-downloads' "
                                  "style='border:0;width:1400px;height:900px'></iframe></body></html>")
            self.page.evaluate("h => document.getElementById('f').srcdoc = h", html)
            self.page.wait_for_timeout(700)
            fr = [f for f in self.page.frames if f != self.page.main_frame][0]
            fr.on = None
            self.f = fr
        else:
            self.page.goto("file://" + OUT + name + (("#" + hash_) if hash_ else ""))
            self.page.wait_for_timeout(300)
            self.f = self.page.main_frame
        return self.f


def pass_workbench(env, page):
    f = env.open(f"choose-{page}.html")
    data = json.load(open(OUT + f"data_{page}.json"))
    res = {"problems": 0, "steps_ok": 0, "verified_shown": 0, "stories": 0, "advanced": 0}
    for p in data["problems"]:
        f.evaluate("id => BENCH.select(id)", p["id"])
        for i, st in enumerate(p["steps"]):
            cur_before = f.evaluate("() => BENCH.state[BENCH.current()].cur")
            f.fill("#answer", fmt(st["ans"]))
            f.click("#check")
            s = f.evaluate("i => BENCH.state[BENCH.current()].steps[i].state", i)
            if s == "ok":
                res["steps_ok"] += 1
            cur_after = f.evaluate("() => BENCH.state[BENCH.current()].cur")
            if i < len(p["steps"]) - 1 and cur_after != cur_before:
                res["advanced"] += 1
        f.click("#submit")
        if f.query_selector("#verified"):
            res["verified_shown"] += 1
        if f.query_selector("#verified .story .frame"):
            res["stories"] += 1
        res["problems"] += 1
    res["multi_step_transitions_expected"] = sum(len(p["steps"]) - 1 for p in data["problems"])
    res["steps_total"] = sum(len(p["steps"]) for p in data["problems"])
    res["finished_counter"] = f.inner_text("#finished")
    return res


def pass_miss4(env):
    f = env.open("choose-practice.html")
    f.evaluate("() => BENCH.select('ps18')")
    st = json.load(open(OUT + "data_practice.json"))["problems"]
    ps18 = [p for p in st if p["id"] == "ps18"][0]
    logs = []
    for k in range(4):
        f.fill("#answer", wrong(ps18["steps"][0]["ans"]))
        f.click("#check")
        logs.append(f.evaluate("() => document.getElementById('console').innerText"))
    state = f.evaluate("() => BENCH.state.ps18.steps[0]")
    cur = f.evaluate("() => BENCH.state.ps18.cur")
    text = logs[-1]
    return {"misses": state["misses"], "state": state["state"], "nudges_logged": sum(n[:25] in text for n in ps18["steps"][0]["nudges"]),
            "final_attempt_msg": "One final attempt" in logs[2], "handover_msg": "Handing over step 1" in text, "moved_to_step": cur + 1,
            "next_step_still_open": f.evaluate("() => BENCH.state.ps18.steps[1].state") == "open"}


def pass_hint(env):
    f = env.open("choose-lesson.html")
    f.evaluate("() => BENCH.select('l4')")
    f.fill("#answer", "999")
    f.click("#check")
    tries_before = f.evaluate("() => BENCH.state.l4.steps[0].tries")
    f.click("#hint")
    open_ = f.evaluate("() => document.getElementById('hintDialog').classList.contains('open')")
    body = f.inner_text("#hintBody")
    f.press("#hintClose", "Escape")
    closed = not f.evaluate("() => document.getElementById('hintDialog').classList.contains('open')")
    return {"dialog_opened": open_, "hint_text": body[:40], "escape_closed": closed,
            "tries_unchanged": f.evaluate("() => BENCH.state.l4.steps[0].tries") == tries_before,
            "hint_recorded": f.evaluate("() => BENCH.state.l4.steps[0].hints")}


def pass_reveal_nav(env):
    out = {}
    f = env.open("choose-practice.html", "ps8")
    out["deep_link_selected"] = f.evaluate("() => BENCH.current()")
    f.evaluate("() => BENCH.select('ps3')")
    f.click("#reveal")
    out["first_click_confirm_note"] = bool(f.inner_text("#confirmNote").strip())
    out["revealed_after_one_click"] = f.evaluate("() => BENCH.state.ps3.revealed")
    f.click("#reveal")
    out["revealed_after_two_clicks"] = f.evaluate("() => BENCH.state.ps3.revealed")
    out["worked_story_visible"] = bool(f.query_selector("#verified .story"))
    # story controls
    f.click("#verified .story [data-act=next]")
    out["story_next_moves"] = f.evaluate("() => Array.from(document.querySelectorAll('#verified .frame')).findIndex(x=>x.classList.contains('on'))") == 1
    f.focus("#verified .story")
    f.press("#verified .story", "ArrowRight")
    out["arrow_key_moves"] = f.evaluate("() => Array.from(document.querySelectorAll('#verified .frame')).findIndex(x=>x.classList.contains('on'))") == 2
    f.check("#verified .story input.showall")
    out["show_all"] = f.evaluate("() => document.querySelector('#verified .story').classList.contains('all')")
    # Enter and Ctrl+Enter
    f.evaluate("() => BENCH.select('ps1')")
    f.fill("#answer", "720")
    f.press("#answer", "Enter")
    out["enter_checks"] = f.evaluate("() => BENCH.state.ps1.steps[0].tries") == 1
    f.fill("#work", "10 × 9 × 8 then divide")
    f.fill("#answer", "120")
    f.press("#work", "Control+Enter")
    out["ctrl_enter_checks"] = f.evaluate("() => BENCH.state.ps1.steps[0].state") == "ok"
    f.click("#next")
    out["next_button"] = f.evaluate("() => BENCH.current()") == "ps2"
    f.select_option("#psel", "ch2")
    out["dropdown"] = f.evaluate("() => BENCH.current()") == "ch2"
    f.click("#rail button[data-id='ps5']")
    out["rail"] = f.evaluate("() => BENCH.current()") == "ps5"
    out["hash_after_select"] = f.evaluate("() => location.hash")
    # answer forms
    forms = {"ps9": ["1,663,200", "12!/(2!^3*3!^2)"], "l9": ["2^5*20*49*47*46", "32 × 2,118,760", "C(50,5)*2⁵", "50 choose 5 × 32"]}
    ok = 0
    total = 0
    for pid, alts in forms.items():
        for a in alts:
            st = (json.load(open(OUT + ("data_lesson.json" if pid.startswith("l") else "data_practice.json"))))
            step = [p for p in st["problems"] if p["id"] == pid][0]["steps"][0]
            total += 1
            ok += f.evaluate("([s,a]) => CHECK.grade(s, a, []).ok", [step, a]) if pid.startswith("ps") or env.mode != "x" else 0
    out["answer_forms_ok"] = f"{ok}/{total}"
    return out


def pass_pen(env, name):
    f = env.open(name)
    pg = env.page
    out = {}
    f.evaluate("() => PEN.setOn(true)")
    def stroke(x0, y0, n=50, dx=4, dy=1, mods=None):
        if mods:
            pg.keyboard.down(mods)
        pg.mouse.move(x0, y0)
        pg.mouse.down()
        for i in range(n):
            pg.mouse.move(x0 + i * dx, y0 + (i % 7) * dy)
        pg.mouse.up()
        if mods:
            pg.keyboard.up(mods)
    count = lambda: f.evaluate("() => __PEN.strokes().length")
    for tool in ("pen", "marker", "line", "box"):
        f.evaluate("t => PEN.setTool(t)", tool)
        stroke(300, 200 + 40 * ["pen", "marker", "line", "box"].index(tool))
    out["strokes_after_4_tools"] = count()
    f.evaluate("() => PEN.setTool('pen')")
    stroke(300, 420, mods="Shift")
    out["shift_snapped_points"] = f.evaluate("() => __PEN.strokes().at(-1).pts.length")
    f.evaluate("() => PEN.setTool('eraser')")
    stroke(300, 200, n=10)
    out["after_eraser"] = count()
    f.evaluate("() => PEN.undo()")
    out["after_undo"] = count()
    f.evaluate("() => PEN.redo()")
    out["after_redo"] = count()
    f.evaluate("() => PEN.clearAll()")
    out["after_clear"] = count()
    f.evaluate("() => PEN.undo()")
    out["after_undo_clear"] = count()
    f.evaluate("() => PEN.setTool('pen')")
    # palm rejection: synthetic touch pointer events with stylus-only on
    f.evaluate("() => PEN.setStylusOnly(true)")
    before = count()
    f.evaluate("""() => { const c = document.querySelector('canvas.live');
        const ev = (t, x) => c.dispatchEvent(new PointerEvent(t, {pointerType:'touch', pointerId:9, clientX:x, clientY:500, bubbles:true}));
        ev('pointerdown', 200); for (let i=0;i<10;i++) ev('pointermove', 200+i*5); ev('pointerup', 260); }""")
    out["touch_ignored_with_stylus_only"] = count() == before
    f.evaluate("""() => { const c = document.querySelector('canvas.live');
        const ev = (t, x) => c.dispatchEvent(new PointerEvent(t, {pointerType:'pen', pointerId:8, clientX:x, clientY:520, bubbles:true}));
        ev('pointerdown', 200); for (let i=0;i<10;i++) ev('pointermove', 200+i*5); ev('pointerup', 260); }""")
    out["stylus_draws_with_stylus_only"] = count() == before + 1
    f.evaluate("() => PEN.setStylusOnly(false)")
    # export
    try:
        with pg.expect_download(timeout=3000) as d:
            f.evaluate("() => PEN.exportPng()")
        out["export"] = "download " + d.value.suggested_filename
    except Exception as e:
        out["export"] = "no download event (" + f.evaluate("() => document.querySelector('.pen-bar .note').textContent") + ")"
    # keyboard
    f.evaluate("() => PEN.setOn(false)")
    pg.mouse.click(700, 60)
    pg.keyboard.press("p")
    out["P_toggles_on"] = f.evaluate("() => PEN.isOn()")
    pg.keyboard.press("Escape")
    out["Escape_turns_off"] = not f.evaluate("() => PEN.isOn()")
    if name.endswith("practice.html") or name.endswith("lesson.html"):
        f.press("#answer", "p")
        out["P_ignored_in_input"] = not f.evaluate("() => PEN.isOn()")
        f.evaluate("() => PEN.setOn(true)")
        f.evaluate("() => PEN.clearAll()")
        first = f.evaluate("() => BENCH.current()")
        stroke(400, 300)
        n1 = count()
        f.evaluate("() => BENCH.select(BENCH.current()==='l1'?'l2':(BENCH.current()==='ps1'?'ps2':'ps1'))")
        out["ink_after_switch"] = count()
        f.evaluate("id => BENCH.select(id)", first)
        out["ink_back_on_first"] = count() == n1
        out["anchoring"] = "viewport (" + f.evaluate("() => __PEN.mode") + ")"
        out["touch_action"] = f.evaluate("() => getComputedStyle(document.querySelector('canvas.live')).touchAction")
    else:
        f.evaluate("() => PEN.setOn(true)")
        f.evaluate("() => PEN.clearAll()")
        stroke(400, 300, n=10)
        y_at_draw = f.evaluate("() => __PEN.strokes().at(-1).pts[0][1]")
        f.evaluate("() => window.scrollTo(0, 600)")
        pg.wait_for_timeout(100)
        stroke(400, 300, n=10)
        y_after = f.evaluate("() => __PEN.strokes().at(-1).pts[0][1]")
        out["page_coords_shift_with_scroll"] = round(y_after - y_at_draw)
        out["anchoring"] = "page (" + f.evaluate("() => __PEN.mode") + ")"
        out["touch_action"] = f.evaluate("() => getComputedStyle(document.querySelector('canvas.live')).touchAction")
    # performance: 40 strokes / 2000 points on the page, then draw one more
    f.evaluate("() => { PEN.clearAll(); PEN.setTool('pen'); }")
    for k in range(40):
        stroke(150 + (k % 8) * 120, 120 + (k // 8) * 120, n=50, dx=2, dy=2)
    pts = f.evaluate("() => __PEN.strokes().reduce((a,s)=>a+s.pts.length,0)")
    f.evaluate("() => { __PEN.stats.oldRedrawsWhileDrawing = 0; __PEN.stats.framesDrawing = 0; }")
    stroke(200, 700, n=80, dx=3, dy=2)
    out["perf_strokes"] = f.evaluate("() => __PEN.strokes().length")
    out["perf_points_before_last"] = pts
    out["old_strokes_redrawn_per_frame_while_drawing"] = f.evaluate("() => __PEN.stats.oldRedrawsWhileDrawing")
    out["frames_drawn"] = f.evaluate("() => __PEN.stats.framesDrawing")
    out["canvas_megapixels_total"] = round(f.evaluate("() => __PEN.megapixels()"), 2)
    out["canvas_size"] = f.evaluate("() => [document.querySelector('canvas.base').width, document.querySelector('canvas.base').height]")
    out["doc_height"] = f.evaluate("() => document.documentElement.scrollHeight")
    return out


def main():
    results = {}
    with sync_playwright() as p:
        b = p.chromium.launch()
        for mode in ("normal", "throwing", "sandbox"):
            env = Env(b, mode)
            r = {}
            r["1_lesson_all_correct"] = pass_workbench(env, "lesson")
            r["1_practice_all_correct"] = pass_workbench(env, "practice")
            r["2_miss_four_times"] = pass_miss4(env)
            r["3_hint_mid_attempt"] = pass_hint(env)
            r["4_reveal_navigation"] = pass_reveal_nav(env)
            r["5_pen_practice"] = pass_pen(env, "choose-practice.html")
            r["5_pen_notes"] = pass_pen(env, "choose-notes.html")
            r["page_errors"] = env.errors
            results[mode] = r
            env.page.close()
        b.close()
    print(json.dumps(results, indent=1, default=str))
    json.dump(results, open("/home/claude/site/tests/passes.json", "w"), indent=1, default=str)


if __name__ == "__main__":
    main()
