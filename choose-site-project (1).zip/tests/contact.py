"""Render every story frame into contact sheets: narrow (workbench middle pane, 520px) and wide (notes, 900px)."""
import json, re, sys
from playwright.sync_api import sync_playwright
OUT = "/home/claude/site/out/"
css = open("/home/claude/site/assets/style.css").read()
def frames_from_story(html):
    return re.findall(r'<figure class="frame.*?</figure>', html, flags=re.S)
items = []
for page in ("lesson", "practice"):
    d = json.load(open(OUT + f"data_{page}.json"))
    for p in d["problems"]:
        for i, f in enumerate(frames_from_story(p["story"])):
            items.append((f"{p['id']} f{i+1}", f))
    for cid, h in d.get("concepts", {}).items():
        for i, f in enumerate(frames_from_story(h)):
            items.append((f"{cid} f{i+1}", f))
notes = open(OUT + "choose-notes.html").read()
for i, f in enumerate(frames_from_story(notes.split('id="bundle"')[1].split("</section>")[0])):
    items.append((f"sig f{i+1}", f))
for i, f in enumerate(frames_from_story(notes.split('id="plan"')[1].split("</section>")[0])):
    items.append((f"plan f{i+1}", f))
import os
F=os.environ.get("ONLY")
if F:
    keep=set(F.split(","))
    items=[it for it in items if it[0] in keep]
print(len(items), "frames")
width = int(sys.argv[1]) if len(sys.argv) > 1 else 520
per = 24
with sync_playwright() as pw:
    b = pw.chromium.launch()
    pg = b.new_page(viewport={"width": 3 * (width + 20) + 20, "height": 1000})
    sheets = 0
    for s in range(0, len(items), per):
        chunk = items[s:s + per]
        cells = "".join(f'<div class="cell" style="width:{width}px"><div class="tag">{t}</div><div class="story"><div class="frame on">{f[len("<figure"):] and f}</div></div></div>'
                        for t, f in chunk)
        html = f"<html><head><style>{css} .cell{{display:inline-block;vertical-align:top;margin:8px;border:1px solid #999;background:#fff}} .tag{{font:12px monospace;background:#eee;padding:2px}} .cell .story{{margin:0;border:none}} .cell figure{{display:block!important}}</style></head><body style='background:#ccc'>{cells}</body></html>"
        pg.set_content(html)
        pg.wait_for_timeout(150)
        pg.screenshot(path=(f"/home/claude/site/tests/only_{sheets:02d}.png" if F else f"/home/claude/site/tests/contact_{width}_{sheets:02d}.png"), full_page=True)
        # overflow check: any svg wider than its cell, or pic-wrap scrolling
        over = pg.evaluate("""() => Array.from(document.querySelectorAll('.cell')).map(c => {
            const w = c.querySelector('.pic-wrap'); return [c.querySelector('.tag').textContent, w ? w.scrollWidth - w.clientWidth : 0];
        }).filter(x => x[1] > 2)""")
        if over: print("overflow", sheets, over)
        sheets += 1
    b.close()
print("sheets", sheets)
