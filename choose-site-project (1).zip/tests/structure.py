import re, os, json
from html.parser import HTMLParser
OUT="/home/claude/site/out/"
js_ids=set()
for f in os.listdir("assets"):
    if f.endswith(".js"):
        s=open("assets/"+f).read()
        js_ids |= set(re.findall(r'\$\("([\w-]+)"\)', s)) | set(re.findall(r'getElementById\("([\w-]+)"\)', s))
uses={"workbench.js": None}
class P(HTMLParser):
    def __init__(s): super().__init__(); s.ids=[]; s.hrefs=[]
    def handle_starttag(s,t,a):
        a=dict(a)
        if "id" in a: s.ids.append(a["id"])
        if t=="a" and "href" in a: s.hrefs.append(a["href"])
pages={}
for name in ["index.html","choose-notes.html","choose-lesson.html","choose-practice.html"]:
    p=P(); h=open(OUT+name).read()
    # parse markup, plus HTML embedded in bench JSON (stories, concepts) which becomes DOM later
    p.feed(re.sub(r'<script.*?</script>','',h,flags=re.S))
    m=re.search(r'<script type="application/json" id="bench-data">(.*?)</script>',h,re.S)
    dyn=P()
    if m:
        d=json.loads(m.group(1).replace("<\\/","</"))
        for pr in d["problems"]: dyn.feed(pr["story"])
        for c in d["concepts"].values(): dyn.feed(c)
        p.ids.append("bench-data")
    pages[name]=(p,dyn,h)
print("ids referenced by JS:", sorted(js_ids))
for name,(p,dyn,h) in pages.items():
    bench = "bench-data" in p.ids
    needed = js_ids - ({"bench-data"} if not bench else set())
    if not bench:
        needed = {i for i in needed if i in ("f",)}  # reading pages use no getElementById
    missing = sorted(i for i in needed if i not in p.ids)
    dups = sorted({i for i in p.ids if p.ids.count(i)>1})
    # story ids in a single loaded problem/concept never collide with static ids
    clash = sorted(set(dyn.ids) & set(p.ids))
    dyn_dups = sorted({i for i in dyn.ids if dyn.ids.count(i)>1})
    bad=[]
    for href in p.hrefs+dyn.hrefs:
        if href.startswith("http"): bad.append(("external",href)); continue
        file,_,anchor=href.partition("#")
        file=file or name
        if file not in pages: bad.append(("nofile",href)); continue
        if anchor:
            tp=pages[file]
            if file=="choose-practice.html" or file=="choose-lesson.html":
                dd=json.loads(re.search(r'id="bench-data">(.*?)</script>',tp[2],re.S).group(1).replace("<\\/","</"))
                if anchor not in [x["id"] for x in dd["problems"]]: bad.append(("noanchor",href))
            elif anchor not in tp[0].ids: bad.append(("noanchor",href))
    print(f"{name}: ids={len(p.ids)} missing={missing} duplicates={dups} story-id clashes={clash} links={len(p.hrefs)+len(dyn.hrefs)} bad={bad}")
