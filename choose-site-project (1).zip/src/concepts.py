"""Concept stories (lesson Concept tab + notes page) and the plan story.
Story numbers deliberately differ from each concept's guided problem; every number is verified."""
from itertools import combinations, permutations, product
from math import comb, factorial as F, perm
import visuals as v
from stories import Cf, Fr, Skip, V, fmt, multinomial, paths_brute
from pcommon import partitions_brute, split_names


def frac(a, b):
    return f'<span class="frac"><span>{a}</span><span>{b}</span></span>'


def binom(n, k):
    return f'<span class="binom"><span>{n}</span><span>{k}</span></span>'


def eq(*parts):
    return '<div class="eq" role="math">' + " ".join(parts) + "</div>"


# ======================================================================= plan story
friends = ["Ana", "Ben", "Cal", "Dev", "Eli"]
fl = [f[0] for f in friends]
V("plan: ordered", len(list(permutations(fl, 3))), 60)
V("plan: groups", len(list(combinations(fl, 3))), 10)
tinyp = ["".join(c) for c in combinations("ABCD", 3)]
V("plan: tiny", len(tinyp), perm(4, 3) // 6)
PLAN_STORY = [
    Fr(1, v.chips_row(friends, {"Ana": "picked", "Cal": "picked", "Eli": "picked"}, w=44, caption="one sleepover"),
       "Pick 3 of 5 friends for a sleepover. One example: Ana, Cal, Eli."),
    Fr(2, v.chips_row(friends, w=44, caption="3 people chosen from 5"), "What is chosen? 3 people. From what? 5 friends."),
    Skip(3, "one kind of sleepover, and every friend is allowed"),
    Fr(4, v.card(["Ana, Cal, Eli   =   Cal, Ana, Eli"], "swap test", W=320, note="same sleepover"),
       "Swap Ana and Cal: same sleepover. Order doesn't matter, so it's a group.",
       ask="If the three were 1st, 2nd and 3rd prize winners, would the swap matter?"),
    Fr(5, v.slots([{"lab": "1st", "n": "5"}, {"lab": "2nd", "n": "4"}, {"lab": "3rd", "n": "3"}], result="60",
                  note="always 4 left after the first pick, whoever it was"),
       "Count as if they're invited one at a time: 5 × 4 × 3 = 60. Whoever goes first, 4 remain, so the counts stay equal and we multiply."),
    Fr(6, v.bundle(list(permutations("ACE")), ["A", "C", "E"], cols=2), "Built twice? Yes. Each sleepover was built 3 × 2 × 1 = 6 times."),
    Fr(6, v.calc(["60", "÷", "6", "=", "10"], "divide"), "Divide by the copies: 60 ÷ 6 = 10."),
    Fr(7, v.outcome_list(tinyp, cols=4, note="4 × 3 × 2 = 24, ÷ 6 = 4"),
       "Tiny case: 3 of 4 friends. The rule says 24 ÷ 6 = 4, and the list has exactly 4."),
]

# ======================================================================= concept stories
C = {}

# ---------------- C1: group without order (example: 2 of 5 flavours; guided problem uses 4 letters)
fla = list("VCSMB")
V("C1 ordered", len(list(permutations(fla, 2))), 20)
V("C1 groups", len(list(combinations(fla, 2))), 10)
for n_, o_, g_ in [(5, 20, 10), (7, 42, 21), (8, 56, 28), (10, 90, None)]:
    V(f"C1 table n={n_}", len(list(permutations(range(n_), 2))), o_)
    if g_:
        V(f"C1 table groups n={n_}", len(list(combinations(range(n_), 2))), g_)
ordered_rows = ["".join(p) for p in permutations(fla, 2)]
C["c1"] = dict(
    title="A group without order",
    idea="If swapping two picks gives the same thing, you're counting groups, and each group hides once in every order.",
    eq=eq("ordered lists", "=", "groups", "×", "(orders of one group)"),
    frames=[
        Cf(v.bag_of(["V", "C", "S", "M", "B"], picked=["V", "C"], label="five flavours, two scooped"),
           "A cup holds 2 different scoops from 5 flavours: Vanilla, Chocolate, Strawberry, Mint, Banana. Here's Vanilla + Chocolate."),
        Cf(v.calc(["5", "×", "4", "=", "20"], "tempting count", crossed=True, note="this counts first-scoop, second-scoop lists"),
           "Tempting: 5 × 4 = 20. But that counts 'Vanilla then Chocolate' and 'Chocolate then Vanilla' as two cups."),
        Cf(v.outcome_list(ordered_rows, cols=4, cellw=40, note="5 rows of 4: equal groups → multiply"),
           "List the first-scoop/second-scoop lists, holding the first scoop fixed: 5 rows of 4. Equal rows are why 5 × 4 works."),
        Cf(v.pickgrid(fla, "filled"), "The pick grid: first scoop down the side, second across the top. Every box is a list."),
        Cf(v.pickgrid(fla, "diagonal"), "The same flavour twice isn't allowed: cross out the diagonal. 20 boxes left."),
        Cf(v.pickgrid(fla, "twins", hl={(0, 1), (1, 0)}), "VC and CV are the same cup. Every box below the diagonal is a twin of one above.",
           ask="Point at a box. Where is its twin?"),
        Cf(v.bundle([("V", "C"), ("C", "V")], ["V", "C"]), "So each cup shows up as 2 lists. 20 lists ÷ 2 = 10 cups."),
        Cf(v.table(["flavours", "ordered lists", "cups of 2"], [["5", "20", "10"], ["7", "42", "21"], ["8", "56", "28"], ["10", "90", "?"]], hl=3),
           "The pattern: halve the ordered count. Fill in the last row."),
        Cf(v.card(["pairs from n  =  n × (n − 1) ÷ 2"], "rule", W=320), "Rule: count in order, then divide by the number of orders of one group."),
    ],
    from_class=("Example 1.1 (01:50–06:57, captures 3–6): the teacher lists the six pairs from A, B, C, D by "
                "'groups with A, then with B but not A…', then counts 4 × 3 = 12 ordered and boxes AB = BA, AC = CA… "
                "to show the 12 come in twos. He renames 'combinations with order' to 'groups with order'."),
    extra="Pairs from 9: 9 × 8 ÷ 2 = 36. Pairs from 20: 20 × 19 ÷ 2 = 190.",
    problems=["ps1", "ps12", "ps13"])
V("C1 extra 9", comb(9, 2), 36)
V("C1 extra 20", comb(20, 2), 190)

# ---------------- C2: choose function (example 3 of 6; guided uses 3 of 7)
st = list("KLMNOP")
V("C2 ordered", len(list(permutations(st, 3))), 120)
V("C2 groups", len(list(combinations(st, 3))), 20)
for n_, o_, g_ in [(4, 24, 4), (5, 60, 10), (6, 120, 20)]:
    V(f"C2 table {n_}", len(list(combinations(range(n_), 3))), g_)
    V(f"C2 table ordered {n_}", perm(n_, 3), o_)
C["c2"] = dict(
    title="The choose function",
    idea="Choose k from n = (k picks in a row) ÷ (the k! orders of one group).",
    eq=eq(binom("n", "k"), "=", frac("n(n−1)…(n−k+1)", "k!"), "=", frac("n!", "k!(n−k)!")),
    frames=[
        Cf(v.bag_of(st, picked=["K", "M", "P"], label="six stickers"), "6 different stickers: K, L, M, N, O, P. Grab 3, like K, M, P."),
        Cf(v.calc(["6", "×", "5", "×", "4", "=", "120"], "tempting", crossed=True, note="counts first, second, third sticker lists"),
           "Tempting: 6 × 5 × 4 = 120. That counts the lists, not the handfuls."),
        Cf(v.tree([("K", [("M", [("KMP", None)]), ("P", [("KPM", None)])]), ("M", [("K", [("MKP", None)]), ("P", [("MPK", None)])]),
                   ("P", [("K", [("PKM", None)]), ("M", [("PMK", None)])])], counts=["3", "2", "1"], leaf_w=46),
           "How many lists hold K, M, P? 3 choices first, 2 next, 1 last: an equal tree with 6 leaves."),
        Cf(v.bundle(list(permutations("KMP")), ["K", "M", "P"], cols=2), "All 6 lists bundle into one handful. Every handful has its own bundle of 6."),
        Cf(v.calc(["120", "÷", "6", "=", "20"], "divide"), "120 lists ÷ 6 lists per handful = 20 handfuls."),
        Cf(v.calc(["6·5·4", "÷", "3·2·1", "=", "6!", "÷", "(3!·3!)"], "factorials", plain_last=True),
           "Short form: 6 × 5 × 4 is 6! with 3! taken off, so it's 6! ÷ (3! × 3!)."),
        Cf(v.table(["choose 3 from", "lists", "handfuls"], [["4", "24", "4"], ["5", "60", "10"], ["6", "120", "20"], ["8", "336", "?"]], hl=3),
           "The pattern: divide the lists by 6 every time. Fill in the last row."),
        Cf(v.card(["n choose k = n!/(k!(n − k)!)"], "rule", W=320), "Rule: k falling numbers on top, k! underneath."),
    ],
    from_class=("Example 1.2 and Proposition 1.1 (07:12–19:35, captures 7–13): he circles {A, D, G} in the bag and writes "
                "'3! arrangements of A, D, G (of any 3 objects)', shows 7·6·5 is the front of 7!, and adds the habit "
                "'look at the larger factorial in the denominator' and cancel it first."),
    extra="9 choose 4 = 9 × 8 × 7 × 6 ÷ 24 = 126. 10 choose 2 = 45.",
    problems=["ps1", "ps17", "ch2"])
V("C2 extra", comb(9, 4), 126)
V("C2 extra2", comb(10, 2), 45)
V("C2 tree", len(list(permutations("KMP"))), 6)
V("C2 table q", perm(8, 3), 336)

# ---------------- C3: take = leave (example 7 of 9; guided 10 of 12)
nine = list("ABCDEFGHI")
V("C3", len(list(combinations(nine, 7))), comb(9, 2))
for n_, k_, val in [(5, 4, 5), (8, 6, 28), (9, 7, 36)]:
    V(f"C3 table {n_},{k_}", len(list(combinations(range(n_), k_))), val)
    V(f"C3 table sym {n_},{k_}", comb(n_, n_ - k_), val)
C["c3"] = dict(
    title="Take = leave",
    idea="Choosing who goes is the same as choosing who stays.",
    eq=eq(binom("n", "k"), "=", binom("n", "n−k")),
    frames=[
        Cf(v.bag_of(nine, picked=list("ABCDEFG")), "9 marbles; take 7 (A to G). H and I stay behind."),
        Cf(v.card(["taking 7 must have more ways", "than leaving 2"], "tempting", W=300, strike=True),
           "Tempting: taking 7 feels like more choosing than leaving 2. It isn't."),
        Cf(v.table(["take these 7", "leave these 2"], [["A B C D E F G", "H I"], ["A B C D E F H", "G I"], ["B C D E F G H", "A I"], ["…", "…"]], hl=0),
           "Every handful of 7 leaves exactly 2 behind, and every 2 left behind matches exactly one handful."),
        Cf(v.calc(["9 × 8", "÷", "2", "=", "36"], "leave 2"), "So count the short side: leave 2 of 9 = 9 × 8 ÷ 2 = 36. Take 7 is also 36."),
        Cf(v.calc(["9!", "÷", "(7! · 2!)", "=", "9!", "÷", "(2! · 7!)"], "same factors", plain_last=True), "The formula agrees: the same two factorials on the bottom, just swapped."),
        Cf(v.table(["take", "of", "same as leaving", "ways"], [["4", "5", "1", "5"], ["6", "8", "2", "28"], ["7", "9", "2", "36"], ["8", "10", "2", "?"]], hl=3),
           "Fill in the last row by counting the short side."),
        Cf(v.card(["n choose k = n choose (n − k)"], "rule", W=320), "Rule: always count the smaller group."),
    ],
    from_class=("Take 10 of 12 (19:52–22:39, capture 14): he draws a bag with 10 marbles in yellow and 2 in red and writes "
                "'to take 10 marbles is the same as leaving 2 marbles' — the same 'combinatorially, even without the arithmetic'."),
    extra="20 choose 18 = 20 choose 2 = 190. 7 choose 6 = 7.",
    problems=["ps13", "ps17"])
V("C3 extra", comb(20, 18), 190)
V("C3 extra2", comb(7, 6), 7)
V("C3 q", comb(10, 8), 45)

# ---------------- C4: groups in a row (example 6 kids into clubs 3/2/1; guided 9 cookies 4/3/2)
kids = list("ABCDEF")
V("C4 total", len(partitions_brute(6, (3, 2, 1))), 60)
V("C4 parts", comb(6, 3) * comb(3, 2) * comb(1, 1), 60)
V("C4 copies", F(3) * F(2) * F(1), 12)
V("C4 lineup", F(6), 720)
for sizes, val in [((3, 1), 4), ((2, 2), 6), ((3, 2, 1), 60)]:
    V(f"C4 table {sizes}", len(partitions_brute(sum(sizes), sizes)), val)
V("C4 q", multinomial([2, 2, 2]), 90)
C["c4"] = dict(
    title="Groups in a row",
    idea="Fill the groups one after another, choosing each from whoever is left.",
    eq=eq(binom("n", "a"), binom("n−a", "b"), binom("n−a−b", "c"), "=", frac("n!", "a! · b! · c!")),
    frames=[
        Cf(v.bags([("Art", list("ABC"), 3), ("Bike", list("DE"), 2), ("Chess", ["F"], 1)]),
           "6 kids join clubs: Art takes 3, Bike takes 2, Chess takes 1. One way: ABC, DE, F."),
        Cf(v.calc(["6!", "=", "720"], "tempting", crossed=True, note="counts lining all six up in a row"),
           "Tempting: 720 ways to line up 6 kids. But the order inside a club doesn't matter."),
        Cf(v.bags([("Art", list("ABC"), 3)], pool=kids, pool_states={x: "picked" for x in "ABC"}), "Art first: choose 3 of 6 = 20."),
        Cf(v.bags([("Bike", list("DE"), 2)], pool=kids, pool_states={**{x: "used" for x in "ABC"}, **{x: "picked" for x in "DE"}}),
           "Bike next: whoever went to Art, 3 kids are left. Choose 2 of 3 = 3."),
        Cf(v.slots([{"lab": "Art", "n": "20"}, {"lab": "Bike", "n": "3"}, {"lab": "Chess", "n": "1"}], result="60"),
           "Chess takes the last kid: 1 way. 20 × 3 × 1 = 60."),
        Cf(v.collapse([[("A", None, "p1"), ("B", None, "p2"), ("C", None, "p3"), ("|", None, None), ("D", None, "p4"), ("E", None, "p5")],
                       [("A", None, "p1"), ("B", None, "p2"), ("C", None, "p3"), ("|", None, None), ("E", None, "p5"), ("D", None, "p4")],
                       [("B", None, "p2"), ("A", None, "p1"), ("C", None, "p3"), ("|", None, None), ("D", None, "p4"), ("E", None, "p5")],
                       [("B", None, "p2"), ("A", None, "p1"), ("C", None, "p3"), ("|", None, None), ("E", None, "p5"), ("D", None, "p4")]],
                      "ABC|DE", note="each Art order × each Bike order"),
           "Check with the line-up: each split shows up once for every Art order (6) with every Bike order (2): 6 × 2 = 12 copies, not 6 + 2."),
        Cf(v.calc(["720", "÷", "12", "=", "60"], "divide"), "720 ÷ 12 = 60, the same answer."),
        Cf(v.table(["kids", "club sizes", "ways"], [["4", "3, 1", "4"], ["4", "2, 2 (named)", "6"], ["6", "3, 2, 1", "60"], ["6", "2, 2, 2 (named)", "?"]], hl=3),
           "Named clubs never trade places. Fill in the last row."),
        Cf(v.card(["n! ÷ (a! × b! × c!)"], "rule", W=260), "Rule: line them all up, then divide by the orders inside each group."),
    ],
    from_class=("Example 1.4 (22:39–29:20, captures 15–18): 'The choose function is not usually a single end to a problem… "
                "it might represent one step.' He fills the 4-bag, then the 3-bag from the 5 left, then the last 2, and explains "
                "2 choose 2 = 1 using 0! = 1. He calls 9!/(4!3!2!) the 'multichoose function' (the usual name is multinomial coefficient)."),
    extra="7 kids into clubs of 4 and 3: 7 choose 4 = 35. 5 kids into clubs of 2, 2 (named), 1: 10 × 3 × 1 = 30.",
    problems=["ps2", "ps9", "ps10", "ps11"])
V("C4 extra", comb(7, 4), 35)
V("C4 extra2", len(partitions_brute(5, (2, 2, 1))), 30)

# ---------------- C5: identical same-size groups (example 6 into two teams of 3; guided 10 cookies)
V("C5 named", len(partitions_brute(6, (3, 3), True)), 20)
V("C5 unnamed", len(partitions_brute(6, (3, 3), False)), 10)
pairs20 = []
for first in combinations(range(6), 3):
    if 0 not in first:
        continue
    rest = tuple(i for i in range(6) if i not in first)
    pairs20 += ["".join("ABCDEF"[i] for i in first), "".join("ABCDEF"[i] for i in rest)]
V("C5 pairs listed", len(pairs20), 20)
V("C5 3 pairs named", len(partitions_brute(6, (2, 2, 2), True)), 90)
V("C5 3 pairs", len(partitions_brute(6, (2, 2, 2), False)), 15)
V("C5 4 into 2+2", len(partitions_brute(4, (2, 2), False)), 3)
V("C5 table q", len(partitions_brute(8, (4, 4), True)), 70)
C["c5"] = dict(
    title="Identical same-size groups",
    idea="If groups are the same size and have no names, swapping them changes nothing, so divide by the ways to name them.",
    eq=eq("unnamed", "=", frac("named", "m!"), '<span class="eqnote">(m same-size groups)</span>'),
    frames=[
        Cf(v.bags([("team", list("ABC"), 3), ("team", list("DEF"), 3)]), "6 kids split into two teams of 3 for a game. No team names. One way: ABC and DEF."),
        Cf(v.calc(["6 choose 3", "=", "20"], "tempting", crossed=True, note="counts as if one team were 'first'"),
           "Tempting: choose a team of 3: 20. That quietly names one team 'first'."),
        Cf(v.same_split([list("ABC"), list("DEF")], [list("DEF"), list("ABC")]), "ABC-first and DEF-first are the same two teams."),
        Cf(v.outcome_list(pairs20, cols=4, cellw=46, note="each neighbour pair: a 'first team' and its twin"),
           "List all 20 'first teams'. They pair up: next to each first team is its twin, the other team."),
        Cf(v.calc(["20", "÷", "2", "=", "10"], "divide"), "20 ÷ 2 = 10 real splits."),
        Cf(v.same_split([list("ABCD"), list("EF")], [list("EF"), list("ABCD")], same=False, note="different sizes"),
           "Teams of different sizes never twin: a team of 4 can't trade places with a team of 2.",
           ask="Why didn't the 4/3/2 cookie bags need this step?"),
        Cf(v.calc(["90", "÷", "3!", "=", "15"], "three teams"), "Three same-size teams can be named 3! = 6 ways. Three pairs from 6 kids: 90 named ÷ 6 = 15."),
        Cf(v.table(["kids", "teams", "named", "unnamed"], [["4", "2 + 2", "6", "3"], ["6", "3 + 3", "20", "10"], ["6", "2 + 2 + 2", "90", "15"], ["8", "4 + 4", "70", "?"]], hl=3),
           "Fill in the last row."),
        Cf(v.card(["divide by m! for m same-size, unnamed groups"], "rule", W=360), "Rule: count with names, then divide by the ways to name the look-alike groups."),
    ],
    from_class=("Example 1.5 (29:20–36:48, captures 19–23): he writes 'Answer: 252?' and crosses it out — 'it's not a mistake, "
                "it's simply an incomplete solution' — then draws A–E | F–J and F–J | A–E in one yellow oval: "
                "'these arrangements are the same'. Identical bags are 'sort of like identical A's'."),
    extra="8 kids into two unnamed teams of 4: 70 ÷ 2 = 35. 9 kids into three unnamed teams of 3: 1,680 ÷ 6 = 280.",
    problems=["ps3", "ps8", "ps9", "ps10", "ch1"])
V("C5 extra", len(partitions_brute(9, (3, 3, 3), False)), 280)
V("C5 extra named", multinomial([3, 3, 3]), 1680)

# ---------------- C6: positions (example HHHTTT; guided UUURRRR)
V("C6", len(set(permutations("HHHTTT"))), comb(6, 3))
V("C6 copies", F(3) * F(3), 36)
V("C6 lineup", F(6), 720)
for w, val in [("HT", 2), ("HHT", 3), ("HHTT", 6), ("HHHTTT", 20), ("HHHHTTTT", 70)]:
    V(f"C6 table {w}", len(set(permutations(w))), val)
C["c6"] = dict(
    title="Choosing positions",
    idea="Arranging repeated letters is choosing which spots get one of the letters.",
    eq=eq("arrangements of a H's and b T's", "=", binom("a+b", "a"), "=", frac("(a+b)!", "a! · b!")),
    frames=[
        Cf(v.tiles([[(c, None, "p2" if c == "H" else "p1") for c in "HTHHTT"]]), "6 coin flips with 3 heads and 3 tails, like H T H H T T. How many such rows?"),
        Cf(v.calc(["6!", "=", "720"], "tempting", crossed=True, note="treats the three H's as different"),
           "Tempting: 720. That only works if every coin is different."),
        Cf(v.tiles([[("H", "1", "p2"), ("T", "1", "p1"), ("H", "2", "p3"), ("H", "3", "p4"), ("T", "2", "p5"), ("T", "3", "p6")]]),
           "Paint the copies: H₁, H₂, H₃ and T₁, T₂, T₃. Now all 6 are different, and there are 720 rows."),
        Cf(v.collapse([[("H", a, "p2"), ("H", b, "p3"), ("H", c, "p4")] for a, b, c in permutations("123")], "HHH",
                      note="× 6 orders of the T's as well"),
           "Wash off the paint. Each real row came from 6 orders of the H's times 6 orders of the T's: 6 × 6 = 36 copies."),
        Cf(v.calc(["720", "÷", "36", "=", "20"], "divide"), "720 ÷ 36 = 20 real rows."),
        Cf(v.chips_row(["1", "2", "3", "4", "5", "6"], {0: "picked", 2: "picked", 3: "picked"}, caption="choose the 3 H spots"),
           "Faster: a row is decided by which 3 of the 6 spots hold H. 6 choose 3 = 20."),
        Cf(v.table(["letters", "arrangements"], [["HT", "2"], ["HHT", "3"], ["HHTT", "6"], ["HHHTTT", "20"], ["HHHHTTTT", "?"]], hl=4),
           "Fill in the last row by choosing spots."),
        Cf(v.card(["(a + b) choose a"], "rule", W=240), "Rule: choose the spots for one letter; the other letter fills the rest."),
    ],
    from_class=("Practice 4 (43:24–45:30, capture 30): he writes 7!/(3!4!), notices 'it looks like seven choose three', then draws "
                "seven spots and circles three for U: 'What is being chosen? What objects are available to choose from?'"),
    extra="AAABB: 5 choose 2 = 10. XXYYYY: 6 choose 2 = 15.",
    problems=["ps4", "ps16"])
V("C6 extra", len(set(permutations("AAABB"))), 10)
V("C6 extra2", len(set(permutations("XXYYYY"))), 15)

# ---------------- C7: block walking (example 4x2; guided 6x5)
V("C7", paths_brute((0, 0), (4, 2)), comb(6, 2))
V("C7 via", paths_brute((0, 0), (4, 2), through=(1, 1)), 2 * 4)
for (w, h), val in [((1, 1), 2), ((2, 1), 3), ((2, 2), 6), ((3, 2), 10), ((4, 2), 15), ((4, 3), 35)]:
    V(f"C7 table {w}x{h}", paths_brute((0, 0), (w, h)), val)
legs8 = [f"{a}+{b}" for a in ("RU", "UR") for b in ("RRU", "RUR", "URR", "")][:8]
legs8 = [f"{a} then {b}" for a in ("RU", "UR") for b in ("RRU", "RUR", "URR")]
V("C7 second legs", paths_brute((1, 1), (4, 2)), 4)
second = ["RRRU", "RRUR", "RURR", "URRR"]
combos = [f"{a}·{b}" for a in ("RU", "UR") for b in second]
C["c7"] = dict(
    title="Block walking",
    idea="Every up/right path is a word of U's and R's; choose where the U's go. Through a checkpoint, multiply the two legs.",
    eq=eq("paths", "=", binom("R + U", "U"), '<span class="eqnote">through P:</span>', "paths(A→P) × paths(P→B)"),
    frames=[
        Cf(v.lattice(4, 2, path="RURRRU", marks={"A": (0, 0), "B": (4, 2)}), "A 4-by-2 grid. One path from A to B: right, up, right, right, right, up."),
        Cf(v.calc(["4", "+", "2", "=", "6"], "tempting", crossed=True, note="6 counts moves, not paths"),
           "Tempting: 6. But 6 is the number of moves in each path, not the number of paths."),
        Cf(v.word_strip("RURRRU", note="4 R's and 2 U's"), "Write the path as a word: R U R R R U. Every path is a 6-letter word with 4 R's and 2 U's."),
        Cf(v.lattice(4, 2, path="RURRRU", legs=[((0, 0), "URRRRU", "leg2")], marks={"A": (0, 0), "B": (4, 2)}),
           "Rearrange the letters: a new path that still ends at B."),
        Cf(v.calc(["6 × 5", "÷", "2", "=", "15"], "choose U spots"), "So choose the 2 U spots out of 6: 6 × 5 ÷ 2 = 15 paths."),
        Cf(v.lattice(4, 2, legs=[((0, 0), "RU", "leg1"), ((1, 1), "RRRU", "leg2")], marks={"A": (0, 0), "P": (1, 1), "B": (4, 2)}),
           "A checkpoint P at (1, 1). A to P: 2 paths. P to B: 4 paths."),
        Cf(v.outcome_list(combos, cols=4, cellw=78, note="every first leg with every second leg: 2 × 4 = 8"),
           "Each of the 2 first legs works with each of the 4 second legs: 2 × 4 = 8 paths through P."),
        Cf(v.table(["grid", "paths"], [["1 × 1", "2"], ["2 × 1", "3"], ["2 × 2", "6"], ["3 × 2", "10"], ["4 × 2", "15"], ["4 × 3", "?"]], hl=5),
           "Fill in the last row by choosing U spots."),
        Cf(v.card(["(R + U) choose U", "checkpoint: multiply the legs"], "rule", W=320), "Rule: a path is a word; choose its U spots."),
    ],
    from_class=("Example 2.1 and the 8 × 8 practice (45:30–50:22, captures 31–37): he traces UURRUUURRRR as spoken directions, "
                "writes 'total number of movements, choose some', then splits A→C at B into 'two separate pieces of our overall path'."),
    extra="5-by-3 grid: 8 choose 3 = 56. 3-by-3 through the centre point (1, 1)… try it: 2 × 6 = 12.",
    problems=["ps5", "ps6", "ps7"])
V("C7 extra", paths_brute((0, 0), (5, 3)), 56)
V("C7 extra2", paths_brute((0, 0), (3, 3), through=(1, 1)), 12)
V("C7 combos", len(combos), 8)

# ---------------- C8: what decides the shape (pentagon triangles; rectangles 3x2; guided cube)
pent = v.polygon_points(5, r=62, cx=100, cy=86)
V("C8 tri", len(list(combinations("ABCDE", 3))), 10)
V("C8 ordered", perm(5, 3), 60)
V("C8 leave", comb(5, 2), 10)
rgrid = [(i, j) for i in range(4) for j in range(3)]


def _rect(S):
    xs = sorted({p[0] for p in S})
    ys = sorted({p[1] for p in S})
    return len(xs) == 2 and len(ys) == 2 and set(S) == {(x, y) for x in xs for y in ys}


V("C8 rect", sum(1 for S in combinations(rgrid, 4) if _rect(S)), comb(4, 2) * comb(3, 2))
V("C8 4 corners", len(list(combinations(rgrid, 4))), 495)
V("C8 table diag", comb(5, 2) - 5, 5)
V("C8 table q", comb(5, 2) * comb(4, 2), 60)
pe = [(a, b) for a, b in zip("ABCDE", "BCDEA")]
C["c8"] = dict(
    title="Choose what decides the shape",
    idea="Find the smallest set of things that decides the shape: 3 corners, 2 endpoints, or 2 lines from each family.",
    eq=eq("triangles", "=", binom("V", "3"), "&nbsp;&nbsp;", "rectangles", "=", binom("a", "2"), "×", binom("b", "2")),
    frames=[
        Cf(v.dots(pent, pe, hl=[("A", "C"), ("C", "D"), ("D", "A")], W=200, H=176), "A pentagon. Connect three corners to make a triangle, like A, C, D."),
        Cf(v.calc(["5 × 4 × 3", "=", "60"], "tempting", crossed=True, note="names the corners in order"),
           "Tempting: 60. That names the corners in order: ACD and DAC are the same triangle."),
        Cf(v.bundle(list(permutations("ACD")), ["A", "C", "D"], cols=2), "What decides a triangle? Just its 3 corners, as a group. 6 orders → 1 triangle."),
        Cf(v.calc(["60", "÷", "6", "=", "10"], "divide"), "60 ÷ 6 = 10 triangles, which is 5 choose 3. (Or leave 2 of 5: also 10.)"),
        Cf(v.dots({"P": (30, 60), "Q": (100, 60), "R": (170, 60)}, [("P", "R")], W=200, H=100, note="3 points in a line: no triangle"),
           "Careful: 3 points in a straight line don't make a triangle. Check that never happens."),
        Cf(v.skew_grid(3, 2, hl_v=(0, 2), hl_h=(0, 1), note="2 of 4 up-lines, 2 of 3 across-lines"),
           "Shapes in a grid: a parallelogram is decided by 2 lines from each family."),
        Cf(v.calc(["6", "×", "3", "=", "18"], "lines"), "In this 3-by-2 grid: 4 choose 2 = 6 pairs one way, 3 choose 2 = 3 the other. 6 × 3 = 18."),
        Cf(v.calc(["12 choose 4", "=", "495"], "tempting corners", crossed=True, note="most sets of 4 corners aren't parallelograms"),
           "Choosing 4 corners instead would give 495, but most of those aren't parallelograms."),
        Cf(v.table(["shape", "decided by", "count"], [["triangles in a pentagon", "3 corners", "10"], ["diagonals of a pentagon", "2 non-neighbour corners", "5"],
                                                      ["shapes in a 3 × 2 grid", "2 + 2 lines", "18"], ["shapes in a 4 × 3 grid", "2 + 2 lines", "?"]], hl=3),
           "Fill in the last row."),
    ],
    from_class=("Example 1.6 and Problem 3.1 (36:48–40:09 and 50:22–54:06): 'I'm not going to choose the triangle itself. What I'm going "
                "to choose is whatever makes a triangle.' For parallelograms he first explains why choosing four vertices fails, then numbers "
                "the slanted lines 1–6 and the flat lines 1–5."),
    extra="Triangles from a hexagon's corners: 6 choose 3 = 20. Rectangles in a 2 × 2 grid: 3 × 3 = 9.",
    problems=["ps12", "ps13", "ps18", "ch2"])
V("C8 extra", comb(6, 3), 20)

# ---------------- C9: rules and cases (example 3 finalists from 4 states; mixed teams 3R 2B; guided P3.2)
ppl = [(s, w) for s in range(4) for w in range(2)]
V("C9 states", sum(1 for c in combinations(ppl, 3) if len({p[0] for p in c}) == 3), comb(4, 3) * 8)
V("C9 tempting", len(list(combinations(ppl, 3))), 56)
st5 = ["R1", "R2", "R3", "B1", "B2"]
mixed = [" ".join(t) for t in combinations(st5, 3) if len({x[0] for x in t}) == 2]
V("C9 mixed", len(mixed), comb(3, 2) * 2 + 3 * comb(2, 2))
rrb = [t for t in mixed if t.count("R") == 2]
rbb = [t for t in mixed if t.count("R") == 1]
V("C9 rrb", len(rrb), 6)
V("C9 rbb", len(rbb), 3)
C["c9"] = dict(
    title="Rules and cases",
    idea="Handle the rule first (choose the allowed groups, then the members), or split into kinds that can't overlap and add.",
    eq=eq("total", "=", "case 1", "+", "case 2", "&nbsp;&nbsp;", "restricted", "=", "(choose groups)", "×", "(members each)"),
    frames=[
        Cf(v.states(4, picked={0, 1, 3}, chosen={0: 0, 1: 1, 3: 0}, names=["S1", "S2", "S3", "S4"]),
           "4 states send 2 people each (A and B). Pick 3 finalists, at most one per state. One way: S1-A, S2-B, S4-A."),
        Cf(v.calc(["8 choose 3", "=", "56"], "tempting", crossed=True, note="includes both people from one state"),
           "Tempting: 56. That includes teams with both people from one state."),
        Cf(v.states(4, picked={0, 1, 3}, names=["S1", "S2", "S3", "S4"]), "Start with the most restricting part: choose the 3 states. 4 choose 3 = 4."),
        Cf(v.tree([(s, [(t, [(s + t + u, None) for u in "AB"]) for t in "AB"]) for s in "AB"], counts=["S1", "S2", "S4"], leaf_w=44),
           "Then each chosen state picks A or B: an equal tree, 2 × 2 × 2 = 8."),
        Cf(v.calc(["4", "×", "8", "=", "32"], "multiply"), "4 state choices × 8 person choices = 32."),
        Cf(v.vstack(v.outcome_list(rrb, cols=3, cellw=86, note="2 red + 1 blue: 6"), v.outcome_list(rbb, cols=3, cellw=86, note="1 red + 2 blue: 3")),
           "A different kind of problem: 3-person teams with both colours from R1, R2, R3, B1, B2. Split by kind: the two branches are uneven, 6 and 3."),
        Cf(v.calc(["6", "+", "3", "=", "9"], "add"), "The branches have different sizes, so we can't multiply. A team is one kind or the other, never both, so add: 9.",
           ask="Why add here, but multiply for the states?"),
        Cf(v.table(["situation", "move"], [["a rule like 'one per state'", "choose the groups first, then the members"],
                                           ["kinds that can't overlap", "count each kind, then add"], ["uneven tree", "split into cases"]], hl=1),
           "Two moves for problems with rules."),
    ],
    from_class=("Problems 3.2 and 3.3 (54:06–66:09, captures 41–47): 'Let's start with the most restricting aspect… choose the states "
                "first.' For the jerseys: 'when we have separate cases like that, we think about those cases separately and then just "
                "add them together at the end.' He leaves 3.2 as 2⁵ × 20 × 49 × 47 × 46."),
    extra="5 states of 2, choose 2 finalists: 5 choose 2 × 4 = 40. Mixed teams of 3 from 4 red, 1 blue: only 2R+1B, 6 × 1 = 6.",
    problems=["ps14", "ps15", "ps17", "ch3"])
ppl5 = [(s, w) for s in range(5) for w in range(2)]
V("C9 extra", sum(1 for c in combinations(ppl5, 2) if c[0][0] != c[1][0]), 40)
st41 = ["R1", "R2", "R3", "R4", "B1"]
V("C9 extra2", sum(1 for t in combinations(st41, 3) if len({x[0] for x in t}) == 2), 6)

CONCEPT_ORDER = ["c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9"]
