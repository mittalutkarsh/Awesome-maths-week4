"""Concept stories for the tag-word method. Each concept is one way of tagging.
Story numbers differ from each concept's guided problem; every number is verified."""
from itertools import combinations, permutations, product
from math import comb, factorial as F
import visuals as v
from stories import Cf, V, fmt, paths_brute
from method import Fr, tag_row, word_pic, group_word_pic, count_words
from pcommon import partitions_brute, split_names
from concepts import eq, frac, binom


def wl(word):
    return sorted(set("".join(p) for p in permutations(word)))


# ======================================================================= plan story (3 of 5 friends)
fr = ["Ana", "Ben", "Cal", "Dev", "Eli"]
V("plan2 words", len(wl("TLTLT")), 10)
V("plan2 ordered", 5 * 4 * 3, 60)
PLAN_STORY = [
    Fr(1, tag_row(fr, "TLTLT"), "Pick 3 of 5 friends for a sleepover. Tag each friend: T = invited, L = not. Ana, Cal and Eli are invited."),
    Fr(2, v.vstack(word_pic("TLTLT"), v.calc(["5! ÷ (3! × 2!)", "=", "10"], "count")),
       "The tags spell a word with 3 T's and 2 L's. Count the different words with the repeated-letters rule: 120 ÷ (6 × 2) = 10."),
    Fr(2, v.calc(["5 × 4 × 3", "=", "60"], "tempting", crossed=True, note="that counts the order of invitations"),
       "Tempting: 60. That counts who was invited first, second and third. The tag word has no order."),
    Fr(3, v.card(["T = going, L = staying", "a T can't trade places with an L"], "no look-alikes", W=320),
       "Look-alike groups? No. Going and staying are different, so nothing can trade places. Nothing to divide."),
    Fr(4, v.outcome_list([f"{w} → {''.join(l for l, t in zip('ABCD', w) if t == 'T')}" for w in sorted(wl('TTTL'), reverse=True)], cols=4, cellw=92,
                         note="words with 3 T and 1 L: 4"),
       "Tiny case: 3 of 4 friends. The words with 3 T's and 1 L are listed: 4, one for each sleepover."),
]
V("plan2 tiny", len(wl("TTTL")), 4)

C = {}

# ---------------- c1 repeated letters (guided: UUURRRR = 35)
V("c1 AABBB", len(wl("AABBB")), 10)
V("c1 copies", F(2) * F(3), 12)
for w, val in [("AB", 2), ("AAB", 3), ("AABB", 6), ("AABBB", 10), ("AAABBB", 20)]:
    V(f"c1 table {w}", len(wl(w)), val)
lst = wl("AABBB")
C["c1"] = dict(
    title="Words with repeated letters",
    idea="A word's letters can be shuffled n! ways, but shuffling identical letters changes nothing, so divide by each letter's repeats!.",
    eq=eq("words", "=", frac("n!", "a! × b! × …")),
    frames=[
        Cf(v.tiles([[(c, None, "p1" if c == "A" else "p3") for c in "ABABB"]]), "A word with 2 A's and 3 B's, like A B A B B. How many different words use exactly these letters?"),
        Cf(v.calc(["5!", "=", "120"], "tempting", crossed=True, note="treats the two A's as different letters"), "Tempting: 5! = 120. That only works if all 5 letters are different."),
        Cf(v.tiles([[("A", "1", "p1"), ("B", "1", "p3"), ("A", "2", "p2"), ("B", "2", "p4"), ("B", "3", "p5")]]),
           "Paint the copies so they are all different: A₁, A₂ and B₁, B₂, B₃. Now there really are 120 painted words."),
        Cf(v.collapse([[("A", a, "p1"), ("A", b, "p2")] for a, b in permutations("12")], "AA", note="× 6 orders of the B's too"),
           "Wash off the paint. Each real word came from 2 orders of the A's times 6 orders of the B's: 2 × 6 = 12 copies (multiply, don't add)."),
        Cf(v.calc(["120", "÷", "12", "=", "10"], "divide"), "120 ÷ 12 = 10 real words."),
        Cf(v.outcome_list(lst, cols=5, note="A first: 4 words; B first: 6 words"), "List them, holding the first letter fixed: 4 start with A and 6 start with B. 10 in all."),
        Cf(v.table(["letters", "words"], [["AB", "2"], ["AAB", "3"], ["AABB", "6"], ["AABBB", "10"], ["AAABBB", "?"]], hl=4), "Fill in the last row."),
        Cf(v.card(["words = n! ÷ (each letter's repeats)!"], "rule", W=360), "Rule: n! on top, a factorial for each repeated letter underneath."),
    ],
    from_class=("Practice 4 (43:24–45:30, capture 30): the teacher writes 7!/(3!4!) for U, U, U, R, R, R, R and notices it "
                "'looks like seven choose three'. That one observation is the whole method: every problem this week becomes a word like this."),
    extra="AAABB: 5! ÷ (3! × 2!) = 10. XXYYYY: 6! ÷ (2! × 4!) = 15. MISSISSIPPI-style words work the same way.",
    problems=["ps4", "ps16"])
V("c1 extra", len(wl("XXYYYY")), 15)

# ---------------- c2 take or leave (guided: 4 letters pairs 6, 7 marbles 35, 12 choose 10 = 66)
fl = list("VCSMB")
V("c2 words", len(wl("TTLLL")), 10)
V("c2 ordered", 5 * 4, 20)
for n_, val in [(5, 10), (7, 21), (8, 28)]:
    V(f"c2 table {n_}", len(list(combinations(range(n_), 2))), val)
V("c2 q", comb(9, 2), 36)
C["c2"] = dict(
    title="Choosing: tag T or L",
    idea="Choosing k things from n is a tag word with k T's (take) and n − k L's (leave).",
    eq=eq(binom("n", "k"), "=", frac("n!", "k! × (n − k)!"), '<span class="eqnote">a word with k T’s and n − k L’s</span>'),
    frames=[
        Cf(tag_row(fl, "TTLLL"), "Pick 2 ice-cream flavours of 5 (Vanilla, Chocolate, Strawberry, Mint, Banana). Tag each: T = in the cup, L = not. Here V and C."),
        Cf(v.calc(["5 × 4", "=", "20"], "tempting", crossed=True, note="counts first scoop, second scoop"),
           "Tempting: 20. That counts Vanilla-then-Chocolate and Chocolate-then-Vanilla as two cups."),
        Cf(v.pickgrid(fl, "twins", hl={(0, 1), (1, 0)}), "The pick grid shows why: every cup appears twice, once above the diagonal and once below."),
        Cf(v.vstack(word_pic("TTLLL"), v.calc(["5! ÷ (2! × 3!)", "=", "10"], "count")),
           "The tag word has no first or second scoop. It has 2 T's and 3 L's. Count its words: 10."),
        Cf(v.outcome_list([f"{w} → {''.join(l for l, t in zip(fl, w) if t == 'T')}" for w in sorted(wl('TTLLL'), reverse=True)], cols=2, cellw=110),
           "All 10 words, one for each cup."),
        Cf(v.card(["swap every T with L:", "take 2  ↔  leave 2 (take 3)"], "take = leave", W=340),
           "Swap every T and L and you get the cups of 3 instead. Same count: taking k is like leaving k."),
        Cf(v.table(["choose 2 from", "T/L words"], [["5", "10"], ["7", "21"], ["8", "28"], ["9", "?"]], hl=3), "Fill in the last row."),
        Cf(v.card(["n choose k = n! ÷ (k! × (n − k)!)"], "rule", W=360), "Rule: a choice is a T/L word."),
    ],
    from_class=("Examples 1.1–1.3 and Proposition 1.1 (01:50–19:35, captures 3–13): the teacher counts in order, then removes the order "
                "(÷ 2 for pairs, ÷ 3! for {A, D, G}). With 12 marbles he notes that taking 10 'is the same as leaving 2'. The tag word "
                "builds the order removal in from the start."),
    extra="Teams of 3 from 6: 6! ÷ (3! × 3!) = 20. Leave 2 of 20: 20! ÷ (18! × 2!) = 190.",
    problems=["ps1", "ps12", "ps13", "ps17", "ps18"])
V("c2 extra", comb(6, 3), 20)
V("c2 extra2", comb(20, 2), 190)

# ---------------- c3 several groups (guided: 9 cookies 4/3/2 = 1260)
kids = list("ABCDEF")
V("c3 words", count_words("c3", tags="AAABBC"), 60)
V("c3 split check", len(partitions_brute(6, (3, 2, 1))), 60)
for sizes, val in [((3, 1), 4), ((2, 2), 6), ((3, 2, 1), 60)]:
    V(f"c3 table {sizes}", len(partitions_brute(sum(sizes), sizes)), val)
V("c3 q", count_words("c3q", tags="XXYYZZ"), 90)
C["c3"] = dict(
    title="Tags for several groups",
    idea="When everything is split into named groups, tag each object with its group's letter and count the words.",
    eq=eq("splits", "=", frac("n!", "a! × b! × c!"), '<span class="eqnote">a word with a X’s, b Y’s, c Z’s</span>'),
    frames=[
        Cf(v.bags([("Art", list("ABC"), 3), ("Bike", list("DE"), 2), ("Chess", ["F"], 1)]), "6 kids join clubs: Art takes 3, Bike 2, Chess 1. One way: ABC, DE, F."),
        Cf(v.calc(["6!", "=", "720"], "tempting", crossed=True, note="counts lining all six up"), "Tempting: 720. But the order inside a club doesn't matter."),
        Cf(tag_row(kids, "AAABBC"), "Tag each kid with a club letter: A = Art, B = Bike, C = Chess."),
        Cf(v.vstack(word_pic("AAABBC"), v.calc(["6! ÷ (3! × 2!)", "=", "60"], "count")), "The tags spell a word with 3 A's, 2 B's and 1 C: 720 ÷ 12 = 60 words, one per split."),
        Cf(v.slots([{"lab": "Art", "n": "20"}, {"lab": "Bike", "n": "3"}, {"lab": "Chess", "n": "1"}], result="60", note="choose each club from whoever is left"),
           "The class way gives the same number: choose Art (20), then Bike from the 3 left (3), then Chess (1): 60."),
        Cf(v.table(["kids", "club sizes", "words"], [["4", "3, 1", "4"], ["4", "2, 2 (named)", "6"], ["6", "3, 2, 1", "60"], ["6", "2, 2, 2 (named)", "?"]], hl=3),
           "Named clubs never trade places. Fill in the last row."),
        Cf(v.card(["n! ÷ (a! × b! × c!)"], "rule", W=260), "Rule: one letter per group, then the repeated-letters rule."),
    ],
    from_class=("Example 1.4 (22:39–29:20, captures 15–18): the teacher fills the 4-bag, then the 3-bag, then the 2-bag and arrives at "
                "9!/(4!·3!·2!), which he calls the 'multichoose function'. That is exactly the tag word XXXXYYYZZ."),
    extra="7 kids into clubs of 4 and 3: 7! ÷ (4! × 3!) = 35. 5 kids into named pairs and a single: 5! ÷ (2! × 2!) = 30.",
    problems=["ps2", "ps10", "ps11", "ps15"])
V("c3 extra", count_words("c3e", tags="XXXXYYY"), 35)
V("c3 extra2", count_words("c3e2", tags="XXYYZ"), 30)

# ---------------- c4 look-alike groups (guided: 10 cookies, identical bags = 126)
V("c4 words", count_words("c4", tags="XXXYYY"), 20)
V("c4 real", len(partitions_brute(6, (3, 3), False)), 10)
V("c4 three pairs", len(partitions_brute(6, (2, 2, 2), False)), 15)
V("c4 two pairs + trio", len(partitions_brute(7, (2, 2, 3), False)), 105)
V("c4 two pairs + trio words", count_words("c4b", tags="XXYYZZZ"), 210)
pairs20 = []
for first in combinations(range(6), 3):
    if 0 in first:
        rest = tuple(i for i in range(6) if i not in first)
        pairs20 += ["".join("ABCDEF"[i] for i in first), "".join("ABCDEF"[i] for i in rest)]
C["c4"] = dict(
    title="Look-alike groups",
    idea="Groups with the same size and no names can trade places, so write the groups as a word and divide by its repeats!.",
    eq=eq("real splits", "=", frac("tag words", "(group word’s repeats)!"), '<span class="eqnote">A A A B B → ÷ (3! × 2!)</span>'),
    frames=[
        Cf(v.bags([("team", list("ABC"), 3), ("team", list("DEF"), 3)]), "6 kids split into two teams of 3. The teams have no names."),
        Cf(v.vstack(tag_row(kids, "XXXYYY"), v.calc(["6! ÷ (3! × 3!)", "=", "20"], "count")), "Tag the teams X and Y and count: 20 words."),
        Cf(v.same_split([list("ABC"), list("DEF")], [list("DEF"), list("ABC")]), "But swap every X with Y: XXXYYY becomes YYYXXX, and it's the same two teams."),
        Cf(v.outcome_list(pairs20, cols=4, cellw=46, note="each neighbour pair is one real split"), "So the 20 words come in twins: 10 real splits."),
        Cf(group_word_pic([("A", "team", "3"), ("A", "team", "3")], note="the groups spell A A → ÷ 2!"),
           "Write the groups themselves as a word: two look-alike teams spell A A. Divide by 2! = 2."),
        Cf(v.same_split([list("ABCD"), list("EF")], [list("EF"), list("ABCD")], same=False, note="group word A B: nothing to divide"),
           "Teams of 4 and 2 never look alike: their group word is A B, with no repeats."),
        Cf(group_word_pic([("A", "X", "2"), ("A", "Y", "2"), ("B", "Z", "3")], note="A A B → ÷ 2!"),
           "Mixed: 7 kids into two pairs and a trio. Tag words: 210. Group word A A B, so ÷ 2! = 105."),
        Cf(v.table(["group word", "divide by"], [["A B", "1"], ["A A", "2! = 2"], ["A A A", "3! = 6"], ["A A B", "2! = 2"], ["A A A B B", "?"]], hl=4),
           "Fill in the last row."),
        Cf(v.card(["look-alike = same size and no names", "divide by each group letter's repeats!"], "rule", W=380), "Rule: only identical group letters can trade places."),
    ],
    from_class=("Example 1.5 (29:20–36:48, captures 19–23): the teacher writes 'Answer: 252?', crosses it out ('not a mistake, just an "
                "incomplete solution') and says identical bags are 'sort of like identical A's'. The group word is that idea written down."),
    extra="9 kids into three unnamed teams of 3: 1,680 tag words ÷ 3! = 280. 8 kids into two unnamed teams of 4: 70 ÷ 2! = 35.",
    problems=["ps3", "ps8", "ps9", "ps10", "ch1"])
V("c4 extra", len(partitions_brute(9, (3, 3, 3), False)), 280)

# ---------------- c5 paths (guided: 6x5 grid = 462)
V("c5 paths", paths_brute((0, 0), (4, 2)), count_words("c5", tags="RRRRUU"))
V("c5 via", paths_brute((0, 0), (4, 2), through=(1, 1)), 2 * 4)
for (w, h), val in [((1, 1), 2), ((2, 1), 3), ((2, 2), 6), ((3, 2), 10), ((4, 2), 15)]:
    V(f"c5 table {w}x{h}", paths_brute((0, 0), (w, h)), val)
C["c5"] = dict(
    title="Paths are words",
    idea="Every up/right path is a word of R's and U's, so count the words. Through a checkpoint, the two legs are two words: multiply.",
    eq=eq("paths", "=", frac("(R + U)!", "R! × U!"), '<span class="eqnote">through P: word₁ × word₂</span>'),
    frames=[
        Cf(v.lattice(4, 2, path="RURRRU", marks={"A": (0, 0), "B": (4, 2)}), "A 4-by-2 grid. One path from A to B: right, up, right, right, right, up."),
        Cf(v.calc(["4", "+", "2", "=", "6"], "tempting", crossed=True, note="6 counts moves, not paths"), "Tempting: 6. That's the number of moves, not paths."),
        Cf(tag_row([str(i) for i in range(1, 7)], "RURRRU"), "Tag each move R or U. The path is the word R U R R R U."),
        Cf(v.lattice(4, 2, path="RURRRU", legs=[((0, 0), "URRRRU", "leg2")], marks={"A": (0, 0), "B": (4, 2)}), "Rearrange the letters: a new path, same end."),
        Cf(v.vstack(word_pic("RURRRU"), v.calc(["6! ÷ (4! × 2!)", "=", "15"], "count")), "Count the words with 4 R's and 2 U's: 15 paths."),
        Cf(v.lattice(4, 2, legs=[((0, 0), "RU", "leg1"), ((1, 1), "RRRU", "leg2")], marks={"A": (0, 0), "P": (1, 1), "B": (4, 2)}),
           "Through a checkpoint P: the first leg is a word (2 of them), the second leg another word (4). Every first word goes with every second: 2 × 4 = 8."),
        Cf(v.table(["grid", "paths"], [["1 × 1", "2"], ["2 × 1", "3"], ["2 × 2", "6"], ["3 × 2", "10"], ["4 × 2", "15"], ["4 × 3", "?"]], hl=5), "Fill in the last row."),
        Cf(v.card(["paths = (R + U)! ÷ (R! × U!)"], "rule", W=320), "Rule: a path is a tag word."),
    ],
    from_class=("Example 2.1 and the 8 × 8 practice (45:30–50:22): the teacher writes a path as UURRUUURRRR, 'total number of movements, "
                "choose some', and splits A → C at B into 'two separate pieces'."),
    extra="5-by-3 grid: 8! ÷ (5! × 3!) = 56. 3-by-3 grid through (1, 1): 2 × 6 = 12.",
    problems=["ps5", "ps6", "ps7"])
V("c5 extra", paths_brute((0, 0), (5, 3)), 56)

# ---------------- c6 shapes (guided: cube triangles 56)
pent = v.polygon_points(5, r=62, cx=100, cy=86)
pe = [(a, b) for a, b in zip("ABCDE", "BCDEA")]
V("c6 tri", count_words("c6", tags="TTTLL"), 10)
rgrid = [(i, j) for i in range(4) for j in range(3)]


def _rect(S):
    xs = sorted({p[0] for p in S}); ys = sorted({p[1] for p in S})
    return len(xs) == 2 and len(ys) == 2 and set(S) == {(x, y) for x in xs for y in ys}


V("c6 rect", sum(1 for S in combinations(rgrid, 4) if _rect(S)), count_words("c6v", tags="TTLL") * count_words("c6h", tags="TTL"))
C["c6"] = dict(
    title="Tag what decides the shape",
    idea="Find what decides the shape (corners, endpoints, or lines) and tag those T or L.",
    eq=eq("triangles", "=", "words of 3 T’s on the corners", "&nbsp;&nbsp;", "parallelograms", "=", "line word × line word"),
    frames=[
        Cf(v.dots(pent, pe, hl=[("A", "C"), ("C", "D"), ("D", "A")], W=200, H=176), "A pentagon. Join three corners to make a triangle, like A, C, D."),
        Cf(v.calc(["5 × 4 × 3", "=", "60"], "tempting", crossed=True, note="names the corners in order"), "Tempting: 60. That names the corners in order."),
        Cf(tag_row(list("ABCDE"), "TLTTL"), "What decides a triangle? Its 3 corners. Tag them T, the rest L."),
        Cf(v.vstack(word_pic("TLTTL"), v.calc(["5! ÷ (3! × 2!)", "=", "10"], "count")), "Words with 3 T's and 2 L's: 10 triangles."),
        Cf(v.dots({"P": (30, 60), "Q": (100, 60), "R": (170, 60)}, [("P", "R")], W=200, H=100, note="3 points in a line: no triangle"),
           "Careful: 3 points in a straight line don't make a triangle. Check that it never happens."),
        Cf(v.skew_grid(3, 2, hl_v=(0, 2), hl_h=(0, 1), note="2 of 4 up-lines, 2 of 3 across-lines"),
           "In a grid, a parallelogram is decided by 2 lines of each kind: two tag words."),
        Cf(v.calc(["6", "×", "3", "=", "18"], "two words"), "Up-line words TTLL: 6. Across-line words TTL: 3. Two separate words multiply: 18."),
        Cf(v.table(["shape", "what to tag", "count"], [["triangles in a pentagon", "3 corners", "10"], ["segments in a pentagon", "2 corners", "10"],
                                                       ["shapes in a 3 × 2 grid", "2 + 2 lines", "18"], ["shapes in a 4 × 3 grid", "2 + 2 lines", "?"]], hl=3),
           "Fill in the last row."),
    ],
    from_class=("Example 1.6 and Problem 3.1 (36:48–40:09, 50:22–54:06): 'I'm not going to choose the triangle itself. What I'm going to choose "
                "is whatever makes a triangle.' For parallelograms he numbers the slanted lines 1–6 and the flat lines 1–5."),
    extra="Triangles from a hexagon's corners: 6! ÷ (3! × 3!) = 20. Shapes in a 2 × 2 grid: 3 × 3 = 9.",
    problems=["ps12", "ps13", "ps18", "ch2"])

# ---------------- c7 two words or cases (guided: debate finalists)
ppl = [(s, w) for s in range(4) for w in range(2)]
V("c7 states", sum(1 for c in combinations(ppl, 3) if len({p[0] for p in c}) == 3), count_words("c7s", tags="TTTL") * 8)
st5 = ["R1", "R2", "R3", "B1", "B2"]
mixed = [" ".join(tt) for tt in combinations(st5, 3) if len({x[0] for x in tt}) == 2]
rrb = [tt for tt in mixed if tt.count("R") == 2]
rbb = [tt for tt in mixed if tt.count("R") == 1]
V("c7 cases", len(mixed), len(rrb) + len(rbb))
V("c7 rrb", len(rrb), 6)
C["c7"] = dict(
    title="Two words, or two cases",
    idea="If a choice has two separate parts, it's two words: multiply. If it splits into kinds that can't overlap, count each kind and add.",
    eq=eq("total", "=", "word₁ × word₂", "&nbsp;or&nbsp;", "case₁ + case₂"),
    frames=[
        Cf(v.states(4, picked={0, 1, 3}, chosen={0: 0, 1: 1, 3: 0}, names=["S1", "S2", "S3", "S4"]),
           "4 states send 2 people each (A and B). Pick 3 finalists, at most one per state."),
        Cf(v.calc(["8 choose 3", "=", "56"], "tempting", crossed=True, note="includes two people from one state"), "Tempting: 56. That allows two from one state."),
        Cf(tag_row(["S1", "S2", "S3", "S4"], "TTLT"), "Start with the most restricting part. First word: tag each state T (has a finalist) or L. Words TTTL: 4."),
        Cf(tag_row(["S1", "S2", "S4"], "ABA"), "Second word: each chosen state tags its person A or B: 2 × 2 × 2 = 8."),
        Cf(v.calc(["4", "×", "8", "=", "32"], "multiply"), "Two separate words: every state word goes with every A/B word. 4 × 8 = 32."),
        Cf(v.vstack(v.outcome_list(rrb, cols=3, cellw=86, note="2 red + 1 blue: 6"), v.outcome_list(rbb, cols=3, cellw=86, note="1 red + 2 blue: 3")),
           "Different idea: 3-person teams with both colours from R1, R2, R3, B1, B2. Two cases, uneven in size."),
        Cf(v.calc(["6", "+", "3", "=", "9"], "add"), "A team is one case or the other, never both, so add: 9.", ask="Why add here, but multiply for the states?"),
        Cf(v.table(["situation", "move"], [["two separate parts", "two words: multiply"], ["kinds that can't overlap", "cases: add"],
                                           ["a rule like 'one per state'", "tag the restricted part first"]], hl=0),
           "The moves for problems with rules."),
    ],
    from_class=("Problems 3.2 and 3.3 (54:06–66:09): 'Let's start with the most restricting aspect… choose the states first', and "
                "'when we have separate cases like that, we think about those cases separately and then just add them together at the end.'"),
    extra="5 states of 2, choose 2 finalists: 10 state words × 4 = 40. Mixed teams of 3 from 4 red and 1 blue: only 2R + 1B, 6 × 1 = 6.",
    problems=["ps7", "ps14", "ps15", "ps16", "ch3"])

CONCEPT_ORDER = ["c1", "c2", "c3", "c4", "c5", "c6", "c7"]
LESSON_CONCEPT = {"l6": "c1", "l1": "c2", "l2": "c2", "l3": "c2", "l4": "c3", "l5": "c4", "l7": "c5", "l8": "c6", "l9": "c7"}
LESSON_ORDER = ["l6", "l1", "l2", "l3", "l4", "l5", "l7", "l8", "l9"]
PRACTICE_CONCEPT = {"ps1": "c2", "ps2": "c3", "ps3": "c4", "ps4": "c1", "ps5": "c5", "ps6": "c5", "ps7": "c5", "ps8": "c4", "ps9": "c4",
                    "ps10": "c4", "ps11": "c3", "ps12": "c6", "ps13": "c6", "ps14": "c7", "ps15": "c7", "ps16": "c7", "ps17": "c2",
                    "ps18": "c2", "ch1": "c4", "ch2": "c6", "ch3": "c7"}
