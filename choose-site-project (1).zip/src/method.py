"""The tag-word method: one way of thinking for every problem this week.

  1. Tag every object with a letter that says where it goes.
  2. Count the words the tags can spell: n! ÷ (each letter's repeats)!.
     Separate words multiply; separate cases add.
  3. Look-alike groups (same size, no names)? Write the group word and divide by its repeats!.
  4. Check a tiny case you can list.

Every count drawn here is computed by enumeration AND by the formula (stories.V asserts they agree).
"""
from itertools import combinations
from math import factorial as F
import visuals as v
from stories import V, fmt

PLAN = ["Tag every object", "Count the words", "Look-alike groups?", "Check a tiny case"]
PLAN_LONG = [
    "Tag every object with a letter that says where it goes.",
    "Count the words the tags spell: n! ÷ (each letter's repeats)!. Two separate words multiply; separate cases add.",
    "Look-alike groups (same size, no names)? Write the group word and divide by its repeats!.",
    "Check a tiny case you can list.",
]

TAG_PAINT = {}
_PALETTE = ["p1", "p2", "p3", "p4", "p5", "p6"]


def paint_for(letter):
    if letter in ("L", "·"):
        return "pl"
    if letter not in TAG_PAINT:
        TAG_PAINT[letter] = _PALETTE[len(TAG_PAINT) % len(_PALETTE)]
    return TAG_PAINT[letter]


def letter_counts(tags):
    """Counts per letter, in reading order, with digits ascending and the 'leave' tag L last."""
    out = {}
    for t in tags:
        out[t] = out.get(t, 0) + 1
    keys = sorted(out, key=lambda k: (k == "L", 0 if not k.isdigit() else 1, int(k) if k.isdigit() else 0))
    first = {}
    for i, t in enumerate(tags):
        first.setdefault(t, i)
    keys = sorted(out, key=lambda k: (k == "L", k.isdigit(), int(k) if k.isdigit() else first[k]))
    return {k: out[k] for k in keys}


def words_formula(counts):
    n = sum(counts)
    r = F(n)
    for c in counts:
        r //= F(c)
    return r


def words_brute(counts):
    """Enumerate every word: choose positions for letter 1, then letter 2 among what's left, ... (counts leaves)."""
    counts = [c for c in counts if c > 0]
    n = sum(counts)

    def rec(free, i):
        if i == len(counts) - 1:
            return 1
        total = 0
        for chosen in combinations(free, counts[i]):
            s = set(chosen)
            total += rec([x for x in free if x not in s], i + 1)
        return total

    return rec(list(range(n)), 0)


def count_words(name, tags=None, counts=None):
    if counts is None:
        counts = list(letter_counts(tags).values())
    return V(f"{name}: words", words_brute(counts), words_formula(counts))


def word_formula_text(counts_by_letter):
    n = sum(counts_by_letter.values())
    den = [f"{c}!" for c in counts_by_letter.values() if c > 1]
    if not den:
        return f"{n}!"
    return f"{n}! ÷ (" + " × ".join(den) + ")" if len(den) > 1 else f"{n}! ÷ {den[0]}"


# ------------------------------------------------------------------ pictures
def tag_row(objs, tags, label="tagged objects", note=None, per_row=None, ow=None):
    """Each object as a chip with its tag letter in a tile underneath."""
    n = len(objs)
    ow = ow or max(34, 9 * max(len(str(o)) for o in objs) + 14)
    per_row = per_row or min(n, max(1, 560 // (ow + 8)))
    rows = (n + per_row - 1) // per_row
    W = per_row * (ow + 8) + 12
    rh = 74
    H = rows * rh + 8 + (22 if note else 0)
    b = ""
    for i, (o, t) in enumerate(zip(objs, tags)):
        r, c = divmod(i, per_row)
        x, y = 8 + c * (ow + 8), 6 + r * rh
        b += v.chip(x, y, str(o), "", w=ow, h=26)
        b += f'<line x1="{x + ow / 2}" y1="{y + 27}" x2="{x + ow / 2}" y2="{y + 36}" class="edge"/>'
        tw = 30
        b += f'<rect x="{x + (ow - tw) / 2}" y="{y + 37}" width="{tw}" height="28" rx="5" class="tile {paint_for(t)}"/>'
        b += v.text(x + ow / 2, y + 57, t, "tilet")
    if note:
        b += v.text(W / 2, H - 6, note, "cap")
    return v.svg(W, H, b, label)


def word_pic(tags, label="tag word", note=None):
    """The tag word, plus how many of each letter."""
    cnt = letter_counts(tags)
    tw = 26 if len(tags) <= 14 else 20
    W = max(len(tags) * (tw + 3) + 20, 200)
    H = 76 + (22 if note else 0)
    b = ""
    for i, t in enumerate(tags):
        x = 10 + i * (tw + 3)
        b += f'<rect x="{x}" y="6" width="{tw}" height="{tw + 2}" rx="4" class="tile {paint_for(t)}"/>'
        b += v.text(x + tw / 2, 6 + tw / 2 + 6, t, "tilet sm")
    summary = ",  ".join(f"{c} × {l}" for l, c in cnt.items())
    b += v.text(W / 2, 58, summary, "cap")
    if note:
        b += v.text(W / 2, H - 6, note, "cap")
    return v.svg(W, H, b, label)


def group_word_pic(groups, label="group word", note=None):
    """groups: list of (letter, group label, size word)."""
    def sub(size):
        return f"size {size}" if str(size).isdigit() else size
    return v.letter_groups([(l, g, "p1" if l == "A" else ("p3" if l == "B" else "p5"), sub(sz)) for l, g, sz in groups],
                           label=label, note=note)


# ------------------------------------------------------------------ frame helpers
def Fr(step, pic, text, ask=None):
    return {"step": step, "pic": pic, "text": text, "ask": ask}


class Part:
    """One tag word. objs/tags: the full objects and their tags, or a shown sample with `counts` given."""

    def __init__(self, name, objs, tags, legend, counts=None, formula=None, value=None, sample_note=None, pic=None,
                 count_text=None, tag_text=None, ask=None, ow=None):
        self.name, self.objs, self.tags, self.legend = name, objs, tags, legend
        self.counts = counts or letter_counts(tags)
        self.formula = formula or word_formula_text(self.counts)
        self.value = value if value is not None else count_words(name, counts=list(self.counts.values()))
        self.sample_note = sample_note
        self.pic = pic
        self.count_text = count_text
        self.tag_text = tag_text
        self.ask = ask
        self.ow = ow
        self.custom = value is not None


def build_story(key, parts, combine=None, look=None, tiny=None, tempting=None, answer=None, extra2=None,
                part_word_pics=True):
    """parts: list of Part. combine: '×', '+', '−' or None. look: dict(yes, groups, divisor_terms, reason, pic).
    tiny: dict(items, text, cols, cellw, note). tempting: list of (calc parts, text) shown crossed in step 2."""
    frames = []
    for p in parts:
        tpic = p.pic or tag_row(p.objs, p.tags, note=p.sample_note, ow=p.ow)
        frames.append(Fr(1, tpic, p.tag_text or f"Tag each one: {p.legend}.", p.ask))
    for p in parts:
        if p.custom or (p.count_text and not part_word_pics):
            frames.append(Fr(2, v.calc([p.formula, "=", fmt(p.value)], "count"), p.count_text))
            continue
        cnt = ", ".join(f"{c} {l}" for l, c in p.counts.items())
        if sum(p.counts.values()) <= 24 and part_word_pics:
            pic = v.vstack(word_pic(p.tags if len(p.tags) == sum(p.counts.values()) else "".join(l * c for l, c in p.counts.items())),
                           v.calc([p.formula, "=", fmt(p.value)], "count", plain_last=False))
        else:
            pic = v.calc([p.formula, "=", fmt(p.value)], "count")
        frames.append(Fr(2, pic, p.count_text or f"The tags spell a word with {cnt}. Count its words: {p.formula} = {fmt(p.value)}."))
    total = parts[0].value
    if combine and len(parts) > 1:
        calc = []
        for i, p in enumerate(parts):
            if i:
                calc.append(combine)
            calc.append(fmt(p.value))
        for p in parts[1:]:
            total = total * p.value if combine == "×" else total + p.value if combine == "+" else total - p.value
        calc += ["=", fmt(total)]
        why = {"×": "Every word of the first kind goes with every word of the second kind, so multiply.",
               "+": "The cases can't overlap, so add.",
               "−": "Take away the ones that don't count."}[combine]
        frames.append(Fr(2, v.calc(calc, "combine"), why))
    for parts_c, text in (tempting or []):
        frames.append(Fr(2, v.calc(parts_c, "tempting", crossed=True), text))
    frames += extra2 or []
    if look and look.get("yes"):
        div = 1
        for c in look["divisor_terms"]:
            div *= F(c)
        terms = " × ".join(f"{c}!" for c in look["divisor_terms"])
        frames.append(Fr(3, look.get("pic") or group_word_pic(look["groups"], note="the groups spell " + " ".join(g[0] for g in look["groups"])),
                         look["text"], look.get("ask")))
        final = total // div
        assert total % div == 0
        frames.append(Fr(3, v.calc([fmt(total), "÷", f"({terms})" if len(look["divisor_terms"]) > 1 else terms, "=", fmt(final)], "divide"),
                         f"Divide by the look-alike repeats: {fmt(total)} ÷ {fmt(div)} = {fmt(final)}."))
        total = final
    else:
        reason = (look or {}).get("reason", "nothing here can trade places without changing the answer")
        frames.append(Fr(3, (look or {}).get("pic") or v.card(["No look-alike groups"], "no look-alikes", W=260, note=None),
                         f"Look-alike groups? No: {reason}. Nothing to divide."))
    if answer is not None:
        assert total == answer, (key, total, answer)
    if tiny:
        V(f"{key}: tiny list", len(tiny["items"]), tiny["value"])
        frames.append(Fr(4, v.outcome_list(tiny["items"], cols=tiny.get("cols", 4), cellw=tiny.get("cellw"), note=tiny.get("note")),
                         tiny["text"]))
    return frames, total
