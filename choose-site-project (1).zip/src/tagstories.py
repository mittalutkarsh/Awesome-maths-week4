"""Tag-word worked answers for every lesson and practice problem, plus hints and nudges in the same language."""
from itertools import combinations, permutations, product
from math import comb, factorial as F
import visuals as v
from stories import V, fmt
from method import Part, build_story, tag_row, word_pic, Fr, count_words
from pcommon import partitions_brute, split_names


def words_list(word):
    return sorted(set("".join(p) for p in permutations(word)))


def pick_list(word, labels):
    """Tag words with 'T' marking taken objects, shown as 'TTLL → AB'."""
    return [f"{w} → {''.join(l for l, t in zip(labels, w) if t == 'T')}" for w in sorted(words_list(word), reverse=True)]


S = {}      # id -> frames
H = {}      # id -> list of per-step overrides {hint, nudges}

NO_TL = "take and leave are different tags, so a T can never trade places with an L"

# ------------------------------------------------------------------ lesson
f, t = build_story("L1", [Part("L1", list("ABCD"), "TLTL", "T = take it, L = leave it (here A and C are taken)")],
                   look={"reason": NO_TL},
                   tempting=[(["4 × 3", "=", "12"], "Tempting: 12. That counts first-letter, second-letter lists, so AC and CA both get counted. A tag word has no first or second.")],
                   tiny={"items": pick_list("TTL", "ABC"), "value": 3, "cols": 3, "cellw": 90,
                         "text": "Tiny case: choose 2 of A, B, C. The words with 2 T and 1 L are listed: 3 of them, one for each pair."},
                   answer=6)
S["l1"] = f
H["l1"] = [dict(hint="Give each letter a tag: T if it's in the combination, L if it's left out. Then count the different tag words.",
                nudges=["Plan step 1: tag each of A, B, C, D with T (in) or L (out). What does one combination look like as tags?",
                        "Plan step 2: how many T's and how many L's are in every tag word? Count the different words.",
                        "Plan step 3: can a T ever trade places with an L without changing the combination?"])]

f, t = build_story("L2", [Part("L2", list("ABCDEFG"), "TLLTLLT", "T = grabbed, L = left in the bag (A, D, G grabbed)")],
                   look={"reason": NO_TL},
                   tempting=[(["7 × 6 × 5", "=", "210"], "Tempting: 210. That counts the order your fingers met the marbles. ADG and GDA are the same tag word.")],
                   tiny={"items": pick_list("TTTL", "ABCD"), "value": 4, "cols": 4, "cellw": 92,
                         "text": "Tiny case: grab 3 of A, B, C, D. Words with 3 T and 1 L: 4, listed."},
                   answer=35)
S["l2"] = f
H["l2"] = [dict(hint="Tag each marble T (grabbed) or L (left). Every grab is one tag word with 3 T's and 4 L's. Count those words.",
                nudges=["Plan step 1: tag each of the 7 marbles. How many get T?",
                        "Plan step 2: a word with some T's and some L's. Count the words with the repeated-letters rule.",
                        "Plan step 3: do any groups here look alike, or are T and L different tags?"])]

f, t = build_story("L3", [Part("L3", list("ABCDEFGHIJKL"), "TTTTTTTTTTLL", "T = taken, L = left in the bag (K and L stay)",
                               count_text="The word has 10 T's and 2 L's. It's decided by where the 2 L's sit, so it's the same count as leaving 2: 12! ÷ (10! × 2!) = 66.")],
                   look={"reason": NO_TL},
                   tiny={"items": pick_list("TTTL", "ABCD"), "value": 4, "cols": 4, "cellw": 92,
                         "text": "Tiny case: take 3 of 4. The word is decided by where its one L goes: 4 words, listed."},
                   answer=66)
S["l3"] = f
H["l3"] = [dict(hint="Tag each marble T (taken) or L (left). A word with 10 T's and 2 L's is decided by where the 2 L's go.",
                nudges=["Plan step 1: tag the 12 marbles. How many L's are there?",
                        "Plan step 2: the word is decided by the spots of the L's. Count those words.",
                        "Plan step 3: can a T and an L ever trade places?"])]

f, t = build_story("L4", [Part("L4", list("ABCDEFGHI"), "XXXXYYYZZ", "X = first bag, Y = second bag, Z = third bag")],
                   look={"reason": "the bags hold 4, 3 and 2, so no two bags can trade places",
                         "pic": v.same_split([list("ABCD"), list("EFG")], [list("EFG"), list("ABCD")], same=False, note="a 4-bag can't swap with a 3-bag")},
                   tiny={"items": [f"{w} → {''.join(c for c, x in zip('ABC', w) if x == 'X')} | {''.join(c for c, x in zip('ABC', w) if x == 'Y')}" for w in words_list("XXY")],
                         "value": 3, "cols": 3, "cellw": 110,
                         "text": "Tiny case: 3 cookies into a bag of 2 (X) and a bag of 1 (Y). Words with 2 X and 1 Y: 3, listed."},
                   answer=1260)
S["l4"] = f
H["l4"] = [dict(hint="Tag each cookie with its bag: X, Y or Z. The first bag alone is a word with 4 X's and 5 'not yet' tags.",
                nudges=["Plan step 1: which cookies get tag X? How many X's are there?",
                        "Plan step 2: count the words with 4 X's and 5 other letters.",
                        "Plan step 3: no look-alikes yet, since this step is just the first bag."]),
           dict(hint="Of the 5 cookies left, tag 3 with Y and 2 with Z. Count those words.",
                nudges=["Plan step 1: only 5 cookies are left. Tag them Y or Z.",
                        "Plan step 2: a word with 3 Y's and 2 Z's.",
                        "Plan step 3: the bags have different sizes."]),
           dict(hint="The whole thing is one tag word: 4 X's, 3 Y's and 2 Z's. Count its words.",
                nudges=["Plan step 1: every cookie gets X, Y or Z.",
                        "Plan step 2: count words with 4 X, 3 Y and 2 Z (or combine steps 1 and 2).",
                        "Plan step 3: can bags of different sizes trade places?"])]

f, t = build_story("L5", [Part("L5", list("ABCDEFGHIJ"), "XXXXXYYYYY", "X = one bag, Y = the other bag")],
                   look={"yes": True, "groups": [("A", "A–E", "5"), ("A", "F–J", "5")], "divisor_terms": [2],
                         "text": "Look-alike groups? Yes. The bags are identical and both hold 5, so swapping every X with Y gives the same division. The groups spell A A.",
                         "ask": "Identical bags are like identical letters. How?"},
                   tiny={"items": sorted(split_names(b, "ABCD") for b in partitions_brute(4, (2, 2), False)), "value": 3, "cols": 3,
                         "note": "6 words ÷ 2! = 3",
                         "text": "Tiny case: A, B, C, D into two identical bags of 2. Tag words XXYY: 6. Swapping X and Y pairs them up, so 3 real ways, listed."},
                   answer=126)
S["l5"] = f
H["l5"] = [dict(hint="Tag the cookies X (one bag) or Y (the other). Count the tag words. Then: the bags are identical, so do the X's and Y's look alike?",
                nudges=["Plan step 1: tag each cookie with its bag, X or Y. How many of each?",
                        "Plan step 2: count the words with 5 X's and 5 Y's.",
                        "Plan step 3: the bags are identical and the same size. What does swapping every X with Y do?"])]

f, t = build_story("L6", [Part("L6", [str(i) for i in range(1, 8)], "URRURUR", "each spot is tagged with the letter that goes there")],
                   look={"reason": "U and R are different letters, and there are no groups to swap"},
                   tempting=[(["7!", "=", "5,040"], "Tempting: 5,040. That treats the three U's as three different letters.")],
                   tiny={"items": words_list("UURR"), "value": 6, "cols": 6,
                         "text": "Tiny case: UURR. Words with 2 U and 2 R: 6, listed."},
                   answer=35)
S["l6"] = f
H["l6"] = [dict(hint="This one already is a tag word: 3 U's and 4 R's. Count the different words using the repeated-letters rule.",
                nudges=["Plan step 1: the 7 spots are the objects; each gets U or R.",
                        "Plan step 2: swap two U's. Is that a new word? So divide out the U repeats and the R repeats.",
                        "Plan step 3: are there any groups that look alike, beyond the letters?"])]

f, t = build_story("L7", [Part("L7", [str(i) for i in range(1, 12)], "UURRUUURRRR", "each move is tagged U (up) or R (right)")],
                   look={"reason": "a path is just its word; there are no groups"},
                   tiny={"items": words_list("RRU"), "value": 3, "cols": 3,
                         "text": "Tiny case: a 2-by-1 grid. Words with 2 R and 1 U: 3 paths, listed."},
                   answer=462)
S["l7"] = f
H["l7"] = [dict(hint="Count how far right and how far up B is from A.",
                nudges=["Count the squares along the bottom edge.", "Count the squares up the side.", "Every path uses the same moves."]),
           dict(hint="Every path is a tag word of R's and U's with 6 R's and 5 U's. Count the words.",
                nudges=["Plan step 1: tag each move R or U.",
                        "Plan step 2: count the words with 6 R's and 5 U's.",
                        "Plan step 3: no groups here, so nothing more to divide."])]

f, t = build_story("L8", [Part("L8", list("ABCDEFGH"), "TTLLLLTL", "T = a corner of the triangle, L = not used (A, B, G here)")],
                   look={"reason": NO_TL},
                   tempting=[(["8 × 7 × 6", "=", "336"], "Tempting: 336. That names the corners in order; ABG and GAB are the same tag word.")],
                   tiny={"items": pick_list("TTTL", "ABCD"), "value": 4, "cols": 4, "cellw": 92,
                         "text": "Tiny case: a square's 4 corners. Words with 3 T and 1 L: 4 triangles, listed."},
                   answer=56)
S["l8"] = f
H["l8"] = [dict(hint="A triangle is decided by its 3 corners. Tag each cube corner T (used) or L (not used) and count the words.",
                nudges=["Plan step 1: what decides a triangle? Tag those things.",
                        "Plan step 2: count the words with 3 T's and 5 L's.",
                        "Plan step 3: can a T and an L trade places without changing the triangle?"])]

st_tags = "TLLTTLLTLT"
V("L9 members", sum(1 for _ in product("AB", repeat=5)), 2 ** 5)
f, t = build_story("L9", [
    Part("L9 states", [f"S{i}" for i in range(1, 11)], st_tags, "T = this state has a finalist, L = it doesn't", counts={"T": 5, "L": 45},
         formula="50! ÷ (5! × 45!)", sample_note="the first 10 of the 50 states shown",
         tag_text="Start with the most restricting part. Tag each state: T if it has a finalist, L if not. (10 of the 50 shown.)"),
    Part("L9 members", ["S1", "S4", "S5", "S8", "S10"], "ABBAA", "each chosen state tags its finalist A or B", counts={"A": 3, "B": 2},
         formula="2 × 2 × 2 × 2 × 2", value=32,
         count_text="Each of the 5 chosen states picks A or B, a free choice each time: 2 × 2 × 2 × 2 × 2 = 32.",
         tag_text="Then each chosen state tags its finalist: A or B.")],
    combine="×", look={"reason": "every finalist is a different person from a different state"},
    tiny={"items": [f"{a}{m1} {b}{m2}" for a, b in combinations("123", 2) for m1 in "AB" for m2 in "AB"], "value": 12, "cols": 4,
          "text": "Tiny case: 3 states, 2 finalists. State words TTL: 3; finalist choices 2 × 2 = 4; 3 × 4 = 12, listed."},
    answer=67800320, part_word_pics=False)
S["l9"] = f
H["l9"] = [dict(hint="Start with the most restricting part: tag each state T (has a finalist) or L. Then each chosen state picks A or B. Two separate words multiply.",
                nudges=["Plan step 1: what should get tagged first, the people or the states?",
                        "Plan step 2: the state word has 5 T's and 45 L's. Then each chosen state has its own free choice.",
                        "Plan step 3: can two finalists ever be look-alikes here?"])]

# ------------------------------------------------------------------ practice
f, t = build_story("PS1", [Part("PS1", [str(i) for i in range(1, 11)], "LTLLTLLTLL", "T = in your hand, L = still in the bag (candies 2, 5, 8 here)")],
                   look={"reason": NO_TL},
                   tempting=[(["10 × 9 × 8", "=", "720"], "Tempting: 720. That counts the order the candies came out. The tag word doesn't care about order.")],
                   tiny={"items": pick_list("TTTL", "ABCD"), "value": 4, "cols": 4, "cellw": 92,
                         "text": "Tiny case: grab 3 of 4 candies. Words with 3 T and 1 L: 4, listed."},
                   answer=120)
S["ps1"] = f
H["ps1"] = [dict(hint="Tag each candy T (grabbed) or L (left). Every handful is one tag word with 3 T's and 7 L's. Count those words.",
                 nudges=["Plan step 1: tag each of the 10 candies. How many T's?",
                         "Plan step 2: count the words with 3 T's and 7 L's, using the repeated-letters rule.",
                         "Plan step 3: can a T and an L trade places without changing the handful?"])]

f, t = build_story("PS2", [Part("PS2", [str(i) for i in range(1, 10)], "XYXXYXYYX", "X = team of 5, Y = team of 4")],
                   look={"reason": "a team of 5 can't trade places with a team of 4",
                         "pic": v.same_split([list("ABCDE"), list("FGHI")], [list("FGHI"), list("ABCDE")], same=False, note="sizes differ")},
                   tiny={"items": [f"{w}" for w in words_list("XXY")], "value": 3, "cols": 3,
                         "text": "Tiny case: 3 players into a team of 2 (X) and a team of 1 (Y). Words with 2 X and 1 Y: 3, listed."},
                   answer=126)
S["ps2"] = f
H["ps2"] = [dict(hint="Tag each player X (team of 5) or Y (team of 4). Count the tag words, then ask whether the teams look alike.",
                 nudges=["Plan step 1: tag each player with a team letter. How many X's and Y's?",
                         "Plan step 2: count the words with 5 X's and 4 Y's.",
                         "Plan step 3: can a team of 5 and a team of 4 trade places?"])]

f, t = build_story("PS3", [Part("PS3", [str(i) for i in range(1, 11)], "XYXXYYXYXY", "X = one team, Y = the other team")],
                   look={"yes": True, "groups": [("A", "team X", "5"), ("A", "team Y", "5")], "divisor_terms": [2],
                         "text": "Look-alike groups? Yes. Both teams have 5 and no names, so swapping every X with Y gives the same two teams. The groups spell A A.",
                         "ask": "What would change if the teams were called Red and Blue?"},
                   tiny={"items": sorted(split_names(b, "ABCD") for b in partitions_brute(4, (2, 2), False)), "value": 3, "cols": 3,
                         "note": "6 words ÷ 2! = 3",
                         "text": "Tiny case: 4 players into two teams of 2. Words XXYY: 6. Each split shows up twice, so 3, listed."},
                   answer=126)
S["ps3"] = f
H["ps3"] = [dict(hint="Tag each player X or Y. Count the words. Then: the teams have no names and the same size, so they're look-alikes.",
                 nudges=["Plan step 1: tag each player with a team letter. How many of each?",
                         "Plan step 2: count the words with 5 X's and 5 Y's.",
                         "Plan step 3: the teams have no names. What does swapping every X with Y do?"])]

f, t = build_story("PS4", [Part("PS4", [str(i) for i in range(1, 8)], "RURRUUR", "each spot is tagged with the letter that goes there")],
                   look={"reason": "U and R are different letters, and there are no groups to swap"},
                   tempting=[(["7!", "=", "5,040"], "Tempting: 5,040. That treats the three U's as three different letters.")],
                   tiny={"items": words_list("UURR"), "value": 6, "cols": 6, "text": "Tiny case: UURR has 6 words, listed."},
                   answer=35)
S["ps4"] = f
H["ps4"] = [dict(hint="It's already a tag word: 3 U's and 4 R's. Count the different words.",
                 nudges=["Plan step 1: the 7 spots are the objects, each tagged U or R.",
                         "Plan step 2: swapping two U's doesn't make a new word. Use the repeated-letters rule.",
                         "Plan step 3: any look-alike groups beyond the letters?"])]

GRID = {"A": (0, 0), "B": (4, 3), "C": (8, 8)}
f, t = build_story("PS5", [Part("PS5", [str(i) for i in range(1, 8)], "RURRUUR", "each move is tagged R or U",
                                pic=v.vstack(v.lattice(8, 8, legs=[((0, 0), "RURRUUR", "leg1")], marks=GRID), tag_row([str(i) for i in range(1, 8)], "RURRUUR")))],
                   look={"reason": "a path is just its word"},
                   tiny={"items": words_list("RRU"), "value": 3, "cols": 3, "text": "Tiny case: a 2-by-1 grid has 3 paths, listed."},
                   answer=35)
S["ps5"] = f
f, t = build_story("PS6", [Part("PS6", [str(i) for i in range(1, 10)], "URUURRURU", "each move is tagged R or U",
                                pic=v.vstack(v.lattice(8, 8, legs=[((4, 3), "URUURRURU", "leg1")], marks=GRID), tag_row([str(i) for i in range(1, 10)], "URUURRURU")))],
                   look={"reason": "a path is just its word"},
                   tiny={"items": words_list("RUU"), "value": 3, "cols": 3, "text": "Tiny case: a 1-by-2 grid has 3 paths, listed."},
                   answer=126)
S["ps6"] = f
for pid, r, u in (("ps5", 4, 3), ("ps6", 4, 5)):
    H[pid] = [dict(hint="Count how far right and how far up the end is from the start.",
                   nudges=["Count the squares going right.", "Count the squares going up.", "Every path uses the same moves."]),
              dict(hint=f"Every path is a tag word with {r} R's and {u} U's. Count the words.",
                   nudges=["Plan step 1: tag each move R or U.", "Plan step 2: count the words with the repeated-letters rule.",
                           "Plan step 3: no groups here."])]
tiny7 = sorted(s for s in words_list("RRUU") if any((s[:i].count("R"), s[:i].count("U")) == (1, 1) for i in range(5)))
f, t = build_story("PS7", [Part("PS7 leg1", [str(i) for i in range(1, 8)], "RURRUUR", "first leg A → B: R or U",
                                pic=v.lattice(8, 8, legs=[((0, 0), "RURRUUR", "leg1"), ((4, 3), "URUURRURU", "leg2")], marks=GRID),
                                tag_text="Split the trip at B. Each trip is two words: a first-leg word (blue) and a second-leg word (orange)."),
                           Part("PS7 leg2", [str(i) for i in range(1, 10)], "URUURRURU", "second leg B → C: R or U",
                                tag_text="Tag the second leg's moves R or U too.")],
                   combine="×", look={"reason": "each trip splits at B in exactly one way"},
                   tiny={"items": tiny7, "value": 4, "cols": 2, "text": "Tiny case: 2-by-2 grid through the middle: 2 first legs × 2 second legs = 4, listed."},
                   answer=4410)
S["ps7"] = f
H["ps7"] = [dict(hint="Split the trip at B: a first-leg word and a second-leg word. Two separate words multiply.",
                 nudges=["Plan step 1: split every trip into two legs at B.",
                         "Plan step 2: you already counted each leg's words in problems 5 and 6. Do separate words add or multiply?",
                         "Plan step 3: can a trip split at B in more than one way?"])]

f, t = build_story("PS8", [Part("PS8", list("ABCDEFGHIJKL"), "XXXXYYYYZZZZ", "X, Y, Z = the three teams")],
                   look={"yes": True, "groups": [("A", "team X", "4"), ("A", "team Y", "4"), ("A", "team Z", "4")], "divisor_terms": [3],
                         "text": "Look-alike groups? Yes. All three teams have 4 and no names. The groups spell A A A, so shuffling X, Y, Z gives the same teams."},
                   tiny={"items": sorted(split_names(b, "ABCDEF") for b in partitions_brute(6, (2, 2, 2), False)), "value": 15, "cols": 3,
                         "note": "90 words ÷ 3! = 15",
                         "text": "Tiny case: 6 players into three teams of 2. Words XXYYZZ: 90. Group word AAA, so ÷ 3! = 15, listed."},
                   answer=5775)
S["ps8"] = f
H["ps8"] = [dict(hint="Tag each player X, Y or Z. Count the words. The three teams are the same size with no names: what's their group word?",
                 nudges=["Plan step 1: tag each player with a team letter. How many of each?",
                         "Plan step 2: count the words with 4 X's, 4 Y's and 4 Z's.",
                         "Plan step 3: the three teams look alike. Write their group word and divide by its repeats."])]

tiny9a = sorted(" | ".join("".join("ABCDE"[i] for i in sorted(g)) for g in sorted(b, key=len)) for b in partitions_brute(5, (2, 3), False))
f, t = build_story("PS9", [Part("PS9", list("ABCDEFGHIJKL"), "aabbccdddeee", "a, b, c = the three pairs; d, e = the two trios")],
                   look={"yes": True, "groups": [("A", "a", ""), ("A", "b", ""), ("A", "c", ""), ("B", "d", ""), ("B", "e", "")], "divisor_terms": [3, 2],
                         "text": "Look-alike groups? Yes. The pairs look alike (A A A) and the trios look alike (B B), but a pair never looks like a trio. The groups spell A A A B B: divide by 3! × 2!, not 5!.",
                         "ask": "Which letters in A A A B B can trade places?"},
                   tiny={"items": tiny9a, "value": 10, "cols": 5, "cellw": 70,
                         "text": "Tiny case: 5 kids into a pair and a trio (group word A B). 10 words, no look-alikes, listed: nothing repeats."},
                   answer=138600)
f.insert(-2, Fr(3, v.calc(["1,663,200", "÷", "5!", "=", "13,860"], "tempting", crossed=True, note="5! treats A A A B B like A A A A A"),
                "Tempting: divide by 5!. That would mean a pair could trade places with a trio. It can't."))
f.append(Fr(4, v.outcome_list(sorted(split_names(b, "ABCD") for b in partitions_brute(4, (2, 2), False)), cols=3, note="6 words ÷ 2! = 3"),
            "Second tiny case: 4 kids into two pairs (group word A A). 6 tag words, each split twice, so 3, listed."))
V("PS9 tiny2", len(partitions_brute(4, (2, 2), False)), 3)
S["ps9"] = f
H["ps9"] = [dict(hint="Tag each student with a group letter: a, b, c for the pairs and d, e for the trios. Count the tag words.",
                 nudges=["Plan step 1: there are five group letters. How many students get each?",
                         "Plan step 2: count the words with a a b b c c d d d e e e.",
                         "Plan step 2 again: for a word with repeated letters, divide n! by each letter's repeats."]),
            dict(hint="Write the groups themselves as a word: each pair-group is an A and each trio-group is a B, so A A A B B. Only identical letters can trade places.",
                 nudges=["Plan step 3: which groups look alike (same size, no names)?",
                         "Plan step 3: write the groups as a word with A for a pair and B for a trio. Divide by that word's repeats.",
                         "Can a pair ever trade places with a trio?"])]

f, t = build_story("PS10", [Part("PS10 boys", [f"b{i}" for i in range(1, 7)], "XXYYLL", "boys: X = first committee, Y = second, L = neither"),
                            Part("PS10 girls", [f"g{i}" for i in range(1, 7)], "XYXYLL", "girls: the same three tags")],
                   combine="×",
                   look={"yes": True, "groups": [("A", "X", "4"), ("A", "Y", "4")], "divisor_terms": [2],
                         "text": "Look-alike groups? Yes. Both committees have 2 boys and 2 girls and no names. The groups spell A A."},
                   tiny={"items": ["b1g1 & b2g2", "b1g2 & b2g1"], "value": 2, "cols": 2, "cellw": 110, "note": "boys XY × girls XY = 4 words, ÷ 2! = 2",
                         "text": "Tiny case: boys b1, b2 and girls g1, g2, two committees of 1 + 1. 2 × 2 = 4 words, each pair of committees twice: 2, listed."},
                   answer=4050)
V("PS10 tiny", len({frozenset(pr) for pr in [frozenset((frozenset(("b1", g1)), frozenset(("b2", g2)))) for g1, g2 in (("g1", "g2"), ("g2", "g1"))]}), 2)
S["ps10"] = f
H["ps10"] = [dict(hint="Tag the boys X (first committee), Y (second) or L (neither) for one committee only: just the X's matter here.",
                  nudges=["Plan step 1: one committee needs 2 boys and 2 girls. Tag boys and girls separately.",
                          "Plan step 2: the boys' word and the girls' word are separate words. Do they add or multiply?",
                          "Plan step 2: count each word with the repeated-letters rule."]),
             dict(hint="Tag each boy X, Y or L, and each girl X, Y or L. Multiply the two word counts. Then: are the committees look-alikes?",
                  nudges=["Plan step 1: each boy and each girl gets X, Y or L.",
                          "Plan step 2: count the boys' words and the girls' words, then combine.",
                          "Plan step 3: the two committees are the same size with no names."])]

kids = ["Ana", "Ben", "Cal", "Dee"]
V("PS11 doubled kid", len(kids), 4)
words11 = sum(1 for w in product("ABCD", repeat=5) if len(set(w)) == 4)
V("PS11 all words", words11, 240)
f, t = build_story("PS11", [
    Part("PS11 kid", kids, "2111", "which kid gets 2 jobs", counts={"x": 4}, value=4, formula="4 kids",
         pic=v.chips_row(kids, {"Ana": "picked"}, w=48, caption="one kid appears twice in the word"),
         tag_text="Tag each job with the kid who does it: A, B, C or D. Every kid appears, so one kid's letter appears twice. First: which kid? 4 choices.",
         count_text="Any of the 4 kids could be the one who appears twice: 4 ways."),
    Part("PS11 jobs", ["Dishes", "Pets", "Trash", "Laundry", "Garden"], "AABCD", "the kid letter on each job (Ana does two)", ow=64,
         tag_text="Then each job gets its kid's letter. With Ana doubled, the word uses A, A, B, C, D.",
         count_text="Words with A, A, B, C, D: 5! ÷ 2! = 60.")],
    combine="×", look={"reason": "the kids have names, so no two kids are look-alikes"},
    tempting=[(["5·4·3·2", "×", "4", "=", "480"], "Tempting: 480 (one job each, then the spare to anyone). It builds each word twice: Ana's two jobs could be 'first' either way.")],
    tiny={"items": [w for w in words_list("AAB") + words_list("ABB")], "value": 6, "cols": 6,
          "text": "Tiny case: 3 jobs for kids A and B, both used. Words: AAB, ABA, BAA, ABB, BAB, BBA. That's 2 × 3 = 6, listed."},
    answer=240, part_word_pics=False)
S["ps11"] = f
H["ps11"] = [dict(hint="Tag each job with the kid who does it. 5 tags, 4 kids, every kid used.",
                  nudges=["Tag the jobs first: each job gets a kid letter. How many letters, how many different kids?",
                          "If every kid's letter appears at least once in a 5-letter word, how many letters are repeats?",
                          "5 jobs, 4 kids, nobody empty-handed."]),
             dict(hint="Pick the kid whose letter appears twice. Then count the words with that letter twice and the other three once.",
                  nudges=["Plan step 1: write one assignment as a word of kid letters.",
                          "Plan step 2: choose which kid repeats, then count the words with the repeated-letters rule.",
                          "Plan step 3: the kids have names. Is anything a look-alike?"])]

f, t = build_story("PS12", [Part("PS12", list("ABCDEFGH"), "TLLLLLTL", "T = an endpoint, L = not used (A and G here)",
                                 pic=v.vstack(v.cube(hl=[("A", "G")]), tag_row(list("ABCDEFGH"), "TLLLLLTL")))],
                   look={"reason": NO_TL},
                   tiny={"items": pick_list("TTLL", "ABCD"), "value": 6, "cols": 3, "cellw": 92,
                         "text": "Tiny case: a square's 4 corners. Words with 2 T and 2 L: 6 segments (4 sides, 2 diagonals), listed."},
                   answer=28)
S["ps12"] = f
H["ps12"] = [dict(hint="A segment is decided by its 2 endpoints. Tag the corners T (endpoint) or L and count the words.",
                  nudges=["Plan step 1: what decides a segment? Tag those.", "Plan step 2: count words with 2 T's and 6 L's.",
                          "Plan step 3: can T and L trade places?"])]

oct_pts = v.polygon_points(8, r=72, cx=110, cy=100)
V("PS13 sides", sum(1 for a, b in combinations(range(8), 2) if (b - a) % 8 in (1, 7)), 8)
pd = [a + b for a, b in combinations("ABCDE", 2) if (ord(b) - ord(a)) % 5 not in (1, 4)]
f, t = build_story("PS13", [Part("PS13", list("ABCDEFGH"), "TLLTLLLL", "T = an end of the segment, L = not used (A and D here)",
                                 pic=v.vstack(v.dots(oct_pts, [(a, b) for a, b in zip("ABCDEFGH", "BCDEFGHA")], hl=[("A", "D")], W=220, H=200),
                                              tag_row(list("ABCDEFGH"), "TLLTLLLL"))),
                            Part("PS13 sides", ["AB", "BC", "CD", "DE", "EF", "FG", "GH", "HA"], "SSSSSSSS", "neighbours make a side, not a diagonal",
                                 pic=v.dots(oct_pts, [], hl=[(a, b) for a, b in zip("ABCDEFGH", "BCDEFGHA")], W=220, H=200, note="the 8 sides"),
                                 counts={"S": 8}, value=8, formula="8 sides", count_text="But 8 of those words are neighbours, which make sides, not diagonals.",
                                 tag_text="Some of those tag words join neighbours: those are the 8 sides.")],
                   combine="−", look={"reason": NO_TL},
                   tiny={"items": pd, "value": 5, "cols": 5, "text": "Tiny case: a pentagon. Words with 2 T and 3 L: 10, minus 5 sides = 5 diagonals, listed."},
                   answer=20, part_word_pics=True)
S["ps13"] = f
H["ps13"] = [dict(hint="Tag the 2 ends of a segment T and the rest L. Count the words, then take away the ones that are sides.",
                  nudges=["Plan step 1: what decides a diagonal? Tag those corners.",
                          "Plan step 2: count words with 2 T's and 6 L's.",
                          "Some of those pairs are neighbours. Are they diagonals?"])]

t14 = ["12", "10", "20", "21"]
V("PS14 tiny", len(t14), comb(2, 2) + comb(3, 2))
f, t = build_story("PS14", [Part("PS14 inc", [str(d) for d in range(1, 10)], "TLLTLLTLL", "increasing: tag digits 1–9 T (used) or L; 0 can't be used",
                                 tag_text="Case 1, increasing: tag the digits 1–9 T (used) or L. 0 can't lead, so it's left out. Once the digits are tagged, the order is forced: 147."),
                            Part("PS14 dec", [str(d) for d in range(10)], "LLTLLTLLTL", "decreasing: tag digits 0–9 T or L",
                                 tag_text="Case 2, decreasing: tag the digits 0–9. Now 0 is allowed, because it sits at the end (like 210). Tagging 2, 5, 8 gives 852.")],
                   combine="+", look={"reason": "no number is both increasing and decreasing, and T and L can't swap"},
                   tiny={"items": t14, "value": 4, "cols": 4,
                         "text": "Tiny case: two-digit numbers from 0, 1, 2. Increasing: 12 (1 word). Decreasing: 10, 20, 21 (3 words). Total 4, listed."},
                   answer=204)
S["ps14"] = f
H["ps14"] = [dict(hint="Tag the digits 1–9 T (used) or L. The tagged digits can only be written one increasing way.",
                  nudges=["Plan step 1: once you know which 3 digits are used, how many increasing orders are there?",
                          "Can 0 be a tagged digit in an increasing number?", "Plan step 2: count the words with 3 T's among the allowed digits."]),
             dict(hint="Tag the digits 0–9 T or L. The tagged digits can only be written one decreasing way, and 0 is fine at the end.",
                  nudges=["Plan step 1: which digits can be tagged now?", "Can a decreasing number end in 0?",
                          "Plan step 2: count the words with 3 T's among the allowed digits."]),
             dict(hint="Two cases that can't overlap: add them.",
                  nudges=["Can a number be both increasing and decreasing?", "Plan step 2: separate cases add.", "Use steps 1 and 2."])]

c3 = [(r, c) for r in range(3) for c in range(3)]
t15 = sorted("".join(str(c + 1) for r, c in sorted(tt)) for tt in combinations(c3, 3)
             if len({x[0] for x in tt}) == 3 and len({x[1] for x in tt}) == 3)
f, t = build_story("PS15", [Part("PS15 rows", ["r1", "r2", "r3", "r4", "r5"], "TLTTL", "rows: T = has a block, L = empty",
                                 tag_text="Start with the most restricting part. Tag each row T (has a block) or L. Here rows 1, 3, 4."),
                            Part("PS15 cols", ["c1", "c2", "c3", "c4", "c5"], "31LL2", "columns: 1, 2, 3 = used by the 1st, 2nd, 3rd chosen row; L = empty",
                                 tag_text="Tag each column with which chosen row uses it: 1 (top), 2, 3 (bottom), or L. The tags 1, 2, 3 are all different.",
                                 count_text="Column words with 1, 2, 3 once and L twice: 5! ÷ 2! = 60.")],
                   combine="×", look={"reason": "the rows are tied to the columns one by one, so no groups can trade places"},
                   tiny={"items": t15, "value": 6, "cols": 6,
                         "text": "Tiny case: a 3-by-3 square, 3 blocks. Row word TTT: 1; column words with 1, 2, 3: 6. Listed by column, row by row."},
                   answer=600)
S["ps15"] = f
H["ps15"] = [dict(hint="Tag the rows T or L (which 3 rows have a block). Then tag the columns with which chosen row uses them: 1, 2, 3, or L. Two words multiply.",
                  nudges=["Plan step 1: which part of the rule restricts you most? Tag that first.",
                          "Plan step 2: the row word has 3 T's and 2 L's. The column word has three different tags and 2 L's.",
                          "Plan step 2: two separate words multiply."])]

ok8 = ["▼" * (8 - k) + "▲" * k for k in range(9)]
V("PS16 faces", len([o for o in product((0, 1), repeat=8) if all(not (o[i] == 1 and o[i + 1] == 0) for i in range(7))]), 9)
t16 = []
for cols in sorted(set(permutations("GGS"))):
    for o in product((0, 1), repeat=3):
        if all(not (o[i] == 1 and o[i + 1] == 0) for i in range(2)):
            t16.append("".join(cols) + " " + "".join("▲" if x else "▼" for x in o))
f, t = build_story("PS16", [Part("PS16 colours", [str(i) for i in range(1, 9)], "GSGGSSGS", "colour word: G gold or S silver, bottom to top"),
                            Part("PS16 faces", [str(i) for i in range(1, 9)], "▼▼▲▲▲▲▲▲", "face word: ▼ face down or ▲ face up",
                                 counts={"x": 9}, value=9, formula="9 face words",
                                 pic=v.outcome_list(ok8, cols=3, cellw=104, note="allowed face words: some ▼, then all ▲"),
                                 count_text="Face words: a ▲ coin can't sit under a ▼ coin, so the allowed words are some ▼'s then all ▲'s: 9.",
                                 tag_text="Second word: tag each coin ▼ (face down) or ▲ (face up). Faces touch only when ▲ sits right under ▼.")],
                   combine="×", look={"reason": "gold coins are identical (already handled by the repeated G's), and nothing else can swap"},
                   tiny={"items": t16, "value": 12, "cols": 4, "cellw": 78,
                         "text": "Tiny case: 2 gold, 1 silver. Colour words GGS: 3; face words: 4; 3 × 4 = 12, listed."},
                   answer=630)
S["ps16"] = f
H["ps16"] = [dict(hint="Tag each spot in the stack G or S. It's a word with 4 G's and 4 S's.",
                  nudges=["Plan step 1: tag each of the 8 spots with a colour.", "Plan step 2: swapping two gold coins doesn't make a new word.",
                          "Plan step 2: use the repeated-letters rule."]),
             dict(hint="Tag each coin ▼ or ▲. Once a ▲ appears, everything above it must be ▲. List the allowed words.",
                  nudges=["Which pair of neighbours touches face to face?", "Once a coin is face-up, what must every coin above it be?",
                          "List the 3-coin version first."]),
             dict(hint="The colour word and the face word are separate words. Separate words multiply.",
                  nudges=["Does each colour word work with each face word?", "Plan step 2: separate words multiply.", "Use steps 1 and 2."])]

rows17 = [[str(n), fmt(comb(n, 3)), fmt(comb(n, 6)), fmt(6 * comb(n, 3))] for n in (10, 11, 12, 13, 14)]
S["ps17"] = [
    Fr(1, tag_row([str(i) for i in range(1, 11)], "TTLTTLLTTL", note="a set of 6: 6 T's (10 of n cards shown)"),
       "Tag the cards: T = in the set, L = not. A set of 6 is a word with 6 T's; a set of 3 is a word with 3 T's."),
    Fr(2, v.table(["n", "words with 3 T", "words with 6 T", "6 × (words with 3 T)"], rows17, hl=3),
       "Count both kinds of word for different n. The rule says the 6-T count must be 6 times the 3-T count."),
    Fr(2, v.card(["(6-T words) ÷ (3-T words) = (n−3)(n−4)(n−5) ÷ 120", "= 6  →  (n−3)(n−4)(n−5) = 720 = 10 × 9 × 8"], "cancel", W=440),
       "Or cancel the factorials: three numbers in a row must multiply to 720 = 10 × 9 × 8, so n − 3 = 10."),
    Fr(3, v.card(["No look-alike groups"], "no", W=260), "Look-alike groups? No: T and L can't swap. Nothing to divide."),
    Fr(4, v.calc(["6 × 286", "=", "1,716"], "check"), "Check n = 13: 286 words with 3 T's, 1,716 words with 6 T's, and 6 × 286 = 1,716. ✓"),
]
H["ps17"] = [dict(hint="Tag the cards T (in the set) or L. Make a table of n against the number of words with 6 T's and with 3 T's.",
                  nudges=["Plan step 1: a set of cards is a T/L word. How many T's for a set of 6?",
                          "Plan step 2: try a value of n and count both kinds of word.",
                          "If the 6-T count is too small, should n go up or down?"])]

S["ps18"] = [
    Fr(1, v.vstack(v.dots(v.polygon_points(6, r=70, cx=110, cy=95), [(a, b) for a, b in combinations("ABCDEF", 2)], hl=[("A", "D")], W=220, H=190),
                   tag_row(list("ABCDEF"), "PLLPLL", note="a game: its 2 players tagged P")),
       "Tag a game's two players P and everyone else L. A game is a word with 2 P's."),
    Fr(2, v.card(["games by the 5 who left: 5 × 2 = 10", "games among those who stayed: 220 − 10 = 210"], "two kinds", W=380),
       "Two kinds of game, which add to 220. The 5 who left played 10 games, none against each other."),
    Fr(2, v.calc(["n × (n − 1) ÷ 2", "=", "210"], "stayers"),
       "Among the n players who stayed, the games are words with 2 P's and n − 2 L's: n × (n − 1) ÷ 2 = 210, so n × (n − 1) = 420 = 21 × 20."),
    Fr(3, v.card(["No look-alike groups"], "no", W=260), "Look-alike groups? No: P and L can't swap. Nothing more to divide."),
    Fr(3, v.calc(["21", "+", "5", "=", "26"], "total"), "21 stayed + 5 withdrew = 26 players."),
    Fr(4, v.outcome_list([x.replace("T", "P") for x in pick_list("TTLL", "ABCD")], cols=3, cellw=92, note="4 players: 6 games"),
       "Tiny case: 4 players. Words with 2 P's and 2 L's: 6 games, listed."),
]
V("PS18 tiny", len(pick_list("TTLL", "ABCD")), 6)
V("PS18 stayers", comb(21, 2), 210)
H["ps18"] = [dict(hint="5 players × 2 games, and none of those games were between two of them.", nudges=["Each played 2.", "Could a game be counted twice?", "Count their games."]),
             dict(hint="Every game is one kind or the other.", nudges=["Take away, don't add.", "Use step 1.", "Separate cases add up to the total."]),
             dict(hint="A game among the stayers is a word with 2 P's. Find n where that count is 210: n × (n − 1) = 420.",
                  nudges=["Plan step 2: how many games does a round robin of n players have?", "Find two numbers in a row that multiply to 420.",
                          "Check your n by counting its games."]),
             dict(hint="Stayers plus the ones who withdrew.", nudges=["Who is missing from step 3?", "Add the players who withdrew.", "Step 3 plus the withdrawn players."])]

f, t = build_story("CH1", [Part("CH1", list("ABCDEFGH"), "XYXXYYXY", "X = one team, Y = the other")],
                   look={"yes": True, "groups": [("A", "team X", "4"), ("A", "team Y", "4")], "divisor_terms": [2],
                         "text": "Look-alike groups? Yes: two teams of 4 with no names. The groups spell A A."},
                   tiny={"items": sorted(split_names(b, "ABCD") for b in partitions_brute(4, (2, 2), False)), "value": 3, "cols": 3, "note": "6 ÷ 2! = 3",
                         "text": "Tiny case: 4 players into two pairs: 6 words, 3 real splits, listed."},
                   answer=35)
S["ch1"] = f
H["ch1"] = [dict(hint="Tag each player X or Y. Count the words. Two teams of 4 with no names are look-alikes.",
                 nudges=["Plan step 1: tag each player with a team letter.", "Plan step 2: count the words with 4 X's and 4 Y's.",
                         "Plan step 3: the teams have no names. What does swapping X and Y do?"])]

f, t = build_story("CH2", [Part("CH2 slanted", [str(i) for i in range(1, 7)], "LTLTLL", "slanted lines: T = a side of the shape, L = not",
                                pic=v.vstack(v.skew_grid(5, 4, hl_v=(1, 3), hl_h=(0, 2)), tag_row([str(i) for i in range(1, 7)], "LTLTLL")),
                                tag_text="What decides a parallelogram? Two slanted lines and two flat lines. Tag the 6 slanted lines T or L."),
                           Part("CH2 flat", [str(i) for i in range(1, 6)], "TLTLL", "flat lines: T or L", tag_text="And tag the 5 flat lines T or L.")],
                   combine="×", look={"reason": "slanted and flat lines are different, and T and L can't swap"},
                   tiny={"items": [f"{a}{b}" for a in ("12", "13", "23") for b in ("ab", "ac", "bc")], "value": 9, "cols": 3,
                         "text": "Tiny case: a 2-by-2 slanted grid. 3 slanted words × 3 flat words = 9 parallelograms (slanted pair + flat pair), listed."},
                   answer=150)
S["ch2"] = f
H["ch2"] = [dict(hint="Tag the slanted lines T or L, and the flat lines T or L. Two separate words multiply.",
                 nudges=["Plan step 1: what decides a parallelogram here? Not its corners.", "Plan step 2: count each kind of line's words.",
                         "Plan step 2: two separate words multiply."])]

rows33 = [["{1, 2}", "2", "too small"], ["{1, 5}", "20", "too small"], ["{1, 10}", "90", "too big"], ["{2, 5}", "50", "works"], ["{5, 5}", "200", "too big"]]
S["ch3"] = [
    Fr(1, v.vstack(tag_row(["R1", "R2", "B1", "B2", "B3", "B4", "B5"], "TTLLTLL", note="one mixed team: R1, R2, B3")),
       "Tag the students T (on the team) or L. A team is a word with 3 T's that uses both colours."),
    Fr(2, v.card(["case 1: 2 red T's + 1 blue T", "case 2: 1 red T + 2 blue T's", "never both → add"], "cases", W=320),
       "Two cases that can't overlap: count each and add."),
    Fr(2, v.calc(["(r choose 2)·b", "+", "r·(b choose 2)", "=", "25"], "equation"),
       "With r red and b blue: (r choose 2) × b + r × (b choose 2) = 25. Doubling and factoring gives r × b × (r + b − 2) = 50."),
    Fr(2, v.table(["{r, b}", "r·b·(r+b−2)", "result"], rows33, hl=3), "Try pairs whose product divides 50: only {2, 5} gives 50."),
    Fr(3, v.card(["No look-alike groups"], "no", W=260), "Look-alike groups? No. The ÷ 2 inside each 'choose 2' already handled the repeated T's."),
    Fr(4, v.outcome_list([" ".join(tt) for tt in combinations(["R1", "R2", "B1", "B2", "B3", "B4", "B5"], 3) if sum(s[0] == "R" for s in tt) == 2],
                         cols=5, cellw=74, note="2-red teams: 5; 1-red teams: 2 × 10 = 20"),
       "Check with 2 red and 5 blue: the 5 two-red teams are listed; the one-red teams number 2 × 10 = 20. Total 25. ✓"),
]
for rb, val, _ in rows33:
    a, b2 = [int(x) for x in rb.strip("{}").split(",")]
    V(f"CH3 table {rb}", a * b2 * (a + b2 - 2), int(val))
H["ch3"] = [dict(hint="Two cases: 2 red + 1 blue, or 1 red + 2 blue. Count each with r and b, add, and set equal to 25. Then try values.",
                 nudges=["Plan step 1: tag the team T. Which colour mixes are allowed?", "Plan step 2: separate cases add.", "Try small numbers of red and blue."]),
            dict(hint="Red plus blue.", nudges=["Use step 1.", "Every student wears one of the two colours.", "Add."])]
