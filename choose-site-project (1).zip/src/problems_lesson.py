"""Lesson page guided problems, one per concept, taken from the lecture notes / class video."""
from pcommon import *

LESSON = []
SEC = "Guided problems from class"

# ---------------------------------------------------------------- L1  Example 1.1 (C1)
LESSON.append(problem(
    "l1", "lesson", SEC, "Example 1.1",
    "How many combinations of two different letters are possible using the letters A, B, C, D?",
    [step("How many different two-letter combinations are there?", 6,
          ["Write one combination down, then write it with the letters swapped. Are those two different combinations?",
           "Try listing them with A first, then with B first (but no A), then C first. Does the list repeat anything?",
           "Count the lists where order matters, then ask how many of those lists show the same pair."],
          "Count first-letter, second-letter lists (4 choices, then 3). Each pair of letters shows up in that count more than once.",
          "4 × 3 ÷ 2 = 6: AB, AC, AD, BC, BD, CD.", "Listing: AB, AC, AD, BC, BD, CD has six pairs and no repeats.",
          "Each pair was counted twice in the ordered count, so you halved it.",
          named={12: "That counts AB and BA as two different combinations. Are they?",
                 16: "That lets a letter be used twice, like AA.", 24: "That's the number of ways to line up all four letters.",
                 4: "That's how many letters there are, not how many pairs.", 3: "That's only the pairs that start with A."})],
    choose_story("L1", list("ABCD"), 2, ["A", "C"], "combination", "letters", list("ABC"),
                 ask_twins="Which entry is the twin of AC?"),
    "6", "4 × 3 = 12 ordered lists; each pair appears twice; 12 ÷ 2 = 6. Listed: AB AC AD BC BD CD.",
    concept="c1", inclass="01:50"))

# ---------------------------------------------------------------- L2  Example 1.2 (C2)
LESSON.append(problem(
    "l2", "lesson", SEC, "Example 1.2",
    "There are 7 different marbles in a bag. We reach into the bag and grab three of the marbles without looking. "
    "How many possible combinations of 3 marbles could we grab?",
    [step("How many different groups of 3 marbles could we grab?", 35,
          ["Does it matter which marble your fingers touched first?",
           "Count as if the marbles came out one at a time. How many of those lists hold the same three marbles?",
           "Write out every order of three particular marbles, say A, D, G. How many are there?"],
          "Count first, second, third marble lists. Then work out how many lists show the very same three marbles, and divide by that.",
          "7 × 6 × 5 ÷ (3 × 2 × 1) = 210 ÷ 6 = 35.", "Same as 7!/(3!·4!) = 35.",
          "Each group of 3 had 6 orders hiding in the 7 × 6 × 5 count.",
          named={210: "That counts ADG and GDA as different grabs. They're the same three marbles.",
                 70: "You divided by 3. Write every order of A, D, G: how many are there?",
                 105: "How many orders does a group of three have, not two?", 343: "Can the same marble come out twice?",
                 21: "Is it one choice of 7 and one of 3, or three choices in a row?"})],
    choose_story("L2", list("ABCDEFG"), 3, ["A", "D", "G"], "grab", "marbles", list("ABCD")),
    "35", "7 × 6 × 5 = 210 ordered; each group appears 3! = 6 times; 210 ÷ 6 = 35 = 7!/(3!4!).",
    concept="c2", inclass="07:12"))

# ---------------------------------------------------------------- L3  12 choose 10 (C3)
labs12 = list("ABCDEFGHIJKL")
take = labs12[:10]
V("L3: take 10 of 12", len(list(combinations(labs12, 10))), comb(12, 2))
V("L3: leave-2 ordered", len(list(permutations(labs12, 2))), 12 * 11)
tiny3 = ["".join(c) for c in combinations("ABCD", 3)]
V("L3: tiny take 3 of 4", len(tiny3), comb(4, 1))
L3_story = [
    Fr(1, v.bag_of(labs12, picked=take, label="12 marbles, 10 taken"), "One handful of 10: A through J. K and L stay in the bag."),
    Fr(2, v.chips_row(labs12, {**{x: "picked" for x in take}, "K": "banned", "L": "banned"}, per_row=12,
                      caption="10 taken, 2 left"),
       "We choose 10 of 12. But every handful of 10 also picks out the 2 that stay behind.",
       ask="Can two different handfuls of 10 leave the same 2 behind?"),
    Skip(3, "one kind of handful, every marble allowed"),
    Fr(4, v.card(["A, B, … , J  =  J, I, … , A", "left behind: {K, L}"], "swap test", W=320, note="same handful"),
       "Reordering the 10 doesn't change the handful, and it doesn't change the 2 left behind either."),
    Fr(5, slots_from([("1st left", "12"), ("2nd left", "11")], "132", note="build the 2 that stay"),
       "Build the short side: the 2 that stay. 12 choices, then 11, so 132 lists."),
    Fr(6, v.bundle([("K", "L"), ("L", "K")], ["K", "L"], label="twins"),
       "Twins? Yes. Leaving K then L is the same as leaving L then K.",
       ask="Why is building the 2 that stay easier than building the 10 you take?"),
    Fr(6, v.calc(["132", "÷", "2", "=", "66"], "divide"), "132 ÷ 2 = 66. So 12 choose 10 = 12 choose 2 = 66."),
    Fr(7, v.outcome_list(tiny3, cols=4, note="take 3 of 4 = leave 1 of 4"),
       "Tiny case: take 3 of A, B, C, D. Each handful leaves one marble behind, so there are 4, and the list has 4."),
]
LESSON.append(problem(
    "l3", "lesson", SEC, "From class",
    "There are 12 different marbles in a bag. You take 10 of them. How many different groups of 10 marbles could you take?",
    [step("How many different groups of 10 could you take?", 66,
          ["When you take 10 marbles, what else have you decided at the same moment?",
           "Counting the 10 you take is long. Is there a shorter group you could count instead?",
           "Count the marbles that stay in the bag. Does the order you leave them in matter?"],
          "Every handful of 10 leaves exactly 2 behind, and every 2 left behind matches exactly one handful. Count the pairs left behind.",
          "12 choose 10 = 12 choose 2 = 12 × 11 ÷ 2 = 66.", "12!/(10!·2!) = (12 × 11)/2 = 66.",
          "Taking 10 is the same as leaving 2.",
          named={132: "That counts leaving K then L as different from leaving L then K.",
                 2: "That's how many stay behind, not how many ways.",
                 120: "That's 12 × 10. Which two numbers count the marbles that stay?",
                 24: "That's 12 × 2. Count first-left, second-left choices."})],
    L3_story, "66", "Leave 2 of 12: 12 × 11 ÷ 2 = 66. Checked: 12!/(10!2!) = 66.", concept="c3", inclass="19:52"))

# ---------------------------------------------------------------- L4  Example 1.4 (C4)
V("L4: first bag", len(list(combinations(range(9), 4))), 126)
V("L4: second bag", len(list(combinations(range(5), 3))), 10)
V("L4: total", len(partitions_brute(9, (4, 3, 2))), 1260)
tiny4 = sorted(split_names(b, "ABC") for b in partitions_brute(3, (2, 1)))
V("L4: tiny 3 cookies into 2/1", len(tiny4), comb(3, 2))
ck = list("ABCDEFGHI")
L4_story = [
    Fr(1, v.bags([("bag 1", list("ABCD"), 4), ("bag 2", list("EFG"), 3), ("bag 3", list("HI"), 2)]),
       "One way: A, B, C, D in the first bag; E, F, G in the second; H, I in the third."),
    Fr(2, v.chips_row(ck, caption="9 cookies into bags of 4, 3, 2"), "All 9 cookies get used: 4, then 3, then the last 2."),
    Skip(3, "every cookie can go in any bag"),
    Fr(4, v.same_split([list("ABCD"), list("EFG")], [list("DCBA"), list("GFE")], note="order inside a bag doesn't matter"),
       "Shuffling cookies inside a bag changes nothing. Moving a cookie to another bag does.",
       ask="Why can't the 4-cookie bag and the 3-cookie bag ever trade places?"),
    Fr(5, v.bags([("bag 1", list("ABCD"), 4)], pool=ck, pool_states={x: "picked" for x in "ABCD"}),
       "First bag: choose 4 of 9, which is 9 choose 4 = 126."),
    Fr(5, v.bags([("bag 2", list("EFG"), 3)], pool=ck, pool_states={**{x: "used" for x in "ABCD"}, **{x: "picked" for x in "EFG"}}),
       "Second bag: only 5 are left, choose 3: 10. Whoever went in bag 1, 5 are always left, so the count stays 10."),
    Fr(5, slots_from([("bag 1", "126"), ("bag 2", "10"), ("bag 3", "1")], "1,260", note="bag 3 takes the last 2: 1 way"),
       "Third bag: the last 2, one way (2 choose 2 = 1, because 0! = 1). Multiply: 126 × 10 × 1 = 1,260."),
    Fr(6, v.same_split([list("ABCD"), list("EFG")], [list("EFG"), list("ABCD")], same=False,
                       note="a 4-bag and a 3-bag can't swap"),
       "Twins? No. The bags hold different numbers, so no split gets built twice."),
    Fr(7, v.outcome_list(tiny4, cols=3, note="3 choose 2 × 1 choose 1 = 3"),
       "Tiny case: cookies A, B, C into a bag of 2 and a bag of 1. The rule says 3, and the list has 3."),
]
LESSON.append(problem(
    "l4", "lesson", SEC, "Example 1.4",
    "There are 9 different cookies on a tray. You take 4 of the cookies in a bag, then 3 of the remaining cookies in a "
    "second bag, and the last 2 cookies in a third bag. How many ways are there to do this?",
    [step("How many ways can the first bag be filled?", 126,
          ["Does the order the 4 cookies go into the bag matter?",
           "Count first, second, third, fourth cookie lists, then think about repeats.",
           "One set of 4 cookies can go in as how many different lists?"],
          "Choose 4 of the 9 cookies without order: count ordered lists, then divide by the orders of 4.",
          "9 choose 4 = 9 × 8 × 7 × 6 ÷ 24 = 126.", "9!/(4!·5!) = 126.", "That's the first bag."),
     step("Once the first bag is full, how many ways can the second bag be filled?", 10,
          ["How many cookies are still on the tray?", "Choose 3 from what's left. Does order matter in the bag?",
           "Count ordered lists of 3 from what's left, then remove the orders."],
          "5 cookies remain; choose 3 of them without order.", "5 choose 3 = 5 × 4 × 3 ÷ 6 = 10.",
          "Same as 5 choose 2 = 10 (choose the 2 that stay out).", "Whoever went in bag 1, there are always 5 left.",
          named={84: "That chooses from all 9 again. Some are already in bag 1.", 60: "That's 5 × 4 × 3 in order. Does the bag care about order?",
                 126: "That's step 1's answer."}),
     step("How many ways to do the whole thing?", 1260,
          ["Does each first-bag choice go with each second-bag choice?",
           "What decides bag 3 once bags 1 and 2 are full?",
           "Put the three counts together the way independent decisions combine."],
          "Bag 3 is forced. Combine the counts for bag 1 and bag 2: every pairing makes a different result.",
          "126 × 10 × 1 = 1,260.", "Also 9!/(4!·3!·2!) = 1,260.", "Three decisions in a row multiply.",
          named={136: "Adding counts 'bag 1 OR bag 2'. Here you do bag 1 AND bag 2.",
                 210: "Dividing by 3! would mean the bags could trade places. Can a 4-bag trade with a 3-bag?",
                 362880: "That's 9!. It also counts the order of cookies inside each bag.", 126: "That's step 1's answer.",
                 10: "That's step 2's answer."})],
    L4_story, "1,260", "126 × 10 × 1 = 1,260 = 9!/(4!3!2!). Checked by listing every way to bag the 9 cookies.",
    concept="c4", inclass="22:39"))

# ---------------------------------------------------------------- L5  Example 1.5 (C5)
V("L5: named", len(partitions_brute(10, (5, 5), True)), 252)
V("L5: unnamed", len(partitions_brute(10, (5, 5), False)), 126)
tiny5 = sorted(split_names(b, "ABCD") for b in partitions_brute(4, (2, 2), False))
V("L5: tiny named", len(partitions_brute(4, (2, 2), True)), 6)
V("L5: tiny unnamed", len(tiny5), 3)
L5_story = [
    Fr(1, v.bags([("a bag", list("ABCDE"), 5), ("a bag", list("FGHIJ"), 5)]),
       "One way: A, B, C, D, E in one bag and F, G, H, I, J in the other."),
    Fr(2, v.chips_row(list("ABCDEFGHIJ"), caption="10 cookies, two bags of 5"), "Evenly means 5 in each bag."),
    Skip(3, "every cookie can go in either bag"),
    Fr(4, v.same_split([list("ABCDE"), list("FGHIJ")], [list("FGHIJ"), list("ABCDE")], note="identical bags"),
       "Swap the two whole bags. The bags are identical, so it's the same way of dividing.",
       ask="Identical bags are like identical letters from last week. How?"),
    Fr(5, v.calc(["10 choose 5", "×", "5 choose 5", "=", "252"], "named count", crossed=False,
                 note="pretend one bag is 'first'"),
       "Pretend one bag is first: choose its 5 (252 ways), and the other bag takes the rest (1 way). That's 252."),
    Fr(6, v.same_split([list("ABCDE"), list("FGHIJ")], [list("FGHIJ"), list("ABCDE")], note="built twice"),
       "Twins? Yes. ABCDE-first and FGHIJ-first are the same split, so every split was built twice. 252 isn't wrong, it's unfinished."),
    Fr(6, v.calc(["252", "÷", "2!", "=", "126"], "divide"), "Divide by 2! for the two ways to name the bags: 126."),
    Fr(7, v.outcome_list(tiny5, cols=3, note="named 6 ÷ 2 = 3"),
       "Tiny case: A, B, C, D into two identical bags of 2. Named count 6, halved is 3, and the list has 3."),
]
LESSON.append(problem(
    "l5", "lesson", SEC, "Example 1.5",
    "There are 10 different cookies on a tray and you have two identical bags. How many ways are there to divide the "
    "cookies evenly among the two bags?",
    [step("How many ways are there to divide the cookies evenly?", 126,
          ["Read the word 'identical' again. What does it change?",
           "If you call one bag 'first', does each real division get counted once, or more?",
           "Write one division, then swap the bags. Did your count treat those as two?"],
          "Count as if the bags had names. Then ask how many times each real division appears in that count.",
          "10 choose 5 = 252 with a named 'first bag'; each division appears twice; 252 ÷ 2 = 126.",
          "Checked by listing every split of 10 cookies into two unnamed groups of 5: 126.",
          "Identical bags can trade places, so each division was counted twice.",
          named={252: "Not wrong, just unfinished. Swap the two bags: did your count notice?",
                 63: "That divides by 4. How many ways can two bags be named?",
                 30240: "That's 10 × 9 × 8 × 7 × 6: the order cookies go in.", 1: "There's more than one way to divide them."})],
    L5_story, "126", "252 named ÷ 2! = 126. Checked by listing all splits of 10 into two unnamed groups of 5.",
    concept="c5", inclass="29:20"))

# ---------------------------------------------------------------- L6  Practice 4 / UUURRRR (C6)
word6 = "UUURRRR"
V("L6: arrangements", len(set(permutations(word6))), comb(7, 3))
V("L6: ordered U-spots", len(list(permutations(range(7), 3))), 210)
tiny6 = sorted("".join(p) for p in set(permutations("UURR")))
V("L6: tiny UURR", len(tiny6), comb(4, 2))
U = lambda s: ("U", s, "p2")
R = lambda s: ("R", s, "p1")


def positions_frames(word, ex, key, tinyw, tinylist):
    n = len(word)
    a = word.count("U")
    fall = falling(n, a)
    ordered = perm(n, a)
    arr = comb(n, a)
    V(f"{key}: ordered U spots", len(list(permutations(range(n), a))), ordered)
    return [
        Fr(1, v.tiles([[(c, None, "p2" if c == "U" else "p1") for c in ex]]), f"One arrangement: {ex}."),
        Fr(2, v.chips_row([str(i + 1) for i in range(n)], {i: "picked" for i, c in enumerate(ex) if c == "U"},
                          caption=f"{n} spots; the U's sit in {a} of them"),
           f"There are {n} spots. Once you know which {a} hold U, the R's fill the rest."),
        Skip(3, "no rule beyond the letters given"),
        Fr(4, v.tiles([[("U", "1", "p2"), ("U", "2", "p3")], [("U", "2", "p3"), ("U", "1", "p2")]],
                      note="paint washes off: same word"),
           "Paint the U's U₁ and U₂ and swap them. Wash off the paint: same word. So the U's form a group.",
           ask="Swap a U with an R instead. Is that the same word?"),
        Fr(5, slots_from([("1st U spot", str(fall[0])), ("2nd U spot", str(fall[1])), ("3rd U spot", str(fall[2]))],
                         fmt(ordered), note="painted U's, placed one at a time"),
           f"Place painted U₁, U₂, U₃ one at a time: {times(fall)} = {fmt(ordered)}."),
        Fr(6, v.collapse([[("U", s[0], "p2"), ("U", s[1], "p3"), ("U", s[2], "p4")] for s in permutations("123")], "UUU",
                         note="3! painted orders → 1"),
           "Twins? Yes. The same 3 spots got filled in 3! = 6 painted orders."),
        Fr(6, v.calc([fmt(ordered), "÷", "6", "=", str(arr)], "divide"), f"{fmt(ordered)} ÷ 6 = {arr}. That's {n} choose {a}."),
        Fr(7, v.outcome_list(tinylist, cols=6, note=f"4 choose 2 = {len(tinylist)}"),
           f"Tiny case: {tinyw}. Choose 2 of 4 spots for U: 6, and the list has 6."),
    ]


LESSON.append(problem(
    "l6", "lesson", SEC, "Practice 4",
    "How many ways are there to arrange the letters U, U, U, R, R, R, R?",
    [step("How many different arrangements are there?", 35,
          ["Swap two of the U's. Is that a new arrangement?",
           "Instead of placing letters, think about the 7 spots. What decides the arrangement?",
           "Once you know where the U's go, is anything left to decide?"],
          "Choose which 3 of the 7 spots hold a U. The R's fill the other 4.",
          "7 choose 3 = 7 × 6 × 5 ÷ 6 = 35.", "Also 7!/(3!·4!) = 5040 ÷ 144 = 35.",
          "The arrangement is decided by the U spots.",
          named={5040: "That treats every U and every R as different.",
                 210: "That places the U's in order (U₁, U₂, U₃). Wash off the paint.",
                 840: "You took out the U orders. What about the R's?", 144: "That's the copies, not the arrangements.",
                 12: "That's 3 × 4. Try listing a smaller case like UURR."})],
    positions_frames(word6, "URRURUR", "L6", "UURR", tiny6),
    "35", "7 choose 3 = 35 = 7!/(3!4!). Checked by listing every distinct arrangement.", concept="c6", inclass="43:24"))

# ---------------------------------------------------------------- L7  Example 2.1 (C7)
V("L7: paths 6x5", paths_brute((0, 0), (6, 5)), comb(11, 5))
V("L7: ordered U spots", len(list(permutations(range(11), 5))), 55440)
tiny7 = sorted(set("".join(p) for p in permutations("RRU")))
V("L7: tiny 2x1", paths_brute((0, 0), (2, 1)), len(tiny7))
L7_story = [
    Fr(1, v.vstack(v.lattice(6, 5, path="UURRUUURRRR", marks={"A": (0, 0), "B": (6, 5)}),
                   v.word_strip("UURRUUURRRR")), "One path: up, up, right, right, up, up, up, right, right, right, right."),
    Fr(2, v.word_strip("UURRUUURRRR", note="11 moves: which 5 are U?"),
       "Every path is 11 moves: 6 right and 5 up. A path is decided by which 5 of the 11 moves are U."),
    Skip(3, "every up/right path is allowed"),
    Fr(4, v.vstack(v.lattice(6, 5, path="UURRUUURRRR", legs=[((0, 0), "RRUUUURRRRU", "leg2")], marks={"A": (0, 0), "B": (6, 5)})),
       "Swap two U's: same path. Swap a U with an R: a new path, same end point.",
       ask="Why does every path have exactly 5 U's?"),
    Fr(5, slots_from([("1st U", "11"), ("2nd U", "10"), ("3rd U", "9"), ("4th U", "8"), ("5th U", "7")], "55,440",
                     note="painted U's placed one at a time"),
       "Place painted U₁ to U₅ one at a time: 11 × 10 × 9 × 8 × 7 = 55,440."),
    Fr(6, v.card(["U₁U₂U₃U₄U₅ in any of 5! = 120 orders", "→ the same 5 spots, the same path"], "twins", W=360),
       "Twins? Yes. The same 5 spots appear in 5! = 120 painted orders."),
    Fr(6, v.calc(["55,440", "÷", "120", "=", "462"], "divide"), "55,440 ÷ 120 = 462, which is 11 choose 5."),
    Fr(7, v.vstack(v.lattice(2, 1, path="RRU", marks={"A": (0, 0), "B": (2, 1)}),
                   v.outcome_list(tiny7, cols=3, note="3 choose 1 = 3")),
       "Tiny case: a 2-by-1 grid. Moves R, R, U: choose the U's spot, 3 ways. The list has 3."),
]
LESSON.append(problem(
    "l7", "lesson", SEC, "Example 2.1",
    "How many paths are there from A to B below, which follow the grid lines and only go up and to the right? "
    "(The grid is 6 squares wide and 5 squares tall; A is bottom-left, B is top-right.)",
    [step("How many R moves and how many U moves does every path from A to B use? (R first)", [6, 5],
          ["Trace any path with your finger and count.", "Count the squares along the bottom, then up the side.",
           "Does a different path ever use a different number of rights?"],
          "Every path ends 6 to the right and 5 up of where it started.", "6 R and 5 U.", "Trace any path: 6 R, 5 U.",
          "Every path uses the same moves, just in a different order.", type="nums", order=True,
          named={"5,6": "Right numbers, wrong order: R first."}),
     step("How many paths are there?", 462,
          ["A path is a word made of R's and U's. What decides the word?",
           "How many spots are in the word, and how many of them hold U?",
           "Choosing the U spots is choosing a group of spots. Does their order matter?"],
          "Choose which 5 of the 11 moves are U (or which 6 are R).", "11 choose 5 = 462.",
          "11!/(5!·6!) = 462; checked by tracing every path in code.", "Paths are just U/R words.",
          named={2048: "That lets each move be anything; the path must end at B.", 55: "That's 11 choose 2.",
                 330: "That's 11 choose 4. How many U moves are there?", 30: "That multiplies 6 × 5 instead of choosing spots.",
                 55440: "That puts the U's in order. Wash off the paint.", 924: "Count the moves again: 6 + 5."})],
    L7_story, "462", "11 choose 5 = 462; checked by walking every path.", concept="c7", inclass="45:30"))

# ---------------------------------------------------------------- L8  Example 1.6 (C8)
from itertools import product as _prod
cube_pts = list(_prod((0, 1), repeat=3))


def _collinear(p, q, r):
    u = [q[i] - p[i] for i in range(3)]
    w = [r[i] - p[i] for i in range(3)]
    return (u[1] * w[2] - u[2] * w[1], u[2] * w[0] - u[0] * w[2], u[0] * w[1] - u[1] * w[0]) == (0, 0, 0)


V("L8: triangles", sum(1 for t in combinations(cube_pts, 3) if not _collinear(*t)), comb(8, 3))
V("L8: ordered", len(list(permutations(cube_pts, 3))), 336)
sq = ["".join(c) for c in combinations("ABCD", 3)]
V("L8: tiny square", len(sq), 4)
L8_story = [
    Fr(1, v.cube(hl=[("A", "B"), ("B", "G"), ("G", "A")], label="cube with one triangle"),
       "One triangle: corners A, B, G. Its sides don't have to be cube edges."),
    Fr(2, v.cube(label="cube corners"), "What decides a triangle? Its 3 corners. So we choose 3 of the 8 corners."),
    Skip(3, "any 3 corners work: no three cube corners lie on one straight line"),
    Fr(4, v.card(["A, B, G   =   G, A, B", "same triangle"], "swap", W=300),
       "Naming the corners in another order draws the same triangle.", ask="Can a triangle use a diagonal that goes through the cube?"),
    Fr(5, slots_from([("1st corner", "8"), ("2nd", "7"), ("3rd", "6")], "336"), "Pick corners one at a time: 8 × 7 × 6 = 336."),
    Fr(6, v.bundle(list(permutations("ABG")), ["A", "B", "G"], cols=2), "Twins? Yes. Each triangle was built 3! = 6 times."),
    Fr(6, v.calc(["336", "÷", "6", "=", "56"], "divide"), "336 ÷ 6 = 56, which is 8 choose 3."),
    Fr(7, v.vstack(v.dots({"A": (40, 150), "B": (150, 150), "C": (150, 40), "D": (40, 40)},
                          [("A", "B"), ("B", "C"), ("C", "D"), ("D", "A")], W=200, H=180),
                   v.outcome_list(sq, cols=2, note="4 choose 3 = 4")),
       "Tiny case: a square's 4 corners. Choose 3: 4 triangles, and the list has 4."),
]
LESSON.append(problem(
    "l8", "lesson", SEC, "Example 1.6", "How many different triangles can be made by connecting the vertices of a cube?",
    [step("How many different triangles are there?", 56,
          ["What decides exactly which triangle you've drawn?",
           "Do the triangle's sides have to be edges of the cube?",
           "Is a triangle with corners A, B, G different from one with corners G, A, B?"],
          "A triangle is decided by its 3 corners. Choose 3 of the cube's corners (no three are in a line).",
          "8 choose 3 = 8 × 7 × 6 ÷ 6 = 56.", "Checked in code: every triple of cube corners makes a real triangle.",
          "You chose what makes a triangle, not the triangle itself.",
          named={336: "That names the corners in order.", 24: "Those are only the triangles lying on a face.",
                 12: "That's the number of edges.", 28: "That's pairs of corners: segments, not triangles.",
                 70: "That chooses 4 corners."})],
    L8_story, "56", "8 choose 3 = 56; checked: no 3 cube corners are collinear.", concept="c8", inclass="36:48"))

# ---------------------------------------------------------------- L9  Problem 3.2 (C9)
V("L9: 50 choose 5", comb(50, 5), 50 * 49 * 48 * 47 * 46 // 120)
V("L9: answer", comb(50, 5) * 32, 67800320)
tiny9 = []
for sts in combinations("123", 2):
    for m in _prod("AB", repeat=2):
        tiny9.append(f"{sts[0]}{m[0]} {sts[1]}{m[1]}")
people9 = [s + m for s in "123" for m in "AB"]
V("L9: tiny brute", sum(1 for c in combinations(people9, 2) if len({p[0] for p in c}) == 2), len(tiny9))
V("L9: tiny formula", len(tiny9), comb(3, 2) * 4)
V("L9: ordered states", 50 * 49 * 48 * 47 * 46, perm(50, 5))
L9_story = [
    Fr(1, v.states(10, picked={0, 3, 4, 7, 9}, chosen={0: 0, 3: 1, 4: 1, 7: 0, 9: 0}, label="ten of the fifty states"),
       "One set of finalists: one person from each of 5 different states (10 of the 50 states shown)."),
    Fr(2, v.card(["100 competitors, 2 per state", "choose 5 finalists"], "setup", W=300),
       "5 finalists from 100 people, but with a rule about states."),
    Fr(3, v.states(10, picked={0, 3, 4, 7, 9}, label="states first"),
       "Rule: at most one per state. Start with the most restricting part: choose the 5 states first.",
       ask="Why is it easier to pick states first than people first?"),
    Fr(4, v.card(["finalists {S1-A, S4-B, …}", "listed in any order = same finalists"], "swap", W=330),
       "Swapping the order of two finalists gives the same set. The states form a group."),
    Fr(5, v.calc(["50·49·48·47·46", "÷", "5!", "=", "2,118,760"], "choose states"),
       "Choose 5 of 50 states: 50 choose 5 = 2,118,760."),
    Fr(5, slots_from([("state 1", "2"), ("state 2", "2"), ("state 3", "2"), ("state 4", "2"), ("state 5", "2")], "32",
                     note="A or B in each chosen state"),
       "Each chosen state picks A or B, always 2 choices, so 2 × 2 × 2 × 2 × 2 = 32."),
    Fr(5, v.calc(["2,118,760", "×", "32", "=", "67,800,320"], "multiply"),
       "Every state set goes with every A/B pattern: 2,118,760 × 32 = 67,800,320."),
    Fr(6, v.card(["states chosen as a group (5! already divided)", "A vs B in a state: different people"], "twins", W=380),
       "Twins? No more. The 5! is already inside 50 choose 5, and picking A or B always gives different finalists."),
    Fr(7, v.outcome_list(tiny9, cols=4, note="3 choose 2 × 2 × 2 = 12"),
       "Tiny case: 3 states, 2 finalists. 3 choose 2 = 3 state pairs, times 4 = 12, and the list has 12."),
]
LESSON.append(problem(
    "l9", "lesson", SEC, "Problem 3.2",
    "There are 100 competitors at the national debating contest, 2 from each of the 50 states. In how many ways can "
    "5 finalists be chosen if no state can have more than one finalist?",
    [step("In how many ways can the 5 finalists be chosen? (A product of numbers is a fine answer.)", 67800320,
          ["Which part of the problem restricts you the most?",
           "Could you decide something about states before deciding about people?",
           "Once you know which states have finalists, how many choices does each of those states have?"],
          "Start with the most restricting part: choose which 5 states have a finalist, then the person from each.",
          "50 choose 5 × 2⁵ = 2,118,760 × 32 = 67,800,320.",
          "Checked three ways in code (state-by-state count, inclusion–exclusion, small-case brute force).",
          "States first, then people.",
          named={75287520: "That's 100 choose 5. Some of those teams have both people from one state.",
                 2118760: "That chooses the states. Each state still has to pick its person.",
                 8136038400: "That picks the states in order. Does the order of states matter?",
                 32: "That's just the A/B choices.", 10: "That's 5 × 2."})],
    L9_story, "67,800,320", "50 choose 5 × 2⁵ = 2,118,760 × 32 = 67,800,320 (the teacher's form: 2⁵ × 20 × 49 × 47 × 46).",
    concept="c9", inclass="54:06", above=True))
