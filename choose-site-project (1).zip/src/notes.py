"""Notes-page content that isn't a concept story."""
from itertools import combinations, permutations
from math import comb, perm
import visuals as v
from stories import Cf, V
from concepts import eq, frac, binom

# --------------------------------------------------------------- signature section: the bundle / pick grid
six = list("ABCDEF")
V("SIG ordered", len(list(permutations(six, 2))), 30)
V("SIG pairs", len(list(combinations(six, 2))), 15)
V("SIG grid boxes", 6 * 6, 36)
SIG_STORY = [
    Cf(v.pickgrid(six, "empty"), "Six kids, A to F. Two of them will carry the class flag together. Start with an empty grid: first pick down the side, second pick across the top."),
    Cf(v.pickgrid(six, "filled"), "Question 1: how many ordered lists? Fill every box with its list: 6 × 6 = 36 boxes."),
    Cf(v.pickgrid(six, "diagonal"), "The same kid can't be picked twice. Cross out the diagonal: 36 − 6 = 30 ordered lists, which is 6 × 5."),
    Cf(v.pickgrid(six, "twins", hl={(1, 3), (3, 1)}), "Question 2: how many lists land in each bundle? BD and DB are the same pair. Every box below the diagonal is a twin of one above, so 2 per bundle.",
       ask="Point at any box. Where is its twin?"),
    Cf(v.bundle([("B", "D"), ("D", "B")], ["B", "D"]), "Question 3: so how many bundles? 30 ÷ 2 = 15 pairs. The top triangle alone shows them."),
    Cf(v.pickgrid(six, "twins", plain=True), "Plain mode: if the two jobs are different (captain and helper), BD and DB are different. No twins: all 30 count."),
]
SAME_PICTURE = v.table(
    ["problem", "what the copies are", "move"],
    [["Problem 1 (candies)", "3! orders of the same handful", "divide by 3!"],
     ["Problem 2 (teams of 5 and 4)", "none: the teams can't trade places", "no division"],
     ["Problem 3 (two teams of 5)", "the two look-alike teams swapped", "divide by 2!"],
     ["Problem 8 (three teams of 4)", "three look-alike teams in any order", "divide by 3!"],
     ["Problem 9 (pairs and trios)", "pair namings × trio namings", "divide by 3! × 2!"],
     ["Problem 12 (cube segments)", "AG and GA", "halve (the top triangle of the pick grid)"],
     ["Problem 13 (diagonals)", "each diagonal from both ends", "halve, then take away the sides"],
     ["Problem 15 (blocks)", "none once rows are chosen as a group", "no extra division"],
     ["Problem 16 (coins)", "none: colours and faces are separate decisions", "multiply, no division"]])

# --------------------------------------------------------------- traps
TRAPS = [
    ("Order sneaks in", "ps1", "720", "Counting 10 × 9 × 8 feels finished, but it lists the same handful in every order."),
    ("Dividing by k instead of k!", "ps1", "240", "Three candies feel like 3 copies. Write the orders of A, B, C: there are 6."),
    ("The forced last team", "ps2", "15,876", "Once the team of 5 is picked, the team of 4 has no choices left: × 1, not × 126."),
    ("Different sizes never twin", "ps2", "63", "Halving out of habit. A team of 5 can't trade places with a team of 4."),
    ("Unnamed look-alike teams", "ps3", "252", "It's the right count for teams called Red and Blue. These teams have no names."),
    ("Painted letters", "ps4", "5,040", "7! treats the three U's as three different letters."),
    ("Adding the legs", "ps7", "161", "Two numbers, so add them? A trip needs leg 1 AND leg 2, so every pairing counts."),
    ("Forgetting the checkpoint", "ps7", "12,870", "Every A-to-C path, including all the ones that miss B."),
    ("Three teams, divide by 3", "ps8", "11,550", "Three teams feels like ÷3, but three teams can be named in 3! = 6 ways."),
    ("Adding the copies", "ps9", "207,900", "Dividing by 3! + 2! = 8. Each pair-naming goes with each trio-naming, so the copies multiply: 12."),
    ("The spare job", "ps11", "480", "One job each, then a spare. But which of the doubled-up kid's jobs was the 'spare'? Each assignment got built twice."),
    ("Sides aren't diagonals", "ps13", "28", "Every pair of corners, including the 8 neighbours that make sides."),
    ("0 can't lead", "ps14", "240", "Treating increasing and decreasing the same. An increasing number can't contain 0; a decreasing one can end in 0."),
    ("Any three blocks", "ps15", "2,300", "25 choose 3 ignores the row and column rule."),
    ("Faces don't double", "ps16", "256", "Each coin up or down looks like 2 choices each, but a face-up coin can't sit under a face-down one."),
]

# --------------------------------------------------------------- cheat sheet
CHEAT = [
    ("Grab or pick a group of different things", "Swap test: same group? Then n choose k."),
    ("Several groups filled one after another", "Choose each from whoever is left; multiply."),
    ("Same-size groups with no names", "Count with names, then divide by m! (m look-alike groups)."),
    ("Groups of different sizes", "They can't trade places: no extra division."),
    ("Repeated letters", "Choose the spots for one letter (or divide by each letter's copies)."),
    ("Up/right paths on a grid", "Count the R's and U's; choose the U spots."),
    ("Path must pass a checkpoint", "Split at the checkpoint; multiply the legs."),
    ("Shapes made from points or lines", "Choose what decides the shape: corners, endpoints, or a pair of lines from each family."),
    ("A rule like 'at most one per state'", "Start with the most restricting part: choose the allowed groups first."),
    ("'At least one of each' or 'or'", "Split into kinds that can't overlap; add them."),
    ("Taking most of a set", "Count the few left behind instead (take = leave)."),
    ("The order inside the answer is forced (like increasing digits)", "Just choose the set; the order comes free."),
    ("An unknown n", "Make a table of n, or cancel the factorials and look for consecutive numbers."),
    ("Your count feels too big", "Write one outcome and look for its twins. Never divide just because the number feels large."),
]

# --------------------------------------------------------------- glossary
GLOSSARY = [
    ("Combination", "A group without order: {A, B} is the same combination as {B, A}."),
    ("Ordered list", "A selection where position matters: AB and BA are different lists. The rule of product builds ordered lists."),
    ("Set", "A collection where only membership matters. Written with curly brackets: {5, 2} = {2, 5}."),
    ("Ordered pair", "Two things in a fixed order, written with round brackets: (5, 2) is not (2, 5)."),
    ("n choose k", "The number of groups of k you can choose from n different things. Written as a tall bracket, C(n, k), or nCk."),
    ("Factorial", "n! = n × (n − 1) × … × 2 × 1, the number of ways to line up n different things."),
    ("0! = 1 (the empty product)", "There is exactly one way to line up nothing: do nothing. That's why 2 choose 2 = 2!/(2!·0!) = 1."),
    ("Multichoose", "The teacher's name for 9!/(4!·3!·2!), splitting into groups of given sizes. Most books call it a multinomial coefficient; some books use 'multichoose' for something else (choosing with repeats)."),
    ("Distinct / identical", "Distinct things can be told apart (cookies A to J). Identical things can't (two plain bags, three U's)."),
    ("Not necessarily distinct", "Repeats are allowed but not required: 'three not necessarily distinct digits' includes 557."),
    ("Twins (our word)", "Two builds that make the same real outcome, like AB and BA for one pair."),
    ("Round robin", "A tournament where every pair of players plays once."),
    ("Diagonal", "A segment joining two corners of a polygon that aren't neighbours."),
    ("Case", "One kind of outcome that can't overlap with the other kinds; cases are added."),
]

HABITS = [
    "Write the choose form first, like C(10, 3), then the factorial form, then cancel. The teacher does this every time.",
    "Cancel the larger factorial in the denominator first: 10!/7! becomes 10 × 9 × 8.",
    "Pull small factors out of big ones before multiplying: 'four can come out of eight, leaving two'.",
    "Name each decision in words above its number: 'first bag', 'second bag', 'A to B', 'B to C'.",
    "A product is a finished answer: 2⁵ × 20 × 49 × 47 × 46 is fine. The checker accepts it.",
    "In equation problems, say what the letters stand for and what they must be: 'b and r are positive whole numbers'.",
    "Pause and try first. Every class problem began with 'pause the video'; the workbench opens the steps before any worked answer.",
    "Finish with a tiny case you can list. If the list and the rule disagree, the rule is wrong.",
]

RULES_CARD = (
    '<div class="rules"><h3>The plan</h3>'
    "<p>What am I making? → What's being chosen, from what? → Kinds or a rule? Split, or start with the most restricting part → "
    "Swap test → Build it and multiply → Built anything twice? Divide → Check a tiny case.</p>"
    "<h3>Moves</h3><ol>"
    "<li>Group of different things, order doesn't matter: n choose k = n!/(k!·(n − k)!).</li>"
    "<li>Groups one after another: choose each from whoever is left, and multiply.</li>"
    "<li>Same-size groups with no names: divide by the number of ways to name them.</li>"
    "<li>Repeated letters or grid paths: choose the spots.</li>"
    "<li>Checkpoint or two independent decisions: multiply. Kinds that can't overlap: add.</li></ol>"
    "<h3>Answers</h3><p>Type a number or an expression: 12 × 11 ÷ 4, 2^6 × 11, 12!/(4!·8!), C(12, 4) and '12 choose 4' all work. "
    "Lists can be written “8 and 3”.</p></div>")


# ======================================================================= tag-word method versions
from method import tag_row as _tag_row, word_pic as _word_pic, group_word_pic as _gwp, Fr as _Fr

V("SIG2 words", len(set(permutations("XXYYZZZ"))), 210)
SIG_STORY2 = [
    Cf(_tag_row(list("ABCDEFG"), "XYZXYZZ"), "Question 1: what tag does each object get? 7 kids into two pairs and a trio, with no names. Tag them X, Y (the pairs) and Z (the trio)."),
    Cf(v.vstack(_word_pic("XXYYZZZ"), v.calc(["7! ÷ (2! × 2! × 3!)", "=", "210"], "count")),
       "Question 2: how many words? The tags spell a word with 2 X, 2 Y, 3 Z: 5,040 ÷ 24 = 210."),
    Cf(_gwp([("A", "X", "2"), ("A", "Y", "2"), ("B", "Z", "3")], note="the groups spell A A B"),
       "Question 3: any look-alike groups? The two pairs look alike; the trio doesn't. The groups spell A A B."),
    Cf(v.calc(["210", "÷", "2!", "=", "105"], "divide"), "Divide by the group word's repeats: 210 ÷ 2 = 105 real splits."),
]
V("SIG2 real", len(__import__("pcommon").partitions_brute(7, (2, 2, 3), False)), 105)
SAME_PICTURE2 = v.table(
    ["problem", "tag word", "look-alike groups?"],
    [["1 candies", "T T T and 7 L", "no: T and L differ"],
     ["2 teams of 5 and 4", "5 X and 4 Y", "no: sizes differ"],
     ["3 two teams of 5", "5 X and 5 Y", "yes: A A"],
     ["4 letters", "U U U R R R R", "no"],
     ["5–7 paths", "R's and U's (two legs: two words)", "no"],
     ["8 three teams of 4", "4 X, 4 Y, 4 Z", "yes: A A A"],
     ["9 pairs and trios", "a a b b c c d d d e e e", "yes: A A A B B"],
     ["10 committees", "boys X X Y Y L L, girls the same", "yes: A A"],
     ["11 jobs", "kid letters, one kid twice", "no: kids have names"],
     ["12, 13 segments", "2 T's on the corners", "no"],
     ["14 digits", "T's on the digits (two cases: add)", "no"],
     ["15 blocks", "rows T/L, columns 1 2 3 / L", "no"],
     ["16 coins", "colour word × face word", "no"]])
CHEAT2 = [
    ("Choose some things from a set", "Tag T (take) or L (leave). Count the words."),
    ("Split everything into groups", "Tag each object with its group's letter. Count the words."),
    ("Groups the same size with no names", "Write the group word (like A A A B B) and divide by its repeats!."),
    ("Groups of different sizes, or named groups", "They can't trade places: no extra division."),
    ("Repeated letters", "It's already a tag word: n! ÷ each letter's repeats!."),
    ("Up/right paths", "Tag each move R or U."),
    ("Path through a checkpoint", "Two legs = two words: multiply."),
    ("Shapes from points or lines", "Tag what decides the shape: corners, endpoints, or lines of each kind."),
    ("A rule like 'at most one per state'", "Tag the most restricted thing first (the states), then the rest."),
    ("'At least one of each', 'or'", "Split into cases that can't overlap; add."),
    ("Every object must be used ('each kid gets a job')", "Every letter must appear in the word: work out which letters repeat."),
    ("An unknown n", "Make a table of n against the word counts."),
    ("Your count feels too big", "Check step 3: is something a look-alike? Never divide just because a number feels large."),
]
GLOSSARY2 = [
    ("Tag", "A letter written under each object saying where it goes: T or L, a team letter, R or U, a colour."),
    ("Tag word", "All the tags read in order, like L T L L T L L T L L. Each outcome is exactly one tag word."),
    ("Look-alike groups", "Groups with the same size and no names. They can trade places without changing anything."),
    ("Group word", "The groups themselves written as letters: a letter per size, like A A A B B for three pairs and two trios."),
] + GLOSSARY
RULES_CARD2 = (
    '<div class="rules"><h3>The plan</h3><ol>'
    "<li>Tag every object with a letter that says where it goes.</li>"
    "<li>Count the words the tags spell: n! ÷ (each letter's repeats)!. Two separate words multiply; separate cases add.</li>"
    "<li>Look-alike groups (same size, no names)? Write the group word and divide by its repeats!.</li>"
    "<li>Check a tiny case you can list.</li></ol>"
    "<h3>Answers</h3><p>Type a number or an expression: 12 × 11 ÷ 4, 2^6 × 11, 12!/(4!·8!), C(12, 4) and '12 choose 4' all work. "
    "Lists can be written “8 and 3”.</p></div>")
