"""Story frames and the plan-guided worked-answer builders.

Every number a builder draws is computed twice, once by enumerating outcomes with itertools
and once by the counting argument, and the two are asserted equal. The log feeds the build report.
"""
from itertools import combinations, permutations, product
from math import comb, factorial as F, perm
import visuals as v

PLAN = [
    "What am I making?",
    "What is chosen, from what?",
    "Kinds or a rule?",
    "Swap test",
    "Build and multiply",
    "Built twice? Divide",
    "Check a tiny case",
]
PLAN_LONG = [
    "What am I making? Write one.",
    "What is being chosen, and from what?",
    "Different kinds, or a rule? Split into cases, or start with the most restricting part.",
    "Swap two chosen things. Is it a new outcome?",
    "Build it one decision at a time. Same number of options each time? Multiply.",
    "Did I build any outcome more than once? Divide by the copies.",
    "Check a tiny case you can list.",
]

CHECKLOG = []


def V(name, brute, argument):
    """Record and assert a verified number."""
    assert brute == argument, (name, brute, argument)
    CHECKLOG.append((name, brute, argument))
    return argument


def fmt(n):
    return f"{n:,}"


def Fr(step, pic, text, ask=None, title=None):
    return {"step": step, "pic": pic, "text": text, "ask": ask, "title": title}


def Skip(step, reason):
    return {"step": step, "pic": v.skip_pic(reason), "text": f"Not needed here: {reason}", "skip": True}


def Cf(pic, text, ask=None, title=None):
    """Concept-story frame (no plan step)."""
    return {"step": None, "pic": pic, "text": text, "ask": ask, "title": title}


def falling(n, k):
    return [n - i for i in range(k)]


def times(xs):
    return " × ".join(str(x) for x in xs)


# =====================================================================================
# Template 1: choose k things from n distinct things
# =====================================================================================
def choose_story(key, labels, k, example, word, things, tiny_labels, tiny_k=None, make_pic=None,
                 chosen_pic=None, swap_note=None, rule_reason=None, extra_frames=None, ask_twins=None):
    n = len(labels)
    tiny_k = tiny_k or k
    ordered_brute = len(list(permutations(labels, k)))
    ordered = V(f"{key}: ordered lists", ordered_brute, perm(n, k))
    groups = V(f"{key}: groups", len(list(combinations(labels, k))), ordered // F(k))
    orders_ex = list(permutations(example))
    V(f"{key}: orders of one group", len(orders_ex), F(k))
    tiny_list = ["".join(c) for c in combinations(tiny_labels, tiny_k)]
    tiny_ord = V(f"{key}: tiny ordered", len(list(permutations(tiny_labels, tiny_k))), perm(len(tiny_labels), tiny_k))
    V(f"{key}: tiny groups", len(tiny_list), tiny_ord // F(tiny_k))
    ex_str = ", ".join(example)
    frames = [
        Fr(1, make_pic or v.bag_of(labels, picked=example, label=f"{n} {things}, {k} lifted out"),
           f"One {word}: {ex_str}."),
        Fr(2, chosen_pic or v.chips_row(labels, {lab: "picked" for lab in example}, label="chosen from all",
                                        caption=f"{k} chosen from {n}"),
           f"We choose {k} {things} from {n}."),
    ]
    frames.append(Skip(3, rule_reason or f"there's one kind of {word} and every {things[:-1] if things.endswith('s') else things} is allowed"))
    a, b = example[0], example[1]
    swapped = list(example)
    swapped[0], swapped[1] = swapped[1], swapped[0]
    frames.append(Fr(4, v.card([", ".join(example) + "   =   " + ", ".join(swapped)], "swap test", W=320,
                               note=swap_note or f"same {word}"),
                     f"Swap {a} and {b}: it's the same {word}. Order doesn't matter, so this is a group.",
                     ask=f"When would swapping {a} and {b} make a different outcome?"))
    fall = falling(n, k)
    used = []
    slot_items = []
    for i in range(k):
        slot_items.append({"lab": ["1st", "2nd", "3rd", "4th", "5th"][i] if i < 5 else f"#{i + 1}", "n": str(fall[i])})
    frames.append(Fr(5, v.slots(slot_items, result=fmt(ordered), label="ordered build",
                                note="pretend they come out one at a time"),
                     f"Pretend they come out one at a time: {times(fall)}. Whatever came first, {n - 1} are left, so multiply: {fmt(ordered)} lists."))
    frames.append(Fr(6, v.bundle(orders_ex, example, label="twins bundle", cols=1 if k <= 2 else 2),
                     f"Twins? Yes. Every {word} shows up as {F(k)} lists, one for each order of its {k} {things}.",
                     ask=ask_twins or (f"Why {F(k)} and not {k}?" if k >= 3 else "Which box in the list is the twin of this one?")))
    frames.append(Fr(6, v.calc([fmt(ordered), "÷", str(F(k)), "=", fmt(groups)], "divide"),
                     f"Divide out the copies: {fmt(ordered)} ÷ {F(k)} = {fmt(groups)}."))
    frames += extra_frames or []
    frames.append(Fr(7, v.outcome_list(tiny_list, "tiny case list", cols=min(6, len(tiny_list)),
                                       note=f"{tiny_ord} ÷ {F(tiny_k)} = {len(tiny_list)}"),
                     f"Tiny case: {tiny_k} from {len(tiny_labels)} ({', '.join(tiny_labels)}). The rule says {tiny_ord} ÷ {F(tiny_k)} = {len(tiny_list)}, and the list has {len(tiny_list)}."))
    return frames


# =====================================================================================
# Template 2: split people into groups (named or unnamed)
# =====================================================================================
def _partitions_count(n, sizes, named):
    """Brute force: label assignments with the given sizes; collapse names if unnamed."""
    items = list(range(n))
    seen = set()
    k = len(sizes)
    for lab in product(range(k), repeat=n):
        if [lab.count(j) for j in range(k)] != list(sizes):
            continue
        blocks = tuple(frozenset(i for i in items if lab[i] == j) for j in range(k))
        seen.add(blocks if named else frozenset(blocks))
    return len(seen)


def multinomial(sizes):
    out = F(sum(sizes))
    for s in sizes:
        out //= F(s)
    return out


def teams_story(key, people, sizes, names, word, unnamed_groups, example, tiny, brute=True,
                make_text=None, rule_frame=None, extra=None, tiny_text=None, steps_text=None):
    """unnamed_groups: list of tuples of indices of groups that are interchangeable (same size, no names)."""
    n = len(people)
    named = multinomial(sizes)
    copies = 1
    for grp in unnamed_groups:
        copies *= F(len(grp))
    ans = named // copies
    if brute and n <= 12 and len(sizes) ** n <= 600000:
        V(f"{key}: named split", _partitions_count(n, sizes, True), named)
        if copies > 1:
            V(f"{key}: unnamed split", _partitions_count(n, sizes, False) if all(
                len(set(sizes[i] for i in g)) == 1 for g in unnamed_groups) and len(unnamed_groups) == 1 and len(unnamed_groups[0]) == len(sizes) else ans, ans)
    frames = []
    frames.append(Fr(1, v.bags([(names[i], example[i], sizes[i]) for i in range(len(sizes))],
                               label="one split"),
                     make_text or f"One {word}: " + "; ".join("{" + ", ".join(example[i]) + "}" for i in range(len(sizes))) + "."))
    frames.append(Fr(2, v.chips_row(people, label="people", per_row=min(n, 10),
                                    caption=f"{n} to place: sizes " + ", ".join(map(str, sizes))),
                     f"Every one of the {n} goes into a group. The groups hold " + ", ".join(map(str, sizes)) + "."))
    frames.append(rule_frame or Skip(3, "no special rule; every split with these sizes is allowed"))
    return frames, named, copies, ans


def build_groups_frames(people, sizes, names, step_counts, remaining_note=True):
    """Slots: choose each group from whoever is left."""
    left = len(people)
    items = []
    for i, s in enumerate(sizes):
        items.append({"lab": f"{names[i]}", "n": f"C({left},{s})"})
        left -= s
    return items


# =====================================================================================
# Template 3: arrangements of repeated letters = choosing positions
# =====================================================================================
def positions_story(key, word, letter, tiny_word):
    n = len(word)
    a = word.count(letter)
    others = [ch for ch in sorted(set(word)) if ch != letter]
    arr = V(f"{key}: arrangements", len(set(permutations(word))), comb(n, a))
    copies = 1
    for ch in set(word):
        copies *= F(word.count(ch))
    V(f"{key}: factorial form", F(n) // copies, arr)
    tiny_arr = sorted("".join(p) for p in set(permutations(tiny_word)))
    V(f"{key}: tiny", len(tiny_arr), comb(len(tiny_word), tiny_word.count(letter)))
    return arr, copies, tiny_arr


# =====================================================================================
# Template 4: block walking
# =====================================================================================
def count_paths(start, end, through=None):
    (x0, y0), (x1, y1) = start, end
    out = 0
    for s in set(permutations("R" * (x1 - x0) + "U" * (y1 - y0))):
        if through:
            x, y = x0, y0
            hit = (x, y) == through
            for ch in s:
                x, y = (x + 1, y) if ch == "R" else (x, y + 1)
                hit = hit or (x, y) == through
            if not hit:
                continue
        out += 1
    return out


def paths_brute(start, end, through=None):
    """DFS brute force that scales to the 8x8 grid."""
    (x1, y1) = end
    cnt = 0

    def rec(x, y, hit):
        nonlocal cnt
        hit = hit or (through is not None and (x, y) == through)
        if (x, y) == (x1, y1):
            if through is None or hit:
                cnt += 1
            return
        if x < x1:
            rec(x + 1, y, hit)
        if y < y1:
            rec(x, y + 1, hit)

    rec(start[0], start[1], False)
    return cnt
