"""Phase 1 verification for the Choose Function workbench (AwesomeMath Level 1, Week 4).
Every answer is computed twice: by brute force (enumerate the actual outcomes) and by the
counting argument the page will teach. The two must agree or the script stops.
"""
from itertools import combinations, permutations, product
from math import comb, factorial as F
from fractions import Fraction

rows = []
def check(tag, brute, argument, note=""):
    ok = brute == argument
    rows.append((tag, brute, argument, "OK" if ok else "MISMATCH", note))
    assert ok, (tag, brute, argument)

# ---------- helpers ----------
def unordered_partitions(items, sizes):
    """Brute force: every way to cut `items` into unlabeled blocks with the given sizes.
    Enumerates label assignments, then collapses to a set of frozensets."""
    k = len(sizes)
    seen = set()
    for lab in product(range(k), repeat=len(items)):
        blocks = [frozenset(x for x, l in zip(items, lab) if l == j) for j in range(k)]
        if sorted(len(b) for b in blocks) == sorted(sizes):
            seen.add(frozenset(blocks))
    return seen

def set_partitions_rgs(n):
    """All set partitions of range(n) via restricted-growth strings (brute force generator)."""
    a = [0] * n
    def rec(i, m):
        if i == n:
            yield tuple(a); return
        for v in range(m + 2):
            a[i] = v
            yield from rec(i + 1, max(m, v))
    if n == 0:
        yield (); return
    a[0] = 0
    yield from rec(1, 0)

def paths(start, end):
    """Enumerate every up/right lattice path as a U/R string."""
    (x0, y0), (x1, y1) = start, end
    out = []
    def rec(x, y, s):
        if (x, y) == (x1, y1):
            out.append(s); return
        if x < x1: rec(x + 1, y, s + "R")
        if y < y1: rec(x, y + 1, s + "U")
    rec(x0, y0, "")
    return out

# =====================================================================
# LECTURE NOTES (class examples)
# =====================================================================
L = "ABCD"
check("Ex1.1 2 letters from ABCD", len({frozenset(p) for p in permutations(L, 2)}), (4 * 3) // 2,
      "ordered 12, each group twice")
check("Ex1.2 3 of 7 marbles", len(list(combinations(range(7), 3))), (7 * 6 * 5) // F(3),
      "ordered 210 / 3! = 35")
check("Ex1.2 orders of {A,D,G}", len(set(permutations("ADG"))), F(3))
check("Class 12 choose 10", len(list(combinations(range(12), 10))), (12 * 11) // 2, "= C(12,2)")
check("Class take10 = leave2", comb(12, 10), comb(12, 2))
cook9 = list("ABCDEFGHI")
# labeled bags of sizes 4,3,2 (bag sizes make them distinguishable)
ex14 = set()
for lab in product(range(3), repeat=9):
    if [lab.count(0), lab.count(1), lab.count(2)] == [4, 3, 2]:
        ex14.add(lab)
check("Ex1.4 9 cookies into 4/3/2 bags", len(ex14), comb(9, 4) * comb(5, 3) * comb(2, 2),
      "126*10*1 = 9!/(4!3!2!)")
check("Ex1.4 multinomial form", comb(9, 4) * comb(5, 3), F(9) // (F(4) * F(3) * F(2)))
ex15 = unordered_partitions(list("ABCDEFGHIJ"), [5, 5])
check("Ex1.5 10 cookies, 2 identical bags", len(ex15), comb(10, 5) // F(2), "252 is the crossed-out count")
cube = list(product((0, 1), repeat=3))
def collinear(p, q, r):
    u = [q[i] - p[i] for i in range(3)]; v = [r[i] - p[i] for i in range(3)]
    cr = (u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0])
    return cr == (0, 0, 0)
tri = [t for t in combinations(cube, 3) if not collinear(*t)]
check("Ex1.6 triangles on cube vertices", len(tri), comb(8, 3), "no 3 cube vertices collinear")
check("Lecture practice 3 (two teams of 4 from 8)", len(unordered_partitions(list(range(8)), [4, 4])),
      comb(8, 4) // 2, "70/2!")
check("Ex2.1 6x5 grid paths", len(paths((0, 0), (6, 5))), comb(11, 5))
# Problem 3.1: parallelograms on a sheared 5x4 grid. Nodes i*u + j*v, i=0..5, j=0..4.
# A parallelogram in the figure has all 4 sides on drawn lines, so its corners are
# (i1,j1),(i2,j1),(i2,j2),(i1,j2). Brute force over all 4-node sets of the 30 nodes.
nodes = [(i, j) for i in range(6) for j in range(5)]
def is_grid_parallelogram(S):
    xs = sorted({p[0] for p in S}); ys = sorted({p[1] for p in S})
    return len(xs) == 2 and len(ys) == 2 and set(S) == {(x, y) for x in xs for y in ys}
par = sum(1 for S in combinations(nodes, 4) if is_grid_parallelogram(S))
check("P3.1 parallelograms", par, comb(6, 2) * comb(5, 2), "15 slanted pairs x 10 horizontal pairs")
# Problem 3.2: full enumeration of 5-subsets of 100 is 75M; do it by state-by-state DP
# (a direct count of valid subsets) and by complement / inclusion-exclusion, plus small-case brute force.
dp = [1] + [0] * 5
for _ in range(50):                      # each state contributes 0 or 1 finalist (2 ways)
    dp = [dp[k] + (2 * dp[k - 1] if k else 0) for k in range(6)]
incl_excl = sum((-1) ** j * comb(50, j) * comb(100 - 2 * j, 5 - 2 * j) for j in range(0, 3))
check("P3.2 debate finalists (DP vs argument)", dp[5], comb(50, 5) * 2 ** 5)
check("P3.2 debate finalists (incl-excl)", incl_excl, comb(50, 5) * 2 ** 5)
small = [(s, f) for s in range(1, 8) for f in range(0, s + 1)]
for s, f in small:
    people = [(st, w) for st in range(s) for w in range(2)]
    b = sum(1 for c in combinations(people, f) if len({p[0] for p in c}) == f)
    assert b == comb(s, f) * 2 ** f
rows.append(("P3.2 small-case brute force s<=7", "all", "match", "OK", "C(s,f)*2^f"))
check("P3.2 teacher's form 2^5*20*49*47*46", 2 ** 5 * 20 * 49 * 47 * 46, comb(50, 5) * 32)
# Problem 3.3: search r,b in 1..60 by brute-force team enumeration
sols = []
for r in range(1, 61):
    for b in range(1, 61 - r):
        if comb(r, 2) * b + r * comb(b, 2) != 25:
            continue
        studs = ["R"] * r + ["B"] * b
        mixed = sum(1 for t in combinations(range(r + b), 3) if len({studs[i] for i in t}) == 2)
        if mixed == 25:
            sols.append((r, b))
check("P3.3 jersey solutions", sorted(sols), [(2, 5), (5, 2)])
check("P3.3 class size", {r + b for r, b in sols}, {7})

# =====================================================================
# PROBLEM SET 4 (all 18)
# =====================================================================
check("PS1 3 of 10 candies", len(list(combinations(range(10), 3))), (10 * 9 * 8) // F(3))
ps2 = set()
for c5 in combinations(range(9), 5):
    ps2.add((frozenset(c5), frozenset(set(range(9)) - set(c5))))
check("PS2 team of 5 + team of 4 from 9", len(ps2), comb(9, 5) * comb(4, 4))
check("PS3 two teams of 5 from 10", len(unordered_partitions(list(range(10)), [5, 5])), comb(10, 5) // F(2))
check("PS4 UUURRRR", len(set(permutations("UUURRRR"))), comb(7, 3))
A, B, C = (0, 0), (4, 3), (8, 8)
check("PS5 A->B", len(paths(A, B)), comb(7, 3))
check("PS6 B->C", len(paths(B, C)), comb(9, 4))
thruB = [p for p in paths(A, C) if any(
    (p[:i].count("R"), p[:i].count("U")) == B for i in range(len(p) + 1))]
check("PS7 A->C through B", len(thruB), comb(7, 3) * comb(9, 4))
check("PS8 three teams of 4 from 12", len(unordered_partitions(list(range(12)), [4, 4, 4])),
      F(12) // (F(4) ** 3 * F(3)), "34650 / 3!")
# PS9: brute force over all set partitions of 12 (Bell(12) = 4,213,597), keep block sizes {2,2,2,3,3}
target = [2, 2, 2, 3, 3]
cnt9 = 0
for rgs in set_partitions_rgs(12):
    m = max(rgs) + 1
    if m != 5: continue
    if sorted(rgs.count(j) for j in range(m)) == target:
        cnt9 += 1
check("PS9 groups 2,2,2,3,3 from 12", cnt9, F(12) // (F(2) ** 3 * F(3) ** 2 * F(3) * F(2)))
boys, girls = range(6), range(6, 12)
subs = [frozenset(bb + gg) for bb in combinations(boys, 2) for gg in combinations(girls, 2)]
ps10 = {frozenset((s, t)) for s in subs for t in subs if not (s & t)}
check("PS10 two disjoint 2B+2G subcommittees", len(ps10), comb(6, 2) ** 2 * comb(4, 2) ** 2 // 2,
      "8100 if the subcommittees were labeled")
ps11 = sum(1 for f in product(range(4), repeat=5) if len(set(f)) == 4)
check("PS11 5 jobs to 4 kids, each >=1", ps11, comb(5, 2) * F(4), "tempting 480 counts each twice")
check("PS12 segments on cube vertices", len(list(combinations(cube, 2))), comb(8, 2))
octo = sum(1 for a, b in combinations(range(8), 2) if (b - a) % 8 not in (1, 7))
check("PS13 octagon diagonals", octo, comb(8, 2) - 8, "= 8*5/2")
def mono(n):
    d = str(n)
    return len(set(d)) == 3 and (d[0] < d[1] < d[2] or d[0] > d[1] > d[2])
inc = sum(1 for n in range(100, 1000) if mono(n) and str(n)[0] < str(n)[1])
dec = sum(1 for n in range(100, 1000) if mono(n) and str(n)[0] > str(n)[1])
check("PS14 increasing", inc, comb(9, 3), "0 can never lead, so digits 1-9")
check("PS14 decreasing", dec, comb(10, 3), "0 can sit last")
check("PS14 total", inc + dec, comb(9, 3) + comb(10, 3))
cells = [(r, c) for r in range(5) for c in range(5)]
ps15 = sum(1 for t in combinations(cells, 3)
           if len({x[0] for x in t}) == 3 and len({x[1] for x in t}) == 3)
check("PS15 3 blocks, no shared row/col", ps15, comb(5, 3) * 5 * 4 * 3, "choose rows, then columns in order")
# PS16: coins listed bottom->top; each is (colour, face_up?). Face-to-face: lower face up & upper face down.
ps16 = set()
for cols in set(permutations("GGGGSSSS")):
    for ori in product((0, 1), repeat=8):          # 1 = face on top
        if all(not (ori[i] == 1 and ori[i + 1] == 0) for i in range(7)):
            ps16.add((cols, ori))
check("PS16 coin stacks", len(ps16), comb(8, 4) * 9, "70 colour orders x 9 orientation patterns")
n17 = [n for n in range(6, 500) if comb(n, 6) == 6 * comb(n, 3)]
check("PS17 n", n17, [13])
sol18 = []
for N in range(6, 200):
    n = N - 5                      # players who stayed and played everyone
    if comb(n, 2) + 5 * 2 == 220:
        sol18.append(N)
check("PS18 players incl. withdrawn", sol18, [26], "C(21,2)=210 plus 10 games")

# =====================================================================
# PHASE-1 ILLUSTRATIVE NUMBERS (plan example, tiny cases, wrong answers, concept-story examples)
# =====================================================================
check("PLAN ex: 3 of 5 friends", len(list(combinations(range(5), 3))), (5 * 4 * 3) // 6, "ordered 60")
check("PS1 tiny: 3 of 4 candies", len(list(combinations("ABCD", 3))), (4 * 3 * 2) // 6)
check("PS1 tempting wrong (ordered)", len(list(permutations(range(10), 3))), 720)
check("PS11 tempting 5*4*3*2*4", 5 * 4 * 3 * 2 * 4, 480)
check("PS11 each assignment built twice", 480 // ps11, 2)
tiny11 = sum(1 for f in product(range(2), repeat=3) if len(set(f)) == 2)
check("PS11 tiny: 3 jobs, 2 kids", tiny11, comb(3, 2) * F(2), "obvious 3*2*2=12, /2")
tiny16 = set()
for cols in set(permutations("GGS")):
    for ori in product((0, 1), repeat=3):
        if all(not (ori[i] == 1 and ori[i + 1] == 0) for i in range(2)):
            tiny16.add((cols, ori))
check("PS16 tiny: 2 gold 1 silver", len(tiny16), comb(3, 1) * 4)
ori8 = [o for o in product((0, 1), repeat=8) if all(not (o[i] == 1 and o[i + 1] == 0) for i in range(7))]
check("PS16 orientation patterns = 'downs then ups'", len(ori8), 9)
check("PS8 tempting C(12,4)C(8,4)", comb(12, 4) * comb(8, 4), 34650)
# concept-story examples (deliberately different numbers from the guided problems)
check("C-swap: 2 of 5 flavours", len({frozenset(p) for p in permutations(range(5), 2)}), 20 // 2)
check("C-formula: 3 of 6", comb(6, 3), (6 * 5 * 4) // 6)
check("C-take/leave: 7 of 9 = 2 of 9", len(list(combinations(range(9), 7))), comb(9, 2))
check("C-bags in a row: 6 kids 3/2/1", F(6) // (F(3) * F(2) * F(1)), comb(6, 3) * comb(3, 2))
check("C-identical teams: 6 into 3+3", len(unordered_partitions(list(range(6)), [3, 3])), 20 // 2)
check("C-positions: HHHTTT", len(set(permutations("HHHTTT"))), comb(6, 3))
check("C-grid 4x2", len(paths((0, 0), (4, 2))), comb(6, 2))
check("C-grid 4x2 via (1,1)", len([p for p in paths((0, 0), (4, 2)) if p[:2] in ("RU", "UR")]),
      comb(2, 1) * comb(4, 1))
check("C-shapes: pentagon triangles", comb(5, 3), len(list(combinations(range(5), 3))))
rect = sum(1 for S in combinations([(i, j) for i in range(4) for j in range(3)], 4) if is_grid_parallelogram(S))
check("C-shapes: rectangles in 3x2 grid", rect, comb(4, 2) * comb(3, 2))
check("C-states: 3 finalists, 4 states x2", sum(1 for c in combinations([(s, w) for s in range(4) for w in range(2)], 3)
      if len({p[0] for p in c}) == 3), comb(4, 3) * 8)
st = ["R"] * 3 + ["B"] * 2
check("C-cases: mixed teams 3R 2B", sum(1 for t in combinations(range(5), 3) if len({st[i] for i in t}) == 2),
      comb(3, 2) * 2 + 3 * comb(2, 2))

w = max(len(r[0]) for r in rows)
for tag, b, a, s, note in rows:
    print(f"{tag:<{w}}  brute={str(b):<14} argument={str(a):<14} {s}  {note}")
print(f"\n{len(rows)} checks, {sum(r[3]=='OK' for r in rows)} OK")

# ---- elementary routes for the algebra problems (added) ----
r17 = [n for n in range(6, 500) if (n-3)*(n-4)*(n-5) == 720]
assert r17 == [13] and 8*9*10 == 720
assert all(Fraction(comb(n,6), comb(n,3)) == Fraction((n-3)*(n-4)*(n-5), 120) for n in range(6, 60))
r18 = [n for n in range(2, 500) if n*(n-1) == 420]
assert r18 == [21] and 21*20 == 420
labeled = {"PS3": comb(10,5), "PS8": comb(12,4)*comb(8,4), "PS9": F(12)//(F(2)**3*F(3)**2), "PS10": 8100}
assert labeled["PS9"] == 138600 * F(3) * F(2)
print("PS17 route: (n-3)(n-4)(n-5)=720=8*9*10 -> n=13  OK")
print("PS18 route: n(n-1)=420=21*20 -> 21 stayers + 5 = 26  OK")
print("Labeled-group readings (for the ambiguity notes):", labeled)
