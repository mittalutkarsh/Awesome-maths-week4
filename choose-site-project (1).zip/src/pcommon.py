"""Helpers shared by the lesson and practice problem modules."""
from itertools import combinations, permutations, product
from math import comb, factorial as F, perm
import visuals as v
from stories import Fr, Skip, V, fmt, choose_story, falling, times, multinomial, paths_brute, PLAN

PH_NUM = "number or expression"
PH_NUMS = "two numbers, e.g. 8 and 3"


def step(q, ans, nudges, hint, reveal, check, ok, type="num", named=None, ph=None, special=None, order=False):
    assert len(nudges) == 3
    return dict(q=q, ans=ans, type=type, nudges=nudges, hint=hint, reveal=reveal, check=check, ok=ok,
                named={str(k): m for k, m in (named or {}).items()}, ph=ph or (PH_NUMS if type == "nums" else PH_NUM),
                special=special, order=order)


def problem(pid, page, section, num, text, steps, story, answer, check, concept=None, inclass=None,
            above=False, note=None, short=None):
    return dict(id=pid, page=page, section=section, num=num, text=text, steps=steps, story=story,
                answer=answer, check=check, concept=concept, inclass=inclass, above=above, note=note,
                short=short or text[:60])


def partitions_brute(n, sizes, named=True):
    """Every way to put n people into groups of the given sizes (by label assignment)."""
    k = len(sizes)
    seen = set()
    for lab in product(range(k), repeat=n):
        if [lab.count(j) for j in range(k)] != list(sizes):
            continue
        blocks = tuple(frozenset(i for i in range(n) if lab[i] == j) for j in range(k))
        seen.add(blocks if named else frozenset(blocks))
    return seen


def split_names(blocks, labels):
    return " | ".join("".join(sorted(labels[i] for i in b)) for b in sorted(blocks, key=lambda b: min(b)))


def slots_from(pairs, result, note=None, label="build", ops=None):
    return v.slots([{"lab": a, "n": b} for a, b in pairs], ops=ops, result=result, note=note, label=label)
