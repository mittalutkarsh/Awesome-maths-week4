/* Sandbox-safe helpers: no storage, no alert/confirm/prompt; hash and history guarded. */
window.SAFE = (function () {
  "use strict";
  function isAbout() { try { return location.protocol === "about:" || location.href === "about:srcdoc"; } catch (e) { return true; } }
  function getHash() { if (isAbout()) return ""; try { return decodeURIComponent((location.hash || "").slice(1)); } catch (e) { return ""; } }
  function setHash(h) {
    if (isAbout()) return false;
    try { history.replaceState(null, "", "#" + h); return true; }
    catch (e) { try { location.hash = h; return true; } catch (e2) { return false; } }
  }
  return { isAbout, getHash, setHash };
})();
