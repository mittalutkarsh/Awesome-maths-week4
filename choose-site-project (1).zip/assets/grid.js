/* Pick grid: pointing at (or focusing) a box lights its twin, unless the grid is plain (no twins). */
(function () {
  "use strict";
  function twin(cell) {
    const svg = cell.closest("svg");
    if (!svg || svg.classList.contains("plain")) return null;
    const r = cell.getAttribute("data-r"), c = cell.getAttribute("data-c");
    if (r === c) return null;
    return svg.querySelector('.pg-cell[data-r="' + c + '"][data-c="' + r + '"]');
  }
  function on(e) { const c = e.target.closest && e.target.closest(".pg-cell"); if (!c) return; const t = twin(c); if (t) { t.classList.add("twin-lit"); c.classList.add("twin-lit"); } }
  function off(e) { const c = e.target.closest && e.target.closest(".pg-cell"); if (!c) return; const t = twin(c); if (t) { t.classList.remove("twin-lit"); c.classList.remove("twin-lit"); } }
  document.addEventListener("pointerover", on);
  document.addEventListener("pointerout", off);
  document.addEventListener("focusin", on);
  document.addEventListener("focusout", off);
})();
