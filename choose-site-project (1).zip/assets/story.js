/* Step-through story: one picture per frame, Back/Next, progress dots, Show all, ←/→ when focused. */
window.STORY = (function () {
  "use strict";
  function setup(st) {
    if (st.dataset.ready) return;
    st.dataset.ready = "1";
    const frames = Array.from(st.querySelectorAll(":scope .frame"));
    const dots = st.querySelector(".dots"), back = st.querySelector("[data-act=back]"), next = st.querySelector("[data-act=next]");
    const all = st.querySelector("input.showall"), name = st.querySelector(".stepname");
    const marks = Array.from(st.querySelectorAll(".plan-side li[data-s], .plan-strip span[data-s]"));
    const skipped = new Set(frames.filter((f) => f.classList.contains("skip")).map((f) => f.dataset.step));
    marks.forEach((m) => m.classList.toggle("skipd", skipped.has(m.dataset.s)));
    let i = 0;
    const seen = new Set([0]);
    frames.forEach((f, k) => {
      const b = document.createElement("button");
      b.type = "button";
      b.setAttribute("aria-label", "Picture " + (k + 1) + " of " + frames.length);
      b.addEventListener("click", () => go(k));
      dots.appendChild(b);
    });
    function go(k) { i = Math.max(0, Math.min(frames.length - 1, k)); seen.add(i); render(); }
    function render() {
      frames.forEach((f, k) => f.classList.toggle("on", k === i));
      Array.from(dots.children).forEach((b, k) => { b.classList.toggle("on", k === i); b.classList.toggle("seen", seen.has(k) && k !== i); });
      back.disabled = i === 0;
      next.disabled = i === frames.length - 1;
      const s = frames[i] && frames[i].dataset.step;
      marks.forEach((m) => m.classList.toggle("on", s && m.dataset.s === s));
      if (name) name.textContent = s && st.dataset.plan ? JSON.parse(st.dataset.plan)[+s - 1] : "";
    }
    back.addEventListener("click", () => go(i - 1));
    next.addEventListener("click", () => go(i + 1));
    st.addEventListener("keydown", (e) => {
      if (e.target.closest("input,textarea,select")) return;
      if (e.key === "ArrowRight") { go(i + 1); e.preventDefault(); }
      else if (e.key === "ArrowLeft") { go(i - 1); e.preventDefault(); }
    });
    all.addEventListener("change", () => st.classList.toggle("all", all.checked));
    st._go = go;
    render();
  }
  function init(root) { (root || document).querySelectorAll(".story").forEach(setup); }
  document.addEventListener("DOMContentLoaded", () => init());
  return { init };
})();
