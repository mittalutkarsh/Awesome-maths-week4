/* Answer checker. Parses numbers and expressions exactly (BigInt rationals), so 2^5*20*49*47*46,
   11!/(4!4!2!), 3×2⁹, 10 choose 3, C(10,3), 10C3 and "1,260" all work. */
window.CHECK = (function () {
  "use strict";
  function gcd(a, b) { a = a < 0n ? -a : a; b = b < 0n ? -b : b; while (b) { [a, b] = [b, a % b]; } return a; }
  function R(n, d) { d = d === undefined ? 1n : d; if (d === 0n) throw new Error("divide by zero"); if (d < 0n) { n = -n; d = -d; } const g = gcd(n, d) || 1n; return { n: n / g, d: d / g }; }
  const add = (a, b) => R(a.n * b.d + b.n * a.d, a.d * b.d);
  const sub = (a, b) => R(a.n * b.d - b.n * a.d, a.d * b.d);
  const mul = (a, b) => R(a.n * b.n, a.d * b.d);
  const div = (a, b) => R(a.n * b.d, a.d * b.n);
  const isInt = (a) => a.d === 1n;
  function fact(a) { if (!isInt(a) || a.n < 0n || a.n > 300n) throw new Error("factorial"); let r = 1n; for (let i = 2n; i <= a.n; i++) r *= i; return R(r); }
  function pow(a, b) {
    if (!isInt(b) || b.n < 0n || b.n > 2000n) throw new Error("power");
    let r = 1n, rd = 1n; for (let i = 0n; i < b.n; i++) { r *= a.n; rd *= a.d; } return R(r, rd);
  }
  function choose(n, k) {
    if (!isInt(n) || !isInt(k) || k.n < 0n || n.n < 0n) throw new Error("choose");
    if (k.n > n.n) return R(0n);
    return div(fact(n), mul(fact(k), fact(R(n.n - k.n))));
  }

  const SUP = { "⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4", "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9" };
  const UNITS = /\s*(ways?|paths?|teams?|players?|students?|games?|diagonals?|segments?|triangles?|parallelograms?|handfuls?|stacks?|arrangements?|combinations?|groups?|kids?|numbers?|options?|possibilities|jobs?|candies|cookies|marbles?)\.?\s*$/;
  function normalize(s) {
    s = String(s).trim().toLowerCase();
    s = s.replace(/[\u2212\u2013\u2014]/g, "-");
    s = s.replace(/[×✕✖·⋅∙•]/g, "*").replace(/÷/g, "/");
    s = s.replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹]+/g, (m) => "^" + [...m].map((c) => SUP[c]).join(""));
    s = s.replace(UNITS, "");
    s = s.replace(/^[a-z]\s*=\s*/, "");          // "n = 13"
    s = s.replace(/(\d),(?=\d{3}(?!\d))/g, "$1");  // thousands commas
    s = s.replace(/(\d)\s+(?=\d{3}(?!\d))/g, "$1"); // "67 800 320"
    s = s.replace(/(\d+)\s*choose\s*(\d+)/g, "c($1,$2)");
    s = s.replace(/(\d+)\s*c\s*(\d+)/g, "c($1,$2)");
    s = s.replace(/(\d|\))\s*x\s*(?=[\d(c])/g, "$1*");
    return s;
  }
  function tokenize(s) {
    const t = []; let i = 0;
    while (i < s.length) {
      const ch = s[i];
      if (/\s/.test(ch)) { i++; continue; }
      if (/[0-9.]/.test(ch)) { let j = i; while (j < s.length && /[0-9.]/.test(s[j])) j++; t.push({ k: "num", v: s.slice(i, j) }); i = j; continue; }
      if (ch === "c" && s[i + 1] === "(") { t.push({ k: "C" }); i++; continue; }
      if ("+-*/^!(),".includes(ch)) { t.push({ k: ch }); i++; continue; }
      throw new Error("bad char " + ch);
    }
    return t;
  }
  function parseNum(v) {
    if ((v.match(/\./g) || []).length > 1) throw new Error("num");
    if (v.includes(".")) { const [a, b] = v.split("."); return R(BigInt((a || "0") + b), 10n ** BigInt(b.length)); }
    return R(BigInt(v));
  }
  function evaluate(src) {
    const t = tokenize(normalize(src)); let p = 0;
    const peek = () => t[p], eat = (k) => { if (!t[p] || t[p].k !== k) throw new Error("expected " + k); return t[p++]; };
    let ops = 0;
    function expr() { let a = term(); while (peek() && (peek().k === "+" || peek().k === "-")) { const o = t[p++].k; ops++; const b = term(); a = o === "+" ? add(a, b) : sub(a, b); } return a; }
    function startsFactor(tk) { return tk && (tk.k === "num" || tk.k === "(" || tk.k === "C"); }
    function term() {
      let a = power();
      for (;;) {
        const tk = peek();
        if (tk && (tk.k === "*" || tk.k === "/")) { p++; ops++; const b = power(); a = tk.k === "*" ? mul(a, b) : div(a, b); }
        else if (startsFactor(tk)) { ops++; a = mul(a, power()); }
        else break;
      }
      return a;
    }
    function power() { const a = unary(); if (peek() && peek().k === "^") { p++; ops++; return pow(a, power()); } return a; }
    function unary() { if (peek() && peek().k === "-") { p++; return sub(R(0n), unary()); } return post(); }
    function post() { let a = prim(); while (peek() && peek().k === "!") { p++; ops++; a = fact(a); } return a; }
    function prim() {
      const tk = peek(); if (!tk) throw new Error("end");
      if (tk.k === "num") { p++; return parseNum(tk.v); }
      if (tk.k === "(") { p++; const a = expr(); eat(")"); return a; }
      if (tk.k === "C") { p++; eat("("); const n = expr(); eat(","); const k = expr(); eat(")"); ops++; return choose(n, k); }
      throw new Error("unexpected " + tk.k);
    }
    const v = expr(); if (p !== t.length) throw new Error("trailing");
    return { v, ops };
  }
  function tryEval(s) { try { return evaluate(s); } catch (e) { return null; } }
  const show = (r) => (r.d === 1n ? r.n.toLocaleString("en-US") : r.n + "/" + r.d);
  const big = (x) => R(BigInt(x));
  function splitList(s) {
    let n = normalize(s).replace(/\band\b|&|;/g, ",");
    const parts = n.split(/\s*,\s*|\s+/).filter(Boolean);
    return parts;
  }

  /* grade(step, input, others) -> {ok, msg, kind, value} ; others = answers of the problem's other steps (by number) */
  function grade(step, input, others) {
    others = others || [];
    const raw = String(input || "").trim();
    if (!raw) return { ok: false, kind: "empty", msg: "Type an answer first." };
    const type = step.type;
    if (type === "yn") {
      const y = /^(y|yes|true)$/i.test(raw), n = /^(n|no|false)$/i.test(raw);
      if (!y && !n) return { ok: false, kind: "unread", msg: "Answer yes or no." };
      return y === !!step.ans ? { ok: true } : { ok: false, kind: "wrong", msg: "Not quite. Look at the question again." };
    }
    if (type === "choice") {
      const want = String(step.ans).toLowerCase();
      const opts = (step.options || []).map((o) => o.toLowerCase());
      const got = raw.toLowerCase().replace(/[().]/g, "").trim();
      const idx = opts.indexOf(got);
      const asLetter = idx >= 0 ? String.fromCharCode(97 + idx) : got;
      return asLetter === want || got === want ? { ok: true } : { ok: false, kind: "wrong", msg: "Not that one." };
    }
    if (type === "text") {
      const need = step.ans.map((w) => w.toLowerCase());
      const ok = need.every((w) => raw.toLowerCase().includes(w));
      return ok ? { ok: true } : { ok: false, kind: "wrong", msg: "Something important is missing." };
    }
    if (type === "nums") {
      const parts = splitList(raw), vals = [];
      for (const pt of parts) { const e = tryEval(pt); if (!e) return { ok: false, kind: "unread", msg: "I couldn't read that list. Try two numbers like “8 and 3”." }; vals.push(e.v); }
      const want = step.ans.map(big);
      const key = vals.map(show).join(",").replace(/,(?=\d{3})/g, "");
      if (step.named && step.named[vals.map((v) => v.n.toString()).join(",")]) return { ok: false, kind: "named", msg: step.named[vals.map((v) => v.n.toString()).join(",")] };
      if (vals.length !== want.length) return { ok: false, kind: "count", msg: `I expected ${want.length} numbers; you gave ${vals.length}.` };
      const eqv = (a, b) => a.n === b.n && a.d === b.d;
      if (step.order) {
        if (vals.every((v, i) => eqv(v, want[i]))) return { ok: true };
        const sortedSame = [...vals].map(show).sort().join() === [...want].map(show).sort().join();
        if (sortedSame) return { ok: false, kind: "order", msg: "Right numbers, wrong order." };
      } else {
        const a = vals.map(show).sort().join(), b = want.map(show).sort().join();
        if (a === b) return { ok: true };
      }
      const hits = vals.filter((v) => want.some((w) => eqv(v, w))).length;
      if (hits === want.length - 1) return { ok: false, kind: "oneoff", msg: "Right number of values, but one is off." };
      return { ok: false, kind: "wrong", msg: "Those aren't the values." };
    }
    // num / expr
    const e = tryEval(raw);
    if (!e) return { ok: false, kind: "unread", msg: "I couldn't read that. Try a number, or an expression like 12 × 11 ÷ 4." };
    const v = e.v, want = big(step.ans);
    if (type === "expr" && e.ops === 0) return { ok: false, kind: "form", msg: "This step wants an expression (with ×, ÷, ! or a power), not just the number." };
    if (v.n === want.n && v.d === want.d) return { ok: true, value: v };
    if (step.special === "ps17" && isInt(v) && v.n >= 6n && v.n <= 400n) {
      const n = v, s6 = choose(n, R(6n)), s3 = choose(n, R(3n)), six = mul(R(6n), s3);
      const cmp = s6.n < six.n ? "too few sets of 6 — try a bigger n" : "too many sets of 6 — try a smaller n";
      return { ok: false, kind: "named", value: v, msg: `For n = ${show(n)}: sets of 6 = ${show(s6)}, and 6 × sets of 3 = ${show(six)}. That's ${cmp}.` };
    }
    const key = v.d === 1n ? v.n.toString() : null;
    if (key && step.named && step.named[key]) return { ok: false, kind: "named", value: v, msg: step.named[key] };
    for (let i = 0; i < others.length; i++) {
      if (others[i] === null || others[i] === undefined || Array.isArray(others[i])) continue;
      const o = big(others[i]);
      if (o.n === v.n && o.d === v.d) return { ok: false, kind: "otherstep", value: v, msg: `That's step ${i + 1}'s answer.` };
    }
    if (!isInt(v)) return { ok: false, kind: "frac", value: v, msg: "Counts are whole numbers. Is there a division that doesn't come out even?" };
    const diff = v.n > want.n ? v.n - want.n : want.n - v.n;
    const close = diff * 50n <= want.n || diff <= 2n;
    if (close) return { ok: false, kind: "close", value: v, msg: "Very close. Recheck the arithmetic." };
    if (v.n > want.n) {
      const q = v.n / want.n;
      if (v.n % want.n === 0n && q > 1n && q <= 720n) return { ok: false, kind: "big", value: v, msg: "Too big. Did something get counted more than once?" };
      return { ok: false, kind: "big", value: v, msg: "Too big." };
    }
    return { ok: false, kind: "small", value: v, msg: "Too small. Is a choice missing?" };
  }
  return { grade, evaluate: (s) => { const e = tryEval(s); return e ? show(e.v) : null; }, normalize };
})();
