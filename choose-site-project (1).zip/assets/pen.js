/* Teaching pen.
   Two viewport-sized canvases: `base` holds committed strokes, `live` holds only the stroke being drawn.
   While drawing, only the newest segments are painted; old strokes are never redrawn.
   Reading pages (data-penmode="page"): strokes are stored in page coordinates and stay on the content; a finger scrolls.
   Workbench pages (data-penmode="viewport"): strokes are viewport-anchored, the pen layer swallows scrolling,
   and ink is kept per problem through window.INK.get/set. */
(function () {
  "use strict";
  const MODE = document.body.dataset.penmode === "viewport" ? "viewport" : "page";
  const DPR = Math.min(2, window.devicePixelRatio || 1);
  const COLORS = [["ink", "#1C2A4A"], ["red", "#C23A2E"], ["blue", "#2D6BD0"], ["green", "#1E7A50"]];
  const WIDTHS = [2, 3.5, 6];
  const stats = { framesDrawing: 0, oldRedrawsWhileDrawing: 0, baseRedraws: 0, segmentsPainted: 0 };
  window.__PEN = { stats, mode: MODE, megapixels: () => 2 * (base.width * base.height) / 1e6, strokes: () => strokes };

  const base = document.createElement("canvas"), live = document.createElement("canvas");
  base.className = "pen-canvas base"; live.className = "pen-canvas live";
  base.setAttribute("aria-hidden", "true"); live.setAttribute("aria-hidden", "true");
  const bctx = base.getContext("2d"), lctx = live.getContext("2d");
  let strokes = [], undoStack = [], redoStack = [];
  let on = false, tool = "pen", color = COLORS[0][1], widthIdx = 1, stylusOnly = false;
  let drawing = null, raf = 0, scrollRaf = 0;

  function off() { return MODE === "page" ? [window.scrollX, window.scrollY] : [0, 0]; }
  function size() {
    for (const c of [base, live]) {
      c.width = Math.round(window.innerWidth * DPR);
      c.height = Math.round(window.innerHeight * DPR);
      c.style.width = window.innerWidth + "px";
      c.style.height = window.innerHeight + "px";
      c.getContext("2d").setTransform(DPR, 0, 0, DPR, 0, 0);
    }
    redrawBase();
  }

  /* ---- drawing primitives ---- */
  function style(ctx, s) {
    ctx.lineCap = "round"; ctx.lineJoin = "round";
    ctx.strokeStyle = s.color;
    ctx.globalAlpha = s.tool === "marker" ? 0.32 : 1;
  }
  function seg(ctx, s, k, ox, oy) {
    // smoothed segment k: from mid(k-2,k-1) to mid(k-1,k) with control point k-1
    const p = s.pts;
    const a = p[k - 2] || p[k - 1], b = p[k - 1], c = p[k];
    const m1x = (a[0] + b[0]) / 2 - ox, m1y = (a[1] + b[1]) / 2 - oy, m2x = (b[0] + c[0]) / 2 - ox, m2y = (b[1] + c[1]) / 2 - oy;
    ctx.lineWidth = b[2];
    ctx.beginPath(); ctx.moveTo(m1x, m1y); ctx.quadraticCurveTo(b[0] - ox, b[1] - oy, m2x, m2y); ctx.stroke();
    stats.segmentsPainted++;
  }
  function drawShape(ctx, s, ox, oy) {
    style(ctx, s);
    if (s.tool === "line" || s.snapped) {
      const a = s.pts[0], b = s.pts[s.pts.length - 1];
      ctx.lineWidth = s.w; ctx.beginPath(); ctx.moveTo(a[0] - ox, a[1] - oy); ctx.lineTo(b[0] - ox, b[1] - oy); ctx.stroke();
    } else if (s.tool === "box") {
      const a = s.pts[0], b = s.pts[s.pts.length - 1];
      ctx.lineWidth = s.w; ctx.strokeRect(Math.min(a[0], b[0]) - ox, Math.min(a[1], b[1]) - oy, Math.abs(b[0] - a[0]), Math.abs(b[1] - a[1]));
    } else if (s.tool === "marker") {
      // translucent: draw as one path so overlaps inside the stroke don't darken
      ctx.lineWidth = s.w; ctx.beginPath();
      const p = s.pts; ctx.moveTo(p[0][0] - ox, p[0][1] - oy);
      for (let k = 1; k < p.length; k++) { const mx = (p[k - 1][0] + p[k][0]) / 2 - ox, my = (p[k - 1][1] + p[k][1]) / 2 - oy; ctx.quadraticCurveTo(p[k - 1][0] - ox, p[k - 1][1] - oy, mx, my); }
      ctx.stroke();
    } else {
      if (s.pts.length === 1) { ctx.lineWidth = s.pts[0][2]; ctx.beginPath(); ctx.arc(s.pts[0][0] - ox, s.pts[0][1] - oy, s.pts[0][2] / 2, 0, 7); ctx.fillStyle = s.color; ctx.fill(); }
      for (let k = 1; k < s.pts.length; k++) seg(ctx, s, k, ox, oy);
    }
    ctx.globalAlpha = 1;
  }
  function redrawBase() {
    if (drawing) stats.oldRedrawsWhileDrawing++;
    stats.baseRedraws++;
    bctx.clearRect(0, 0, base.width, base.height);
    const [ox, oy] = off();
    for (const s of strokes) drawShape(bctx, s, ox, oy);
  }

  /* ---- pointer handling ---- */
  function accept(e) {
    if (!on) return false;
    if (e.pointerType === "touch" && (stylusOnly || MODE === "page")) return false; // palm rejection / finger scrolls
    return true;
  }
  function pt(e, prev) {
    const [ox, oy] = off();
    const x = e.clientX + ox, y = e.clientY + oy, t = e.timeStamp || performance.now();
    const baseW = WIDTHS[widthIdx] * (tool === "marker" ? 4 : 1);
    let w = baseW;
    if (prev && tool === "pen") {
      const dt = Math.max(1, t - prev[3]), v = Math.hypot(x - prev[0], y - prev[1]) / dt;
      const target = baseW * Math.max(0.45, Math.min(1.25, 1.25 - v * 0.35));
      w = prev[2] * 0.7 + target * 0.3;
    }
    return [x, y, w, t];
  }
  function down(e) {
    if (!accept(e)) return;
    e.preventDefault();
    try { live.setPointerCapture(e.pointerId); } catch (_) {}
    if (tool === "eraser") { drawing = { tool: "eraser", removed: [] }; eraseAt(e); return; }
    const p = pt(e, null);
    drawing = { tool, color, w: WIDTHS[widthIdx] * (tool === "marker" ? 4 : 1), pts: [p], drawn: 1, snapped: false };
    schedule();
  }
  function move(e) {
    if (!drawing) return;
    e.preventDefault();
    if (drawing.tool === "eraser") { eraseAt(e); return; }
    const evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
    for (const ev of evs.length ? evs : [e]) drawing.pts.push(pt(ev, drawing.pts[drawing.pts.length - 1]));
    drawing.snapped = (drawing.tool === "pen" || drawing.tool === "marker") && e.shiftKey;
    schedule();
  }
  function up(e) {
    if (!drawing) return;
    if (drawing.tool === "eraser") {
      if (drawing.removed.length) { undoStack.push({ type: "erase", items: drawing.removed }); redoStack = []; }
      drawing = null; persist(); return;
    }
    cancelAnimationFrame(raf); raf = 0;
    const s = drawing; drawing = null;
    delete s.drawn;
    if ((s.tool === "line" || s.tool === "box" || s.snapped) && s.pts.length > 1) s.pts = [s.pts[0], s.pts[s.pts.length - 1]];
    strokes.push(s);
    undoStack.push({ type: "add", stroke: s }); redoStack = [];
    lctx.clearRect(0, 0, live.width, live.height);
    const [ox, oy] = off();
    drawShape(bctx, s, ox, oy);           // commit: paint only the new stroke onto the base layer
    persist();
  }
  function schedule() { if (!raf) raf = requestAnimationFrame(frame); }
  function frame() {
    raf = 0;
    if (!drawing) return;
    stats.framesDrawing++;
    const s = drawing, [ox, oy] = off();
    if (s.tool === "pen" && !s.snapped) {
      style(lctx, s);
      for (let k = Math.max(1, s.drawn); k < s.pts.length; k++) seg(lctx, s, k, ox, oy);   // only new points
      s.drawn = s.pts.length;
    } else {
      // marker, line, box, shift-snapped: the live layer shows just this one shape
      lctx.clearRect(0, 0, live.width, live.height);
      drawShape(lctx, s, ox, oy);
      if (s.tool === "pen") s.drawn = 1;
    }
  }
  function eraseAt(e) {
    const [ox, oy] = off();
    const x = e.clientX + ox, y = e.clientY + oy;
    let hit = false;
    for (let i = strokes.length - 1; i >= 0; i--) {
      const s = strokes[i];
      const near = s.pts.some((p) => Math.hypot(p[0] - x, p[1] - y) < 12) ||
        ((s.tool === "line" || s.tool === "box" || s.snapped) && nearShape(s, x, y));
      if (near) { drawing.removed.push({ stroke: s, index: i }); strokes.splice(i, 1); hit = true; }
    }
    if (hit) { const d = drawing; drawing = null; redrawBase(); drawing = d; }
  }
  function nearShape(s, x, y) {
    const a = s.pts[0], b = s.pts[s.pts.length - 1];
    const segs = s.tool === "box" ? [[a[0], a[1], b[0], a[1]], [b[0], a[1], b[0], b[1]], [b[0], b[1], a[0], b[1]], [a[0], b[1], a[0], a[1]]] : [[a[0], a[1], b[0], b[1]]];
    return segs.some(([x1, y1, x2, y2]) => {
      const L = Math.hypot(x2 - x1, y2 - y1) || 1, t = Math.max(0, Math.min(1, ((x - x1) * (x2 - x1) + (y - y1) * (y2 - y1)) / (L * L)));
      return Math.hypot(x - (x1 + t * (x2 - x1)), y - (y1 + t * (y2 - y1))) < 10;
    });
  }

  /* ---- history ---- */
  function undo() {
    const a = undoStack.pop(); if (!a) return;
    if (a.type === "add") strokes.splice(strokes.lastIndexOf(a.stroke), 1);
    else if (a.type === "erase") a.items.slice().reverse().forEach((it) => strokes.splice(it.index, 0, it.stroke));
    else if (a.type === "clear") strokes = a.items.slice();
    redoStack.push(a); redrawBase(); persist();
  }
  function redo() {
    const a = redoStack.pop(); if (!a) return;
    if (a.type === "add") strokes.push(a.stroke);
    else if (a.type === "erase") a.items.forEach((it) => { const i = strokes.indexOf(it.stroke); if (i >= 0) strokes.splice(i, 1); });
    else if (a.type === "clear") strokes = [];
    undoStack.push(a); redrawBase(); persist();
  }
  function clearAll() {
    if (!strokes.length) return;
    undoStack.push({ type: "clear", items: strokes.slice() }); redoStack = [];
    strokes = []; redrawBase(); persist();
  }
  function exportPng() {
    try {
      const a = document.createElement("a");
      a.href = base.toDataURL("image/png");
      a.download = "ink.png";
      document.body.appendChild(a); a.click(); a.remove();
      note("Saved the ink only (not the page underneath).");
    } catch (err) { note("Export isn't allowed here."); }
  }

  /* ---- per-problem ink (workbench) ---- */
  let problemId = null;
  function persist() { if (MODE === "viewport" && problemId && window.INK) window.INK.set(problemId, strokes.slice()); }
  document.addEventListener("bench:problem", (e) => {
    if (MODE !== "viewport") return;
    if (e.detail.from && window.INK) window.INK.set(e.detail.from, strokes.slice());
    problemId = e.detail.to;
    strokes = window.INK ? window.INK.get(problemId).slice() : [];
    undoStack = []; redoStack = [];
    redrawBase();
  });

  /* ---- toolbar ---- */
  const bar = document.createElement("div");
  bar.className = "pen-bar"; bar.setAttribute("role", "toolbar"); bar.setAttribute("aria-label", "Teaching pen");
  const btn = (label, title, fn, pressed) => {
    const b = document.createElement("button"); b.type = "button"; b.innerHTML = label; b.title = title; b.setAttribute("aria-label", title);
    if (pressed !== undefined) b.setAttribute("aria-pressed", String(pressed));
    b.addEventListener("click", fn); return b;
  };
  const toggle = btn("✎ Pen", "Pen on/off (P)", () => setOn(!on), false);
  const tools = document.createElement("div"); tools.className = "tools";
  const toolBtns = {};
  [["pen", "✎", "Pen"], ["marker", "▬", "Marker"], ["line", "╱", "Straight line"], ["box", "▭", "Box"], ["eraser", "⌫", "Eraser"]].forEach(([k, g, t]) => {
    toolBtns[k] = btn(g, t, () => setTool(k), k === tool); tools.appendChild(toolBtns[k]);
  });
  tools.appendChild(Object.assign(document.createElement("span"), { className: "sep" }));
  const colBtns = COLORS.map(([n, c], i) => { const b = btn('<span class="sw" style="background:' + c + '"></span>', n + " ink", () => setColor(i), i === 0); tools.appendChild(b); return b; });
  tools.appendChild(Object.assign(document.createElement("span"), { className: "sep" }));
  const wBtns = WIDTHS.map((w, i) => { const b = btn(["thin", "medium", "thick"][i][0].toUpperCase(), ["Thin", "Medium", "Thick"][i] + " nib", () => setWidth(i), i === widthIdx); tools.appendChild(b); return b; });
  tools.appendChild(Object.assign(document.createElement("span"), { className: "sep" }));
  tools.appendChild(btn("↶", "Undo", undo)); tools.appendChild(btn("↷", "Redo", redo)); tools.appendChild(btn("Clear", "Clear all ink (undoable)", clearAll));
  tools.appendChild(btn("PNG", "Export the ink only as a PNG image (not the page)", exportPng));
  const stylusBtn = btn("Stylus only", "Ignore finger touches (palm rejection)", () => { stylusOnly = !stylusOnly; stylusBtn.setAttribute("aria-pressed", String(stylusOnly)); }, false);
  tools.appendChild(stylusBtn);
  const noteEl = document.createElement("span"); noteEl.className = "note"; noteEl.setAttribute("aria-live", "polite");
  tools.appendChild(noteEl);
  bar.appendChild(toggle); bar.appendChild(tools);
  function note(t) { noteEl.textContent = t; }
  function setOn(v) {
    on = v;
    toggle.setAttribute("aria-pressed", String(on));
    bar.classList.toggle("open", on);
    live.classList.toggle("active", on);
    live.classList.toggle(MODE === "page" ? "touchpass" : "swallow", on);
    note(on ? (MODE === "page" ? "Ink stays on the page; a finger scrolls." : "Ink stays with this problem.") : "");
  }
  function setTool(k) { tool = k; Object.entries(toolBtns).forEach(([n, b]) => b.setAttribute("aria-pressed", String(n === k))); }
  function setColor(i) { color = COLORS[i][1]; colBtns.forEach((b, j) => b.setAttribute("aria-pressed", String(i === j))); }
  function setWidth(i) { widthIdx = i; wBtns.forEach((b, j) => b.setAttribute("aria-pressed", String(i === j))); }

  /* ---- wiring ---- */
  function typing(e) { const t = e.target; return !!(t && t.closest && t.closest("input,textarea,select,[contenteditable=true]")); }
  document.addEventListener("keydown", (e) => {
    if (typing(e) || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === "p" || e.key === "P") { setOn(!on); e.preventDefault(); }
    else if (e.key === "Escape" && on) setOn(false);
  });
  live.addEventListener("pointerdown", down);
  live.addEventListener("pointermove", move);
  live.addEventListener("pointerup", up);
  live.addEventListener("pointercancel", up);
  if (MODE === "page") {
    window.addEventListener("scroll", () => { if (!scrollRaf) scrollRaf = requestAnimationFrame(() => { scrollRaf = 0; redrawBase(); }); }, { passive: true });
    // wheel over the active pen layer still scrolls the page
    live.addEventListener("wheel", (e) => { window.scrollBy(e.deltaX, e.deltaY); }, { passive: true });
  } else {
    live.addEventListener("wheel", (e) => { if (on) e.preventDefault(); }, { passive: false });
  }
  window.addEventListener("resize", size);
  document.addEventListener("DOMContentLoaded", () => {
    document.body.appendChild(base); document.body.appendChild(live); document.body.appendChild(bar);
    size();
  });
  window.PEN = { setOn, setTool, setColor, setWidth, undo, redo, clearAll, exportPng, isOn: () => on, setStylusOnly: (v) => { stylusOnly = v; stylusBtn.setAttribute("aria-pressed", String(v)); } };
})();
