/* Workbench: problem rail, tabs, per-step grading loop, hint dialog, submit/reveal, timer, deep links.
   Nothing is stored between visits (no browser storage is used); ink is kept per problem in window.INK. */
(function () {
  "use strict";
  const DATA = JSON.parse(document.getElementById("bench-data").textContent);
  const P = DATA.problems, byId = {};
  P.forEach((p) => (byId[p.id] = p));
  const $ = (id) => document.getElementById(id);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  /* ---- ink per problem ---- */
  const inkStore = {};
  window.INK = { get: (id) => inkStore[id] || [], set: (id, strokes) => { inkStore[id] = strokes; } };

  /* ---- state ---- */
  const S = {};
  P.forEach((p) => {
    S[p.id] = { time: 0, cur: 0, revealed: false, submitted: false, confirmArmed: 0,
      steps: p.steps.map(() => ({ tries: 0, misses: 0, state: "open", work: "", hints: 0, answers: [] })) };
  });
  let cur = null, tab = DATA.page === "lesson" ? "concept" : "problem", lastTick = Date.now();

  function status(id) {
    const s = S[id];
    if (s.revealed || s.steps.every((x) => x.state !== "open")) return "closed";
    if (s.steps.some((x) => x.tries || x.work.trim() || x.hints)) return "prog";
    return "untouched";
  }
  function finished() { return P.filter((p) => status(p.id) === "closed").length; }

  /* ---- console ---- */
  function log(msg, cls) {
    const c = $("console");
    const d = el("div", cls || "");
    const t = new Date();
    d.innerHTML = '<span class="ts">' + String(t.getHours()).padStart(2, "0") + ":" + String(t.getMinutes()).padStart(2, "0") + "</span>" + msg;
    c.appendChild(d);
    c.scrollTop = c.scrollHeight;
    if (cur) (S[cur].log = S[cur].log || []).push(d.outerHTML);
  }

  /* ---- top bar and rail ---- */
  function buildNav() {
    const sel = $("psel"), rail = $("rail");
    let lastSec = null, og = null;
    P.forEach((p) => {
      if (p.section !== lastSec) {
        og = el("optgroup"); og.label = p.section; sel.appendChild(og);
        rail.appendChild(el("h4", "", esc(p.section)));
        lastSec = p.section;
      }
      const o = el("option"); o.value = p.id; o.textContent = p.label; og.appendChild(o);
      const b = el("button", "", '<span class="sdot" aria-hidden="true"></span><span></span>');
      b.type = "button"; b.dataset.id = p.id; b.lastChild.textContent = p.label;
      b.setAttribute("aria-label", p.label);
      b.addEventListener("click", () => { select(p.id); rail.classList.remove("open"); });
      rail.appendChild(b);
    });
    sel.addEventListener("change", () => select(sel.value));
    $("prev").addEventListener("click", () => step(-1));
    $("next").addEventListener("click", () => step(1));
    $("railToggle").addEventListener("click", () => $("rail").classList.toggle("open"));
  }
  function step(d) { const i = P.findIndex((p) => p.id === cur); select(P[(i + d + P.length) % P.length].id); }
  function refreshNav() {
    $("psel").value = cur;
    document.querySelectorAll("#rail button[data-id]").forEach((b) => {
      b.classList.toggle("cur", b.dataset.id === cur);
      const st = status(b.dataset.id);
      b.firstChild.className = "sdot" + (st === "prog" ? " prog" : st === "closed" ? " closed" : "");
      b.setAttribute("aria-label", byId[b.dataset.id].label + " (" + (st === "untouched" ? "not started" : st === "prog" ? "in progress" : "finished") + ")");
    });
    $("finished").textContent = finished() + " / " + P.length + " finished";
  }

  /* ---- timer ---- */
  function tick() {
    const now = Date.now();
    if (cur && !document.hidden) S[cur].time += now - lastTick;
    lastTick = now;
    if (cur) { const s = Math.floor(S[cur].time / 1000); $("timer").textContent = "⏱ " + Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); }
  }
  setInterval(tick, 1000);

  /* ---- tabs ---- */
  function setTab(t) {
    tab = t;
    document.querySelectorAll("#tabs button").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.tab === t)));
    document.querySelectorAll(".tabpanel").forEach((pn) => (pn.hidden = pn.id !== "tab-" + t));
    if (t === "steps") renderMySteps();
  }

  /* ---- middle pane ---- */
  function renderProblem() {
    const p = byId[cur], s = S[cur], box = $("tab-problem");
    let h = '<h2>' + esc(p.label) + "</h2>";
    h += '<div class="ptext">' + esc(p.text) + "</div>";
    let meta = "";
    if (p.inclass) meta += '<span class="inclass" title="time in your class video">In class ' + esc(p.inclass) + "</span>";
    if (p.above) meta += '<span class="above">Above grade: split into steps</span>';
    if (meta) h += '<p class="pnote">' + meta + "</p>";
    if (p.note) h += '<p class="pnote">' + esc(p.note) + "</p>";
    const open = s.revealed || s.submitted;
    if (open) {
      h += '<div class="verified" id="verified"><h3>Verified answer: ' + esc(p.answer) + "</h3><p>" + esc(p.check) + "</p>" +
        "<h3>Worked answer</h3>" + p.story + "</div>";
    } else {
      h += '<p class="pnote">The worked answer appears here after you close every step and press <b>Submit question</b>.</p>';
    }
    box.innerHTML = h;
    if (open) window.STORY.init(box);
    if (DATA.page === "lesson") {
      $("tab-concept").innerHTML = DATA.concepts[p.concept];
      window.STORY.init($("tab-concept"));
    }
  }
  function renderMySteps() {
    const p = byId[cur], s = S[cur];
    let h = '<div class="mysteps">';
    p.steps.forEach((st, i) => {
      const x = s.steps[i];
      const res = x.state === "ok" ? "✓ closed" : x.state === "handed" ? "answer handed over" : x.tries ? "open (" + x.tries + " tries)" : "not tried";
      h += '<div class="ms"><b>Step ' + (i + 1) + ":</b> " + esc(st.q) + '<br><span class="pnote">' + res + (x.hints ? ", hint opened" : "") +
        "</span>" + (x.work.trim() ? "<pre>" + esc(x.work) + "</pre>" : "") +
        (x.answers.length ? '<span class="pnote">Answers tried: ' + x.answers.map(esc).join(" · ") + "</span>" : "") + "</div>";
    });
    $("tab-steps").innerHTML = h + "</div>";
  }

  /* ---- right pane ---- */
  function renderRight() {
    const p = byId[cur], s = S[cur], st = p.steps[s.cur], x = s.steps[s.cur];
    const pills = $("pills");
    pills.innerHTML = "";
    p.steps.forEach((_, i) => {
      const b = el("button");
      b.type = "button";
      b.textContent = "Step " + (i + 1);
      const xi = s.steps[i];
      b.className = (i === s.cur ? "cur " : "") + (xi.state === "ok" ? "ok" : xi.state === "handed" ? "handed" : xi.tries ? "tried" : "");
      b.setAttribute("aria-label", "Step " + (i + 1) + (xi.state === "ok" ? ", closed" : xi.state === "handed" ? ", handed over" : ", open"));
      b.addEventListener("click", () => { saveWork(); s.cur = i; renderRight(); });
      pills.appendChild(b);
    });
    $("stepq").textContent = st.q;
    $("work").value = x.work;
    syncGutter();
    $("answer").value = "";
    $("answer").placeholder = st.ph;
    const closed = x.state !== "open";
    $("answer").disabled = closed;
    $("check").disabled = closed;
    $("hint").disabled = closed;
    $("stepstate").textContent = x.state === "ok" ? "Step closed. " + st.ok : x.state === "handed" ? "Answer handed over: " + st.reveal : (x.misses === 3 ? "One final attempt on this step." : "");
    $("reveal").textContent = "Show worked answer";
    $("confirmNote").textContent = "";
    s.confirmArmed = 0;
  }
  function saveWork() { if (cur) S[cur].steps[S[cur].cur].work = $("work").value; }
  function syncGutter() {
    const n = Math.max(6, $("work").value.split("\n").length);
    $("gutter").innerHTML = Array.from({ length: n }, (_, i) => i + 1).join("<br>");
    $("gutter").scrollTop = $("work").scrollTop;
  }

  /* ---- grading loop ---- */
  function nextOpen(s) {
    const n = s.steps.length;
    for (let k = 1; k <= n; k++) { const j = (s.cur + k) % n; if (s.steps[j].state === "open") return j; }
    return s.cur;
  }
  function checkStep() {
    const p = byId[cur], s = S[cur], i = s.cur, st = p.steps[i], x = s.steps[i];
    if (x.state !== "open") return;
    saveWork();
    const val = $("answer").value;
    const others = p.steps.map((o, k) => (k === i ? null : o.ans));
    const r = window.CHECK.grade(st, val, others);
    if (r.kind === "empty" || r.kind === "unread" || r.kind === "count" || r.kind === "form") { log("Step " + (i + 1) + ": " + esc(r.msg), "info"); return; }
    x.tries++;
    x.answers.push(val.trim());
    if (r.ok) {
      x.state = "ok";
      log("✓ Step " + (i + 1) + " closed (“" + esc(val.trim()) + "”). " + esc(st.ok), "ok");
      s.cur = nextOpen(s);
    } else {
      x.misses++;
      const nudge = st.nudges[Math.min(x.misses - 1, 2)];
      if (x.misses <= 3) {
        log("✗ Step " + (i + 1) + ", try " + x.misses + ": “" + esc(val.trim()) + "”. " + esc(r.msg) + " " + esc(nudge), "bad");
        if (x.misses === 3) log("One final attempt on step " + (i + 1) + ".", "hand");
      } else {
        x.state = "handed";
        log("✗ Step " + (i + 1) + ", final attempt: “" + esc(val.trim()) + "”. " + esc(r.msg), "bad");
        log("Handing over step " + (i + 1) + ": " + esc(st.reveal) + " Check: " + esc(st.check) + " Keep going with the next step yourself.", "hand");
        s.cur = nextOpen(s);
      }
    }
    renderRight();
    refreshNav();
    if (tab === "steps") renderMySteps();
  }
  function openHint() {
    const p = byId[cur], s = S[cur], st = p.steps[s.cur];
    s.steps[s.cur].hints++;
    $("hintTitle").textContent = "Hint for step " + (s.cur + 1);
    $("hintBody").textContent = st.hint;
    $("hintDialog").classList.add("open");
    $("hintClose").focus();
    log("Hint opened for step " + (s.cur + 1) + " (doesn't use a try).", "info");
    refreshNav();
  }
  function closeHint() { $("hintDialog").classList.remove("open"); $("answer").focus(); }
  function submit() {
    const p = byId[cur], s = S[cur];
    saveWork();
    const open = s.steps.map((x, i) => (x.state === "open" ? i + 1 : null)).filter(Boolean);
    if (open.length) { log("Not yet: step" + (open.length > 1 ? "s " : " ") + open.join(", ") + " still open.", "info"); return; }
    const lines = s.steps.map((x, i) => "Step " + (i + 1) + ": " + (x.state === "handed" ? "handed over after 4 misses" : x.tries === 1 ? "first try" : "closed on try " + x.tries) + (x.hints ? ", hint used" : ""));
    log("Submitted. " + lines.join("; ") + ". Verified answer and worked story are open in the Problem tab.", "ok");
    s.submitted = true;
    setTab("problem");
    renderProblem();
    refreshNav();
  }
  function reveal() {
    const s = S[cur];
    const untried = s.steps.some((x) => x.state === "open" && x.tries === 0);
    if (untried && !(s.confirmArmed && Date.now() - s.confirmArmed < 8000)) {
      s.confirmArmed = Date.now();
      $("confirmNote").textContent = "Some steps haven't been tried yet. Press again to show the worked answer anyway.";
      $("reveal").textContent = "Yes, show it";
      return;
    }
    s.revealed = true;
    s.confirmArmed = 0;
    $("confirmNote").textContent = "";
    $("reveal").textContent = "Show worked answer";
    log("Worked answer shown.", "info");
    setTab("problem");
    renderProblem();
    refreshNav();
  }

  /* ---- selection ---- */
  function select(id) {
    if (!byId[id]) return;
    tick();
    saveWork();
    const from = cur;
    cur = id;
    document.dispatchEvent(new CustomEvent("bench:problem", { detail: { from, to: id } }));
    $("console").innerHTML = (S[id].log || []).join("");
    renderProblem();
    renderRight();
    setTab(DATA.page === "lesson" ? "concept" : "problem");
    refreshNav();
    window.SAFE.setHash(id);
    tick();
  }

  /* ---- wiring ---- */
  document.addEventListener("DOMContentLoaded", () => {
    buildNav();
    document.querySelectorAll("#tabs button").forEach((b) => b.addEventListener("click", () => setTab(b.dataset.tab)));
    $("check").addEventListener("click", checkStep);
    $("hint").addEventListener("click", openHint);
    $("hintClose").addEventListener("click", closeHint);
    $("submit").addEventListener("click", submit);
    $("reveal").addEventListener("click", reveal);
    $("answer").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); checkStep(); } });
    $("work").addEventListener("keydown", (e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); checkStep(); } });
    $("work").addEventListener("input", () => { syncGutter(); saveWork(); refreshNav(); });
    $("work").addEventListener("scroll", syncGutter);
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && $("hintDialog").classList.contains("open")) closeHint(); });
    $("hintDialog").addEventListener("click", (e) => { if (e.target === $("hintDialog")) closeHint(); });
    const h = window.SAFE.getHash();
    select(byId[h] ? h : P[0].id);
  });
  window.BENCH = { select, state: S, status, grade: () => checkStep(), current: () => cur };
})();
