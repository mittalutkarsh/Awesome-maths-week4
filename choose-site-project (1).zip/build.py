"""Build the Choose Function site: index, notes, lesson workbench, practice workbench.

    python3 build.py            -> writes out/*.html and out/build_report.json
"""
import contextlib
import io
import json
import os
import sys
from html import escape

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT, "src"))

# 1) Full brute-force verification (every answer, by enumeration and by argument).
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    import answers_bruteforce as AB  # asserts as it runs
BRUTE = {r[0]: r[1] for r in AB.rows}

import stories  # noqa: E402
from method import PLAN, PLAN_LONG  # noqa: E402
from problems_lesson import LESSON  # noqa: E402
from problems_practice import PRACTICE  # noqa: E402
from concepts import eq, frac, binom  # noqa: E402
from concepts2 import C, CONCEPT_ORDER, PLAN_STORY, LESSON_CONCEPT, LESSON_ORDER, PRACTICE_CONCEPT  # noqa: E402
import tagstories as TS  # noqa: E402
import notes as N  # noqa: E402

# Rebuild every worked answer, hint and nudge around the tag-word method.
for _p in LESSON + PRACTICE:
    _p["story"] = TS.S[_p["id"]]
    _ovr = TS.H[_p["id"]]
    assert len(_ovr) == len(_p["steps"]), (_p["id"], len(_ovr), len(_p["steps"]))
    for _st, _o in zip(_p["steps"], _ovr):
        _st["hint"], _st["nudges"] = _o["hint"], _o["nudges"]
    _p["concept"] = LESSON_CONCEPT.get(_p["id"]) or PRACTICE_CONCEPT[_p["id"]]
LESSON.sort(key=lambda q: LESSON_ORDER.index(q["id"]))

SLUG = "choose"
PAGES = {"index": "index.html", "notes": f"{SLUG}-notes.html", "lesson": f"{SLUG}-lesson.html", "practice": f"{SLUG}-practice.html"}

# 2) Every problem's final answer must match the independent brute-force module.
FINAL_TAG = {
    "l1": "Ex1.1 2 letters from ABCD", "l2": "Ex1.2 3 of 7 marbles", "l3": "Class 12 choose 10", "l4": "Ex1.4 9 cookies into 4/3/2 bags",
    "l5": "Ex1.5 10 cookies, 2 identical bags", "l6": "PS4 UUURRRR", "l7": "Ex2.1 6x5 grid paths", "l8": "Ex1.6 triangles on cube vertices",
    "l9": "P3.2 debate finalists (DP vs argument)", "ps1": "PS1 3 of 10 candies", "ps2": "PS2 team of 5 + team of 4 from 9",
    "ps3": "PS3 two teams of 5 from 10", "ps4": "PS4 UUURRRR", "ps5": "PS5 A->B", "ps6": "PS6 B->C", "ps7": "PS7 A->C through B",
    "ps8": "PS8 three teams of 4 from 12", "ps9": "PS9 groups 2,2,2,3,3 from 12", "ps10": "PS10 two disjoint 2B+2G subcommittees",
    "ps11": "PS11 5 jobs to 4 kids, each >=1", "ps12": "PS12 segments on cube vertices", "ps13": "PS13 octagon diagonals",
    "ps14": "PS14 total", "ps15": "PS15 3 blocks, no shared row/col", "ps16": "PS16 coin stacks", "ps17": "PS17 n",
    "ps18": "PS18 players incl. withdrawn", "ch1": "Lecture practice 3 (two teams of 4 from 8)", "ch2": "P3.1 parallelograms",
    "ch3": "P3.3 class size",
}
answer_checks = []
for p in LESSON + PRACTICE:
    final = p["steps"][-1]["ans"]
    b = BRUTE[FINAL_TAG[p["id"]]]
    if isinstance(b, list):
        b = b[0]
    if isinstance(b, set):
        b = next(iter(b))
    assert final == b, (p["id"], final, b)
    assert str(p["answer"]).replace(",", "") == str(final), (p["id"], p["answer"], final)
    answer_checks.append((p["id"], final, b))

# ------------------------------------------------------------------ rendering helpers
def asset(name):
    with open(os.path.join(ROOT, "assets", name), encoding="utf-8") as f:
        return f.read()


FONTS = ('<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
         '<link href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible:wght@400;700&family=Kalam:wght@400;700&display=swap" rel="stylesheet">')


def shell(title, body, body_attrs, scripts):
    js = "\n".join(f"<script>\n{asset(s)}\n</script>" for s in scripts)
    return (f'<!DOCTYPE html>\n<html lang="en"><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width, initial-scale=1">'
            f"<title>{escape(title)}</title>{FONTS}<style>\n{asset('style.css')}\n</style></head>"
            f"<body {body_attrs}>{body}\n{js}\n</body></html>")


_story_n = [0]


def story(frames, kind, label, wide_plan=True):
    """kind: 'worked' (plan-guided) or 'concept'."""
    _story_n[0] += 1
    sid = f"story{_story_n[0]}"
    figs = ""
    for i, f in enumerate(frames):
        skip = " skip" if f.get("skip") else ""
        title = ""
        if kind == "worked" and f.get("step"):
            title = f'<p class="ftitle">{f["step"]}. {escape(PLAN[f["step"] - 1])}</p>'
        elif f.get("title"):
            title = f'<p class="ftitle">{escape(f["title"])}</p>'
        ask = f'<div class="ask"><b>Ask him:</b> {escape(f["ask"])}</div>' if f.get("ask") else ""
        step_attr = f' data-step="{f["step"]}"' if f.get("step") else ""
        figs += (f'<figure class="frame{skip}"{step_attr}>{title}<div class="pic-wrap">{f["pic"]}</div>'
                 f'<figcaption><p>{escape(f["text"])}</p>{ask}</figcaption></figure>')
    ctl = ('<div class="story-ctl"><span class="nav"><button type="button" class="btn" data-act="back">← Back</button> '
           '<button type="button" class="btn primary" data-act="next">Next step →</button></span>'
           '<span class="dots" role="group" aria-label="Pictures"></span>'
           f'<label><input type="checkbox" class="showall"> Show all steps</label></div>')
    if kind == "worked":
        side = '<div class="plan-side" aria-hidden="true"><ol>' + "".join(f'<li data-s="{i + 1}">{escape(t)}</li>' for i, t in enumerate(PLAN_LONG)) + "</ol></div>"
        strip = '<div class="plan-strip" aria-hidden="true">' + "".join(f'<span data-s="{i + 1}">{i + 1}</span>' for i in range(len(PLAN))) + '<span class="stepname"></span></div>'
        inner = f'<div class="wbody">{side}<div class="wmain">{strip}{figs}</div></div>'
        plan_attr = f" data-plan='{escape(json.dumps(PLAN))}'"
    else:
        inner = figs
        plan_attr = ""
    return f'<div class="story {kind}" id="{sid}" tabindex="0" aria-label="{escape(label)}"{plan_attr}>{inner}{ctl}</div>'


def concept_block(cid, full):
    c = C[cid]
    h = c["eq"] + f'<p class="idea">{escape(c["idea"])}</p>' + story(c["frames"], "concept", c["title"] + " story")
    if full:
        h += f'<div class="fromclass"><b>From class.</b> {escape(c["from_class"])}</div>'
        h += f'<p><b>More worked numbers.</b> {escape(c["extra"])}</p>'
        chips = "".join(f'<a href="{PAGES["practice"]}#{pid}">{escape(label_of(ALL[pid]))}</a>' for pid in c["problems"])
        h += f'<div class="chips" aria-label="Problems that use this">{chips}</div>'
    return h


ALL = {p["id"]: p for p in LESSON + PRACTICE}


def label_of(p):
    if p["page"] == "practice" and p["id"].startswith("ps"):
        return f"Problem {p['num']}"
    return p["num"]


# ------------------------------------------------------------------ workbench pages
def bench_page(page):
    probs = LESSON if page == "lesson" else PRACTICE
    data = {"page": page, "problems": [], "concepts": {}}
    for p in probs:
        steps = [{k: s[k] for k in ("q", "type", "ans", "nudges", "hint", "reveal", "check", "ok", "named", "ph", "special", "order")} for s in p["steps"]]
        data["problems"].append({"id": p["id"], "label": label_of(p), "section": p["section"], "text": p["text"], "steps": steps,
                                 "story": story(p["story"], "worked", f"Worked answer: {label_of(p)}"),
                                 "answer": p["answer"], "check": p["check"], "concept": p["concept"], "inclass": p["inclass"],
                                 "above": p["above"], "note": p["note"]})
    if page == "lesson":
        for cid in CONCEPT_ORDER:
            data["concepts"][cid] = f"<h2>{escape(C[cid]['title'])}</h2>" + concept_block(cid, False)
    title = "Lesson: guided problems" if page == "lesson" else "Practice: Problem Set 4"
    tabs = ['<button type="button" role="tab" data-tab="problem">Problem</button>']
    if page == "lesson":
        tabs.append('<button type="button" role="tab" data-tab="concept">Concept</button>')
    else:
        tabs.append('<button type="button" role="tab" data-tab="rules">Rules</button>')
    tabs.append('<button type="button" role="tab" data-tab="steps">My steps</button>')
    panels = '<div class="tabpanel" id="tab-problem" role="tabpanel"></div>'
    panels += ('<div class="tabpanel" id="tab-concept" role="tabpanel" hidden></div>' if page == "lesson" else
               f'<div class="tabpanel" id="tab-rules" role="tabpanel" hidden>{N.RULES_CARD2}</div>')
    panels += '<div class="tabpanel" id="tab-steps" role="tabpanel" hidden></div>'
    other = "practice" if page == "lesson" else "lesson"
    body = f"""
<header class="topbar">
  <button type="button" class="btn railtoggle" id="railToggle" aria-label="Show problem list">☰</button>
  <span class="brand">Choose function</span>
  <label class="sr" for="psel" style="position:absolute;left:-9999px">Problem</label>
  <select id="psel" aria-label="Choose a problem"></select>
  <button type="button" class="btn" id="prev" aria-label="Previous problem">‹</button>
  <button type="button" class="btn" id="next" aria-label="Next problem">›</button>
  <span class="meta"><span id="finished" aria-live="polite"></span><span id="timer" aria-label="Time on this problem"></span></span>
  <nav class="links" aria-label="Site"><a href="{PAGES['index']}">Home</a><a href="{PAGES['notes']}">Notes</a><a href="{PAGES[other]}">{other.title()}</a></nav>
</header>
<div class="benchgrid">
  <nav class="rail" id="rail" aria-label="Problems"></nav>
  <section class="middle" aria-label="{escape(title)}">
    <div class="tabs" id="tabs" role="tablist">{''.join(tabs)}</div>
    {panels}
  </section>
  <section class="right" aria-label="Your steps">
    <div class="rscroll">
      <div class="pills" id="pills" aria-label="Steps"></div>
      <p class="stepq" id="stepq"></p>
      <div class="editor"><div class="gutter" id="gutter" aria-hidden="true"></div>
        <textarea id="work" aria-label="Your working (Ctrl+Enter checks the step)" placeholder="Write your method here." spellcheck="false"></textarea></div>
      <div class="ansrow"><input id="answer" type="text" inputmode="text" autocomplete="off" aria-label="Answer for this step (Enter checks)">
        <button type="button" class="btn primary" id="check">Check step</button></div>
      <p class="pnote" id="stepstate" aria-live="polite"></p>
      <div class="btnrow">
        <button type="button" class="btn" id="hint">Hint for this step</button>
        <button type="button" class="btn" id="submit">Submit question</button>
        <button type="button" class="btn warn" id="reveal">Show worked answer</button>
      </div>
      <p class="confirm-note" id="confirmNote" aria-live="polite"></p>
    </div>
    <div class="console" id="console" role="log" aria-live="polite" aria-label="Feedback"></div>
  </section>
</div>
<div class="dialog-back" id="hintDialog" role="dialog" aria-modal="true" aria-labelledby="hintTitle">
  <div class="dialog"><h3 id="hintTitle">Hint</h3><p id="hintBody"></p>
  <button type="button" class="btn primary" id="hintClose">Close (Esc)</button></div>
</div>
<script type="application/json" id="bench-data">{json.dumps(data).replace("</", "<\\/")}</script>
"""
    return shell(f"{title} · Choose function", body, 'class="bench" data-penmode="viewport"',
                 ["common.js", "checker.js", "story.js", "grid.js", "workbench.js", "pen.js"]), data


# ------------------------------------------------------------------ notes page
def section(sid, title, equation, inner):
    return f'<section class="sheet" id="{sid}" aria-labelledby="{sid}-h">{equation}<h2 id="{sid}-h">{escape(title)}</h2>{inner}</section>'


PLAN_EQ = eq("count", "=", frac("n!", "(each tag’s repeats)!"), "÷", "(look-alike group repeats)!")


def notes_page():
    toc = [("plan", "The plan")] + [(c, C[c]["title"]) for c in CONCEPT_ORDER] + [
        ("bundle", "The tag word"), ("traps", "Tricky bits"), ("worked", "Worked problems"),
        ("cheat", "Cheat sheet"), ("glossary", "Glossary"), ("habits", "Write-up habits")]
    toc_html = '<nav class="toc" aria-label="Contents"><b>Contents</b>' + "".join(
        f'<a href="#{i}" class="{"sub" if i.startswith("c") and i[1:].isdigit() else ""}">{escape(t)}</a>' for i, t in toc) + "</nav>"
    secs = []
    secs.append(section("plan", "The plan", PLAN_EQ,
                        "<p>One way of thinking for every problem this week, in four steps. One running example walks through all of them: "
                        "picking 3 of 5 friends for a sleepover.</p>" + story(PLAN_STORY, "worked", "The plan, step by step")))
    for cid in CONCEPT_ORDER:
        c = C[cid]
        secs.append(f'<section class="sheet" id="{cid}" aria-labelledby="{cid}-h">{c["eq"]}<h2 id="{cid}-h">{escape(c["title"])}</h2>'
                    + concept_block(cid, True).replace(c["eq"], "", 1) + "</section>")
    secs.append(section("bundle", "The tag word", eq("count", "=", frac("n!", "(tag repeats)!"), "÷", "(look-alike group repeats)!"),
                        "<p>Three questions build every count this week: <b>What tag does each object get?</b> <b>How many words do "
                        "the tags spell?</b> <b>Are any groups look-alikes?</b></p>"
                        + story(N.SIG_STORY2, "concept", "Tag word build-up")
                        + "<h3>Same method, every problem</h3><p>What changes from problem to problem is only the tags, and whether "
                          "any groups look alike.</p>" + N.SAME_PICTURE2))
    traps = '<ul class="traps">' + "".join(
        f'<li><b>{escape(t)}</b> <span class="pnote">(<a href="{PAGES["practice"]}#{pid}">Problem {pid[2:]}</a>)</span><br>'
        f'<span class="wrong">{escape(w)}</span> {escape(why)}</li>' for t, pid, w, why in N.TRAPS) + "</ul>"
    secs.append(section("traps", "Tricky bits", eq("right count", "=", frac("what you built", "copies of each real outcome")),
                        "<p>Each trap comes from a real problem in the set, with the tempting wrong answer.</p>" + traps))
    wk = ""
    for pid in ("l2", "l5", "l7"):
        p = ALL[pid]
        wk += f'<h3>{escape(p["num"])}</h3><p class="ptext">{escape(p["text"])}</p>' + story(p["story"], "worked", f"Worked: {p['num']}")
    secs.append(section("worked", "Worked problems", PLAN_EQ,
                        "<p>Three problems the teacher solved in class, each worked through the plan. "
                        "(They're also on the lesson page, so try them there first.)</p>" + wk))
    cheat = '<table class="cheat"><thead><tr><th>Situation</th><th>Move</th></tr></thead><tbody>' + "".join(
        f"<tr><td>{escape(a)}</td><td>{escape(b)}</td></tr>" for a, b in N.CHEAT2) + "</tbody></table>"
    secs.append(section("cheat", "Cheat sheet", eq(binom("n", "k"), "=", frac("n!", "k!(n−k)!")), cheat))
    gl = '<dl class="gloss">' + "".join(f"<dt>{escape(a)}</dt><dd>{escape(b)}</dd>" for a, b in N.GLOSSARY2) + "</dl>"
    secs.append(section("glossary", "Glossary", eq("n!", "=", "n × (n − 1) × … × 2 × 1", ",", "0! = 1"), gl))
    hb = "<ol>" + "".join(f"<li>{escape(h)}</li>" for h in N.HABITS) + "</ol>"
    secs.append(section("habits", "Write-up habits", eq(binom("n", "k"), "→", frac("n!", "k!(n−k)!"), "→", "cancel"), hb))
    body = (f'<header class="site-head"><h1>Choose function: notes</h1><nav aria-label="Site"><a href="{PAGES["index"]}">Home</a>'
            f'<a href="{PAGES["lesson"]}">Lesson</a><a href="{PAGES["practice"]}">Practice</a></nav></header>'
            f'<div class="page">{toc_html}<main class="reading-main">{"".join(secs)}</main></div>')
    return shell("Choose function: notes", body, 'class="reading" data-penmode="page"', ["common.js", "story.js", "grid.js", "pen.js"])


def index_page():
    secs = []
    secs.append(section("pages", "Three pages", eq("notes", "→", "lesson", "→", "practice"),
                        f'<ul><li><a href="{PAGES["notes"]}"><b>Notes</b></a>: the reading page. Every idea as a picture story, '
                        "what the teacher did in class, traps, a cheat sheet and a glossary. No grading.</li>"
                        f'<li><a href="{PAGES["lesson"]}"><b>Lesson</b></a>: one guided problem per idea, all from class. '
                        "The Concept tab is open first and teaches the idea with different numbers.</li>"
                        f'<li><a href="{PAGES["practice"]}"><b>Practice</b></a>: all 18 problems from Problem Set 4, '
                        "plus three challenge problems from class.</li></ul>"))
    secs.append(section("plan", "The plan", PLAN_EQ,
                        "<p>The same four steps work on every problem this week: tag, count the words, check for look-alike groups, check a tiny case.</p>" + story(PLAN_STORY, "worked", "The plan")))
    secs.append(section("grading", "How grading works", eq("a closed step", "=", "your method", "+", "the right number"),
                        "<p>Each problem is split into steps, one number per step. He writes his method in the lined box and types the "
                        "number (or an expression like <i>12 choose 4</i> or <i>2^6 × 11</i>), then presses <b>Check step</b> "
                        "(<kbd>Enter</kbd> in the answer box, <kbd>Ctrl</kbd>+<kbd>Enter</kbd> in the working box).</p>"
                        "<p>A wrong answer gets a nudge, and the nudges get more specific each time. After three misses he gets one "
                        "final attempt; if that misses too, the step's answer is handed over and he does the next step himself. "
                        "<b>Hint for this step</b> opens a hint without using a try (it's noted in My steps). "
                        "<b>Submit question</b> reports how each step went and opens the verified answer and a step-by-step picture "
                        "story once every step is closed. <b>Show worked answer</b> asks twice if some steps haven't been tried.</p>"
                        "<p>Nothing is saved when the tab closes: progress and ink start fresh each visit.</p>"))
    secs.append(section("pen", "The teaching pen", eq("P", "=", "pen on/off", ",", "Esc", "=", "pen off"),
                        "<p>Press <kbd>P</kbd> (or the ✎ button, bottom right) to write on any page. Four inks, three nibs, a "
                        "highlighter, straight lines, boxes and an eraser; hold <kbd>Shift</kbd> for a straight stroke. "
                        "<b>Stylus only</b> ignores your palm. On the notes page the ink stays with the text as you scroll and a finger "
                        "scrolls; on the workbenches the ink stays with each problem. <b>PNG</b> saves the ink only, not the page underneath.</p>"))
    body = (f'<header class="site-head"><h1>Choose function</h1><nav aria-label="Site"><a href="{PAGES["notes"]}">Notes</a>'
            f'<a href="{PAGES["lesson"]}">Lesson</a><a href="{PAGES["practice"]}">Practice</a></nav></header>'
            '<div class="page" style="grid-template-columns:1fr;max-width:980px"><main class="reading-main">'
            '<p class="lede">AwesomeMath Academy Level 1, week 4. A combination is a group without order: count it in order, '
            "then divide out the orders.</p>" + "".join(secs) + "</main></div>")
    return shell("Choose function", body, 'class="reading" data-penmode="page"', ["common.js", "story.js", "grid.js", "pen.js"])


def main():
    out = os.path.join(ROOT, "out")
    os.makedirs(out, exist_ok=True)
    lesson_html, lesson_data = bench_page("lesson")
    practice_html, practice_data = bench_page("practice")
    files = {PAGES["index"]: index_page(), PAGES["notes"]: notes_page(), PAGES["lesson"]: lesson_html, PAGES["practice"]: practice_html}
    for name, html in files.items():
        with open(os.path.join(out, name), "w", encoding="utf-8") as f:
            f.write(html)
    report = {
        "files": {k: len(v) for k, v in files.items()},
        "brute_force_rows": len(AB.rows),
        "answer_checks": answer_checks,
        "story_number_checks": len(stories.CHECKLOG),
        "story_number_log": stories.CHECKLOG,
        "lesson_problems": len(LESSON), "practice_problems": len(PRACTICE),
        "frames": {"lesson": sum(len(p["story"]) for p in LESSON), "practice": sum(len(p["story"]) for p in PRACTICE),
                   "concepts": sum(len(C[c]["frames"]) for c in CONCEPT_ORDER), "plan": len(PLAN_STORY)},
    }
    with open(os.path.join(out, "build_report.json"), "w") as f:
        json.dump(report, f, indent=1, default=str)
    with open(os.path.join(out, "data_lesson.json"), "w") as f:
        json.dump(lesson_data, f)
    with open(os.path.join(out, "data_practice.json"), "w") as f:
        json.dump(practice_data, f)
    print(json.dumps({k: v for k, v in report.items() if k not in ("story_number_log", "answer_checks")}, indent=1))


if __name__ == "__main__":
    main()
